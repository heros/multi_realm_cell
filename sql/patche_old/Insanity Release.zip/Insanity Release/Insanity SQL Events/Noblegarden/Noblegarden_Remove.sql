/* 
===============================
Event: Noblegarden
Author: Nexis
Team: Sun++ (www.sunplusplus.info)
===============================
*/

/* REMOVE NOBLEGARDEN */
DELETE FROM `gameobject_spawns` WHERE (`entry`='113768');

DELETE FROM `objectloot` WHERE (`entryid`='113768');

DELETE FROM `gameobject_names` WHERE (`entry`='113768');