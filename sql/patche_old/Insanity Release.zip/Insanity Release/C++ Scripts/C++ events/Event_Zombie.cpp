#include "StdAfx.h"
#include "Setup.h"

class SCRIPT_DECL PlaguedCritterAI : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(PlaguedCritterAI);
	PlaguedCritterAI(CreaturePointer pCreature) : CreatureAIScript(pCreature) {}

    void OnDied(UnitPointer mKiller)
    {
		// You're infected now!
        mKiller->CastSpell( mKiller, 43958, true );
    }
};

class SCRIPT_DECL ArgentHealerAI : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(ArgentHealerAI);
	ArgentHealerAI(CreaturePointer pCreature) : CreatureAIScript(pCreature)
	{
		RegisterAIUpdateEvent( 15000 );
	}

	void OnDied(UnitPointer mKiller)
	{
		RemoveAIUpdateEvent();
	}

	void AIUpdate()
	{
		// Loop over in-range players, remove the infection, remove zombie form
		unordered_set<PlayerPointer>::iterator itr = _unit->GetInRangePlayerSetBegin();
		for(; itr != _unit->GetInRangePlayerSetEnd(); ++itr)
		{
			PlayerPointer plr = (*itr);
			// We've got some plagues to cure, then?
			if( plr && plr->HasActiveAura( 43958 ) )
			{
				plr->RemoveNegativeAura( 43958 );
				continue;
			}

			if( plr && plr->GetShapeShift() == FORM_ZOMBIE )
			{
				plr->RemoveNegativeAura( 43869 );
				continue;
			}
		}

		// Now cast Holy Nova for the fancy-looking Argent Healer effect
		_unit->CastSpell( _unit, 15237, true );
	}
};

void SetupZombieEvent(ScriptMgr * mgr)
{
	mgr->register_creature_script( 27845, &PlaguedCritterAI::Create); // Plagued Roach
	mgr->register_creature_script( 27855, &PlaguedCritterAI::Create); // Plagued Vermin

	mgr->register_creature_script( 27305, &ArgentHealerAI::Create); // Argent Healer (Alliance)
	mgr->register_creature_script( 31282, &ArgentHealerAI::Create); // Argent Healer (Horde)
}

