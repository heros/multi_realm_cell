/*
 * Sun++ Scripts for Aspire MMORPG Server
 * Copyright (C) 2009 Sun++ Team <http://www.sunscripting.com/>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "StdAfx.h"
#include "Setup.h"
#include "../Common/Base.h" 

enum ENCOUNTER_CREATURES
{
	CN_SARTHARION		= 28860,
	CN_FLAME_TSUNAMI	= 30616,
	CN_LAVA_BLAZE		= 30643,
	CN_CYCLON			= 30648,
};

enum SARTHARION_DRAKES
{
	CN_DRAKE_TENEBRON	= 30452,
	CN_DRAKE_VESPERON	= 30449,
	CN_DRAKE_SHADRON	= 30451,
};

enum ENCOUNTER_SPELLS
{
	// Sartharion
	SARTHARION_CLEAVE				= 56909,
	SARTHARION_ENRAGE				= 61632,
	SARTHARION_AURA					= 61254,
	// Normal mode spells
	SARTHARION_FLAME_BREATH_NM		= 56908,
	SARTHARION_TAIL_LASH_NM			= 56910,
	// Heroic mode spells
	SARTHARION_FLAME_BREATH_HC		= 58956,
	SARTHARION_TAIL_LASH_HC			= 58957,
	// Tsunami spells
	TSUNAMI							= 57492,
	TSUNAMI_VISUAL					= 57494,
	// Cyclon spells
	CYCLON_AURA						= 57562,
	CYCLON_SPELL					= 57560,
	// TODO: add drake spells
	SHADRON_AURA					= 58105,
	TENEBRON_AURA					= 61248,
	VESPERON_AURA					= 61251,
};

struct Coord 
{
	float positionX;
	float positionY;
	float positionZ;
	float positionO;
};

static Coord TSUNAMI_SPAWN[] =
{
	// Right 
	{ 3283.215820f, 511.234100f, 59.288776f, 3.148659f },
	{ 3286.661133f, 533.317261f, 59.366989f, 3.156505f },
	{ 3283.311035f, 556.839611f, 59.397129f, 3.105450f },
	// Left 
	{ 3211.564697f, 505.982727f, 59.556610f, 0.000000f },
	{ 3214.280029f, 531.491089f, 59.168331f, 0.000000f },
	{ 3211.609131f, 560.359375f, 59.420803f, 0.000000f },
};

static Coord TSUNAMI_MOVE[] =
{
	// Left  if right 
	{ 3211.564697f, 505.982727f, 59.556610f, 3.148659f },
	{ 3214.280029f, 531.491089f, 59.168331f, 3.156505f },
	{ 3211.609131f, 560.359375f, 59.420803f, 3.105450f },
	// Right 1 if left 1
	{ 3283.215820f, 511.234100f, 59.288776f, 3.148659f },
	{ 3286.661133f, 533.317261f, 59.366989f, 3.156505f },
	{ 3283.311035f, 556.839611f, 59.397129f, 3.105450f }
};

static Coord LAVA_SPAWNS[]	=
{
	{ 3234.500488f, 516.904297f, 58.713600f, 0.955027f },
	{ 3255.424805f, 534.890137f, 58.886429f, 4.215994f },
	{ 3250.638672f, 554.778381f, 58.550964f, 2.790497f },
	{ 3252.041748f, 515.223572f, 58.552681f, 3.670144f },
	{ 3237.217285f, 507.188324f, 58.793762f, 0.956592f },
	{ 3245.539307f, 517.599243f, 58.707531f, 1.400339f },
	{ 3236.014648f, 529.310181f, 58.736656f, 4.736738f },
	{ 3244.688721f, 546.702637f, 58.394291f, 1.489113f }
};

void SpellFunc_FlameTsunami( SpellDesc* pThis, MoonScriptCreatureAI* pCreatureAI, UnitPointer pTarget, TargetType pType )
{
	if(pCreatureAI != NULL)
	{
		pCreatureAI->GetUnit()->SendChatMessage(CHAT_MSG_RAID_BOSS_EMOTE, LANG_UNIVERSAL, "The lava surrounding Sartharion churns!");

		uint32 RandomSpeach = rand()%4;
		switch (RandomSpeach)		
		{
		case 0:
			pCreatureAI->Emote( "Such flammable little insects....", Text_Yell, 14100);	
			break;
		case 1:
			pCreatureAI->Emote( "Your charred bones will litter the floor!", Text_Yell, 14101);
			break;
		case 2:
			pCreatureAI->Emote( "How much heat can you take?", Text_Yell, 14102);
			break;
		case 3:
			pCreatureAI->Emote( "All will be reduced to ash!", Text_Yell, 14103);
			break;				
		};
		
		uint32 RndSide = rand()%2;
		CreaturePointer Tsunami = NULLCREATURE;

		for(int i = 0; i < 3; ++i)
		{
			switch(RndSide)
			{
			case 0:
				Tsunami = pCreatureAI->GetUnit()->GetMapMgr()->GetInterface()->SpawnCreature(CN_FLAME_TSUNAMI, TSUNAMI_SPAWN[i].positionX, TSUNAMI_SPAWN[i].positionY, TSUNAMI_SPAWN[i].positionZ, TSUNAMI_SPAWN[i].positionO, true, true, NULL, NULL);  
				
				if( Tsunami != NULL )
					Tsunami->GetAIInterface()->MoveTo( TSUNAMI_MOVE[i].positionX, TSUNAMI_MOVE[i].positionY, TSUNAMI_MOVE[i].positionZ, TSUNAMI_MOVE[i].positionO );
				break;
			case 1:
				Tsunami = pCreatureAI->GetUnit()->GetMapMgr()->GetInterface()->SpawnCreature(CN_FLAME_TSUNAMI, TSUNAMI_SPAWN[i + 3].positionX, TSUNAMI_SPAWN[i + 3].positionY, TSUNAMI_SPAWN[i + 3].positionZ, TSUNAMI_SPAWN[i + 3].positionO, true, true, NULL, NULL);  
				
				if( Tsunami != NULL )
					Tsunami->GetAIInterface()->MoveTo( TSUNAMI_MOVE[i + 3].positionX, TSUNAMI_MOVE[i + 3].positionY, TSUNAMI_MOVE[i + 3].positionZ, TSUNAMI_MOVE[i + 3].positionO );
			};

			Tsunami = NULLCREATURE;
		};
	};
};

class SartharionAI : public MoonScriptBossAI
{
	MOONSCRIPT_FACTORY_FUNCTION(SartharionAI, MoonScriptBossAI);
	SartharionAI(CreaturePointer pCreature) : MoonScriptBossAI(pCreature)
	{
		AddSpell(SARTHARION_CLEAVE, Target_Current, 24, 0, 8 );

		if( IsHeroic() )
		{
			mFlame = AddSpell( SARTHARION_FLAME_BREATH_HC, Target_Self, 18, 2, 16); 
			mFlame->AddEmote("Burn, you miserable wretches!", Text_Yell, 14098);
			AddSpell( SARTHARION_TAIL_LASH_HC, Target_Self, 40, 0, 12);
		}
		else
		{
			mFlame = AddSpell( SARTHARION_FLAME_BREATH_NM, Target_Self, 18, 2, 16); 
			mFlame->AddEmote("Burn, you miserable wretches!", Text_Yell, 14098);
			AddSpell( SARTHARION_TAIL_LASH_NM, Target_Self, 40, 0, 12);
		};

		mFlameTsunami = AddSpellFunc( &SpellFunc_FlameTsunami, Target_Self, 99, 0, 25);

		AddEmote(Event_OnTargetDied, "You will make a fine meal for the hatchlings.", Text_Yell, 14094);
		AddEmote(Event_OnTargetDied, "You are at a grave disadvantage!", Text_Yell, 14096);
		AddEmote(Event_OnTargetDied, "This is why we call you lesser beings.", Text_Yell, 14097);
		AddEmote(Event_OnCombatStart, "It is my charge to watch over these eggs. I will see you burn before any harm comes to them!", Text_Yell, 14093);
	};

	void OnCombatStart(UnitPointer pTarget)
	{
		mFlameTsunami->TriggerCooldown();
		i_drakeCount = CheckDrakes();
		if( i_drakeCount >= 1 ) //HardMode!
		{
			mDrakeTimer = AddTimer( 30000 );
			ApplyAura( SARTHARION_AURA );
			Regenerate();// Lets heal him as aura increase his hp for 25%
		};

		mAddTimer = AddTimer( 12000 );

		ParentClass::OnCombatStart(pTarget);
	};

	void AIUpdate()
	{
		if( i_drakeCount >= 1)
		{
			if( IsTimerFinished(mDrakeTimer) )
			{
				if( b_tenebron == true )
					CallTenebron();
				else if( b_shadron == true )
					CallShadron();
				else if( b_vesperon == true )
					CallVesperon();

				ResetTimer( mDrakeTimer, 45000 );
			};
		};

		if( IsTimerFinished(mAddTimer) )
		{			
			for(uint32 i = 0; i < 2; ++i)
			{
				uint32 j = rand()%8;
				SpawnCreature(CN_LAVA_BLAZE, LAVA_SPAWNS[j].positionX, LAVA_SPAWNS[j].positionY, LAVA_SPAWNS[j].positionZ, LAVA_SPAWNS[j].positionO, true);
			};

			ResetTimer(mAddTimer, 15000);
		};
			
		if( IsTimerFinished(mAddTimer) && GetHealthPercent() <= 10 ) // enrage phase
		{
			for(uint32 i = 0; i < 6; ++i)
			{
				uint32 j = rand()%8;
				SpawnCreature(CN_LAVA_BLAZE, LAVA_SPAWNS[j].positionX, LAVA_SPAWNS[j].positionY, LAVA_SPAWNS[j].positionZ, LAVA_SPAWNS[j].positionO, true);
			};

			RemoveTimer(mAddTimer);
		};

		ParentClass::AIUpdate();		
	};

	int CheckDrakes()
	{
		i_drakeCount = 0;
		
		Tenebron = _unit->GetMapMgr()->GetInterface()->GetCreatureNearestCoords( 3239.470215f, 656.809448f, 86.760391f, CN_DRAKE_TENEBRON);
		if(Tenebron != NULL && Tenebron->isAlive()) 
		{
				b_tenebron = true;
				i_drakeCount++;
				ApplyAura( TENEBRON_AURA );
		};

		Vesperon = _unit->GetMapMgr()->GetInterface()->GetCreatureNearestCoords( 3147.475342f, 521.405151f, 89.664108f, CN_DRAKE_VESPERON);
		if(Vesperon != NULL && Vesperon->isAlive())
		{
				b_vesperon = true;
				i_drakeCount++;
				ApplyAura( VESPERON_AURA );
		};

		Shadron = _unit->GetMapMgr()->GetInterface()->GetCreatureNearestCoords( 3360.871582f, 524.196167f, 98.381096f, CN_DRAKE_SHADRON);
		if(Shadron != NULL && Shadron->isAlive())
		{
				b_shadron = true;
				i_drakeCount++;
				ApplyAura( SHADRON_AURA );
		};
		
		return i_drakeCount;
	};

	void CallTenebron()
	{
		if(Tenebron != NULL && Tenebron->isAlive())
		{
			Emote( "Tenebron! The eggs are yours to protect as well!", Text_Yell, 14106);
			Tenebron->GetAIInterface()->MoveTo( 3254.606689f, 531.867859f, 66.898163f, 4.215994f);
		};
		b_tenebron = false;
	};

	void CallShadron()
	{
		if(Shadron != NULL && Shadron->isAlive())
		{
			Emote( "Shadron! The clutch is in danger! Assist me!", Text_Yell, 14104);
			Shadron->GetAIInterface()->MoveTo( 3254.606689f, 531.867859f, 66.898163f, 4.215994f);
		};
		b_shadron = false;
	};

	void CallVesperon()
	{
		if(Vesperon != NULL && Vesperon->isAlive())
		{
			Emote( "Vesperon! Come to me, all is at risk!", Text_Yell, 14105);
			Vesperon->GetAIInterface()->MoveTo( 3254.606689f, 531.867859f, 66.898163f, 4.215994f);
		};
		b_vesperon = false;
	};

	void OnDied(UnitPointer pKiller)
	{
		Emote( "Such is the price... of failure...", Text_Yell, 14107);
		
		RemoveAIUpdateEvent();
		ParentClass::OnDied(pKiller);
	};

	void Destroy()
	{
		delete this;
	};

private:
	bool b_tenebron, b_vesperon, b_shadron;
	int32 mAddTimer, mDrakeTimer;
	int	i_drakeCount;
	
	CreaturePointer Tenebron;
	CreaturePointer Vesperon;
	CreaturePointer Shadron;
	SpellDesc* mFlame;
	SpellDesc* mFlameTsunami;
};	

class TsunamiAI : public MoonScriptBossAI
{
	MOONSCRIPT_FACTORY_FUNCTION(TsunamiAI, MoonScriptBossAI);
	TsunamiAI(CreaturePointer pCreature) : MoonScriptBossAI(pCreature){};

	void OnLoad()
	{
		RegisterAIUpdateEvent( 1000 );
		SetFlyMode(true);
		SetCanEnterCombat(false);
		_unit->SetUInt64Value(UNIT_FIELD_FLAGS, UNIT_FLAG_NOT_SELECTABLE);
		Despawn( 11500, 0 );

		ParentClass::OnLoad();
	};
	
	void AIUpdate()
	{
		ApplyAura( TSUNAMI );
		ApplyAura( TSUNAMI_VISUAL );
		RegisterAIUpdateEvent( 11000 );

		ParentClass::OnLoad();
	};

	void Destroy()
	{
		delete this;
	};
};	

class CyclonAI : public MoonScriptBossAI
{
public:
	MOONSCRIPT_FACTORY_FUNCTION(CyclonAI, MoonScriptBossAI);
	CyclonAI(CreaturePointer pCreature) : MoonScriptBossAI(pCreature)
	{};

	void OnLoad()
	{
		SetCanMove(false);
		SetCanEnterCombat(false);
		_unit->SetUInt64Value(UNIT_FIELD_FLAGS, UNIT_FLAG_NOT_SELECTABLE);
		ApplyAura( CYCLON_SPELL ); 
		ApplyAura( CYCLON_AURA );

		ParentClass::OnLoad();
	};

	void Destroy()
	{
		delete this;
	};
};

class LavaBlazeAI : public MoonScriptBossAI
{
public:
	MOONSCRIPT_FACTORY_FUNCTION(LavaBlazeAI, MoonScriptBossAI);
	LavaBlazeAI(CreaturePointer pCreature) : MoonScriptBossAI(pCreature)
	{};

	void OnLoad()
	{
		AggroNearestPlayer(1);
		ParentClass::OnLoad();
	};

	void OnCombatStop(UnitPointer pTarget)
	{
		Despawn( 1000, 0 );
	};

	void OnDied(UnitPointer pKiller)
	{
		Despawn( 1000, 0 );
	};

	void Destroy()
	{
		delete this;
	};
};

void SetupTheObsidianSanctum(ScriptMgr * mgr)
{
	//////////////////////////////////////////////////////////////////////////////////////////
	///////// Mobs
	//////////////////////////////////////////////////////////////////////////////////////////
	///////// Bosses
	mgr->register_creature_script(CN_SARTHARION, &SartharionAI::Create);
	mgr->register_creature_script(CN_FLAME_TSUNAMI, &TsunamiAI::Create);
	mgr->register_creature_script(CN_CYCLON, &CyclonAI::Create);
	mgr->register_creature_script(CN_LAVA_BLAZE, &LavaBlazeAI::Create);
};

