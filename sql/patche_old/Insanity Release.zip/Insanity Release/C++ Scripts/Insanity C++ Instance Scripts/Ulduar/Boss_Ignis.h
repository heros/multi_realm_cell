#include "StdAfx.h"
#include "../../InstanceScripts/Setup.h"
#include "../../Common/Base.h"

#define Ignis_ID 33118

class IgnisAI : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(IgnisAI);
	IgnisAI(CreaturePointer pCreature);

	void OnCombatStart(UnitPointer mTarget);

	void OnCombatStop(UnitPointer mTarget);

	void OnTargetDied(UnitPointer mTarget);
	void OnDied(UnitPointer mKiller);
	void AIUpdate();

protected:
	uint32 m_constructTimer;
	uint32 m_slagpotTimer;
	uint32 m_flameJetTimer;
	uint32 m_scorchTimer;
	uint32 m_locustTimer;
	uint32 m_constructHeatCount;
	set<LocationVector*> m_summonLocations;
	set<CreaturePointer> m_constructs;
	bool m_heroic;
};

class IronConstructAI : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(IronConstructAI);
	IronConstructAI(CreaturePointer pCreature);
	
	void OnDied(UnitPointer mKiller);

protected:
	bool m_heroic;
	MapMgrPointer m_mapMgr;
};