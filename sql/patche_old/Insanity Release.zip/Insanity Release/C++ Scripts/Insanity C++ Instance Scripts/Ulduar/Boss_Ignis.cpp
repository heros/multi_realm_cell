#include "StdAfx.h"
#include "Boss_Ignis.h"

#define IGNIS_IRON_CONSTRUCT_ID 33121
#define IGNIS_STRENGTH_OF_THE_CREATOR 64473
#define IGNIS_NORMAL_SLAGPOT 62717
#define IGNIS_HEROIC_SLAGPOT 63477
#define IGNIS_NORMAL_SCORCH 62546
#define IGNIS_HEROIC_SCORCH 63473
#define IGNIS_NORMAL_FLAME_JET 62680
#define IGNIS_HEROIC_FLAME_JET 63472

void SetupIgnis(ScriptMgr* mgr)
{
	mgr->register_creature_script( Ignis_ID, &IgnisAI::Create );
}

IgnisAI::IgnisAI(CreaturePointer pCreature) : CreatureAIScript(pCreature)
{
	if( pCreature->GetMapMgr()->pInstance->m_difficulty )
	{
		m_heroic = true;
	}
}

void IgnisAI::OnCombatStart(UnitPointer mTarget)
{
	RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));

	// sigh... Only the construct timers are 100% blizzlike. The rest are made up.
	if (m_heroic)
	{
		m_constructTimer = UNIXTIME + 30;
		m_slagpotTimer = UNIXTIME + 60;
		m_scorchTimer = UNIXTIME + 40;
		m_flameJetTimer = UNIXTIME + 120;
	}
	else 
	{
		m_constructTimer = UNIXTIME + 40;
		m_slagpotTimer = UNIXTIME + 90;
		m_scorchTimer = UNIXTIME + 60;
		m_flameJetTimer = UNIXTIME + 150;
	}
	_unit->PlaySoundToSet(15564);
}

void IgnisAI::OnCombatStop(UnitPointer mTarget)
{
	_unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
	_unit->GetAIInterface()->SetAIState(STATE_IDLE);
	RemoveAIUpdateEvent();
}

void IgnisAI::OnDied(UnitPointer mKiller)
{
	_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, "I. Have. Failed.");
	_unit->PlaySoundToSet(15572);
	RemoveAIUpdateEvent();
}

void IgnisAI::AIUpdate()
{
	if( UNIXTIME >= m_constructTimer )
	{
		if (m_heroic)
			m_constructTimer = UNIXTIME + 30;
		else
			m_constructTimer = UNIXTIME + 40;

		_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, "Arise, soldiers of the Iron Crucible! The Makers' will be done!");
		_unit->PlaySoundToSet(15565);
		// Add spawn constructs code here
	}

	if( UNIXTIME >= m_slagpotTimer )
	{
		if (m_heroic)
			m_locustTimer = UNIXTIME + 60;
		else
			m_slagpotTimer = UNIXTIME + 90;
		
		uint32 chosen = _unit->GetInRangePlayersCount();
		if( chosen )
		{
			unordered_set<PlayerPointer>::iterator itr = _unit->GetInRangePlayerSetBegin();
			while( --chosen )
				itr++;

			PlayerPointer pTarget = (*itr);
			if( pTarget )
			{
				_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, "I will burn away your impurities!");
				_unit->PlaySoundToSet(15566);
				if (m_heroic)
					_unit->CastSpell(pTarget, IGNIS_HEROIC_SLAGPOT, true);
				else
					_unit->CastSpell(pTarget, IGNIS_NORMAL_SLAGPOT, true);
			}
		}
	}

	if( UNIXTIME >= m_scorchTimer )
	{
		int RandomSpeech;
		RandomUInt(1000);
		RandomSpeech=rand()%2;
		
		switch(RandomSpeech)
		{
			case 0:
				_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, "Let the inferno consume you!");
				_unit->PlaySoundToSet(15567);
				break;
			case 1:
				_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, "BURN! Burn in the Makers' fire!");
				_unit->PlaySoundToSet(15568);
				break;
		} 
		
		if ( m_heroic )
		{
			m_scorchTimer = UNIXTIME + 40;
			_unit->CastSpell(_unit, IGNIS_HEROIC_SCORCH, false);
		}
		else
		{
			m_scorchTimer = UNIXTIME + 60;
			_unit->CastSpell(_unit, IGNIS_NORMAL_SCORCH, false);
		}
	}
	
	if ( UNIXTIME >= m_flameJetTimer )
	{
		if (m_heroic)
		{
			m_flameJetTimer = UNIXTIME + 120;
			_unit->CastSpellAoF(_unit->GetPositionX(), _unit->GetPositionY(), _unit->GetPositionZ(), dbcSpell.LookupEntryForced(IGNIS_HEROIC_FLAME_JET), true);
		}
		else
		{
			m_flameJetTimer = UNIXTIME + 150;
			_unit->CastSpellAoF(_unit->GetPositionX(), _unit->GetPositionY(), _unit->GetPositionZ(), dbcSpell.LookupEntryForced(IGNIS_NORMAL_FLAME_JET), true);
		}
	}
}

void IgnisAI::OnTargetDied(UnitPointer mTarget)
{
	int RandomSpeech;
	RandomUInt(1000);
	RandomSpeech=rand()%2;
		
	switch (RandomSpeech)
	{
		case 0:
			_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, "More scraps for the scrapheap!");
			_unit->PlaySoundToSet(15569);
			break;
		case 1:
			_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, "Your bones will serve as kindling!");
			_unit->PlaySoundToSet(15570);
			break;
	}
}

void SetupIronConstruct(ScriptMgr* mgr)
{
	mgr->register_creature_script( IGNIS_IRON_CONSTRUCT_ID, &IronConstructAI::Create );
}

IronConstructAI::IronConstructAI(CreaturePointer pCreature) : CreatureAIScript(pCreature)
{
	if (!(pCreature && pCreature->GetMapMgr() && pCreature->GetMapMgr()->pInstance))
	{
		return;
	}
	m_mapMgr = pCreature->GetMapMgr();

	if( pCreature->GetMapMgr()->pInstance->m_difficulty )
		m_heroic = true;
}

void IronConstructAI::OnDied(UnitPointer mKiller)
{
	// Find Ignis' GUID here... I'm not doing it right...
	uint32 chosen = _unit->GetInRangePlayersCount();
	uint32 ignisGUID = -1;
	/*if( chosen )
	{
		unordered_set<CreaturePointer>::iterator itr = _unit->GetInRanGetInRangeCreatureSetBegin();
		while( --chosen )
		{
			itr++;
			CreaturePointer pTarget = (*itr);
			if( pTarget->GetEntry() ==  Ignis_ID)
			{
				ignisGUID = pTarget->GetGUID();
				break;
			}
		}
	}*/

	// Need to find Ignis' GUID
	//m_mapMgr->GetUnit(-1); <- -1 needs to be replaced with the appropriate GUID.
	if (!(m_mapMgr->GetUnit(ignisGUID)) || !(m_mapMgr->GetUnit(ignisGUID)->FindAura(IGNIS_STRENGTH_OF_THE_CREATOR)))
		return;
	m_mapMgr->GetUnit(ignisGUID)->FindAura(IGNIS_STRENGTH_OF_THE_CREATOR)->ModStackSize(-1);
}