/*
 * Sun++ Scripts for Aspire MMORPG Server
 * Copyright (C) 2005-2007 Ascent Team <http://www.ascentemu.com/>
 * Copyright (C) 2007-2008 Moon++ Team <http://www.moonplusplus.info/>
 * Copyright (C) 2008-2009 Sun++ Team <http://www.sunscripting.com/>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "StdAfx.h"
#include "Setup.h"

/************************************************************************/
/*  Blackrock Depths.cpp												*/
/************************************************************************/

class AmbassadorFlamelash : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(AmbassadorFlamelash);
	SP_AI_Spell spells[1];
 bool m_spellcheck[1];

    AmbassadorFlamelash(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 1;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(15573);
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].cooldown = 10;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;

  }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};



class AnubShiah : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(AnubShiah);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    AnubShiah(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(11661);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(15471);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class BaelGar : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(BaelGar);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    BaelGar(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(13879);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(13895);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class EmperorDagranThaurissan : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(EmperorDagranThaurissan);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    EmperorDagranThaurissan(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(17492);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(24573);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(20691);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_ATTACKING;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class Eviscerator : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(Eviscerator);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    Eviscerator(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(14331);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(20741);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class FineousDarkvire : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(FineousDarkvire);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    FineousDarkvire(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(15614);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(13953);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class GeneralAngerforge : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(GeneralAngerforge);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    GeneralAngerforge(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(14099);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(9080);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(20691);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_ATTACKING;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

      }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class GolemLordArgelmach : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(GolemLordArgelmach);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    GolemLordArgelmach(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(16033);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(16034);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(10432);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_SELF;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class GoroshTheDervish : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(GoroshTheDervish);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    GoroshTheDervish(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(15589);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(24573);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class Grizzle : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(Grizzle);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    Grizzle(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(6524);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(20691);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class HedrumTheCreeper : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(HedrumTheCreeper);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    HedrumTheCreeper(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(15475);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(15474);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(3609);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_ATTACKING;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};

class HighInterrogatorGerstahn : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(HighInterrogatorGerstahn);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    HighInterrogatorGerstahn(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(10894);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(8122);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(10876);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_ATTACKING;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};

class HoundmasterGrebmar : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(HoundmasterGrebmar);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    HoundmasterGrebmar(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(23511);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(17153);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class HurleyBlackbreath : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(HurleyBlackbreath);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    HurleyBlackbreath(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(17294);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(15583);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(14099);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_ATTACKING;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class LordIncendius : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(LordIncendius);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    LordIncendius(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(13899);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(13900);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(14099);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_ATTACKING;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class LordRoccor : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(LordRoccor);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    LordRoccor(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(10448);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(6524);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(10414);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_ATTACKING;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};


class Magmus : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(Magmus);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    Magmus(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(13900);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(24375);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;
    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};

class OkThorTheBreaker : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(OkThorTheBreaker);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    OkThorTheBreaker(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(15453);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(15451);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};

class Phalanx : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(Phalanx);
	SP_AI_Spell spells[3];
 bool m_spellcheck[3];

    Phalanx(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 3;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(8732);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(22425);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;


		     spells[2].info = dbcSpell.LookupEntry(14099);
		     spells[2].cooldown = 10;
		     spells[2].targettype = TARGET_ATTACKING;
		     spells[2].instant = true;
		     spells[2].perctrigger = (float)RandomFloat(20.0f);
		     spells[2].attackstoptimer = 1000;
		     m_spellcheck[2] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};

class PrincessMoiraBronzebeard : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(PrincessMoiraBronzebeard);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    PrincessMoiraBronzebeard(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(10947);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(22645);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};

class PyromancerLoregrain : public CreatureAIScript
{
public:
	ADD_CREATURE_FACTORY_FUNCTION(PyromancerLoregrain);
	SP_AI_Spell spells[2];
 bool m_spellcheck[2];

    PyromancerLoregrain(CreaturePointer pCreature) : CreatureAIScript(pCreature)
    {
		nrspells = 2;
		for(int i=0;i<nrspells;i++)
		{
			m_spellcheck[i] = false;
		}

		     spells[0].info = dbcSpell.LookupEntry(10448);
		     spells[0].cooldown = 10;
		     spells[0].targettype = TARGET_ATTACKING;
		     spells[0].instant = true;
		     spells[0].perctrigger = (float)RandomFloat(20.0f);
		     spells[0].attackstoptimer = 1000;
		     m_spellcheck[0] = true;


		     spells[1].info = dbcSpell.LookupEntry(15095);
		     spells[1].cooldown = 10;
		     spells[1].targettype = TARGET_ATTACKING;
		     spells[1].instant = true;
		     spells[1].perctrigger = (float)RandomFloat(20.0f);
		     spells[1].attackstoptimer = 1000;
		     m_spellcheck[1] = true;

    }
    
    void OnCombatStart(UnitPointer mTarget)
    {
		CastTime();
		RegisterAIUpdateEvent(_unit->GetUInt32Value(UNIT_FIELD_BASEATTACKTIME));
    }

	void CastTime()
	{
		for(int i=0;i<nrspells;i++)
			spells[i].casttime = spells[i].cooldown;
	}

	void OnTargetDied(UnitPointer mTarget)
    {
    }

    void OnCombatStop(UnitPointer mTarget)
    {
		CastTime();
        _unit->GetAIInterface()->setCurrentAgent(AGENT_NULL);
        _unit->GetAIInterface()->SetAIState(STATE_IDLE);
        RemoveAIUpdateEvent();
    }

    void OnDied(UnitPointer mKiller)
    {
		CastTime();
       RemoveAIUpdateEvent();
    }

    void AIUpdate()
	{
		float val = (float)RandomFloat(100.0f);
		SpellCast(val);
    }

	void SpellCast(float val)
	{
        if(_unit->GetCurrentSpell() == NULL && _unit->GetAIInterface()->GetNextTarget())
        {
			float comulativeperc = 0;
		    UnitPointer target = NULLUNIT;
			for(int i=0;i<nrspells;i++)
			{
				spells[i].casttime--;
				
				if (m_spellcheck[i])
				{					
					spells[i].casttime = spells[i].cooldown;
					target = _unit->GetAIInterface()->GetNextTarget();
					switch(spells[i].targettype)
					{
						case TARGET_SELF:
						case TARGET_VARIOUS:
							_unit->CastSpell(_unit, spells[i].info, spells[i].instant); break;
						case TARGET_ATTACKING:
							_unit->CastSpell(target, spells[i].info, spells[i].instant); break;
						case TARGET_DESTINATION:
							_unit->CastSpellAoF(target->GetPositionX(),target->GetPositionY(),target->GetPositionZ(), spells[i].info, spells[i].instant); break;
					}

					if (spells[i].speech != "")
					{
						_unit->SendChatMessage(CHAT_MSG_MONSTER_YELL, LANG_UNIVERSAL, spells[i].speech.c_str());
						_unit->PlaySoundToSet(spells[i].soundid); 
					}

					m_spellcheck[i] = false;
					return;
				}

				if ((val > comulativeperc && val <= (comulativeperc + spells[i].perctrigger)) || !spells[i].casttime)
				{
					_unit->setAttackTimer(spells[i].attackstoptimer, false);
					m_spellcheck[i] = true;
				}
				comulativeperc += spells[i].perctrigger;
			}
		}
	}

	void Destroy()
	{
		delete this;
	};

protected:

	int nrspells;
};
void SetupBlackrockDepths(ScriptMgr * mgr)
{
mgr->register_creature_script(9156, &AmbassadorFlamelash::Create);
mgr->register_creature_script(9031, &AnubShiah::Create);
mgr->register_creature_script(9016, &BaelGar::Create);
mgr->register_creature_script(9019, &EmperorDagranThaurissan::Create);
mgr->register_creature_script(9029, &Eviscerator::Create);
mgr->register_creature_script(9056, &FineousDarkvire::Create);
mgr->register_creature_script(9033, &GeneralAngerforge::Create);
mgr->register_creature_script(8983, &GolemLordArgelmach::Create);
//mgr->register_creature_script(9027, &GoroshtheDervish::Create); - AI must be added ;)
mgr->register_creature_script(9028, &Grizzle::Create);
mgr->register_creature_script(9032, &HedrumTheCreeper::Create);
mgr->register_creature_script(9018, &HighInterrogatorGerstahn::Create);
mgr->register_creature_script(9319, &HoundmasterGrebmar::Create);
mgr->register_creature_script(9537, &HurleyBlackbreath::Create);
mgr->register_creature_script(9017, &LordIncendius::Create);
mgr->register_creature_script(9025, &LordRoccor::Create);
mgr->register_creature_script(9938, &Magmus::Create);
mgr->register_creature_script(9030, &OkThorTheBreaker::Create);
mgr->register_creature_script(9502, &Phalanx::Create);
mgr->register_creature_script(8929, &PrincessMoiraBronzebeard::Create);
mgr->register_creature_script(9024, &PyromancerLoregrain::Create);
}