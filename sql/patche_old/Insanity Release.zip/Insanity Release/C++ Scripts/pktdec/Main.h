#ifndef __MAIN_H__
#define __MAIN_H__

struct NameTableEntry
{
	uint32 id;
	const char *name;
};

#endif
