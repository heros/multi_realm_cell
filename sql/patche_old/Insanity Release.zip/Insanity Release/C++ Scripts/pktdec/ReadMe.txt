pktdec
======

Usage: Grab sniffitzt and feed pktdec with the xml output
