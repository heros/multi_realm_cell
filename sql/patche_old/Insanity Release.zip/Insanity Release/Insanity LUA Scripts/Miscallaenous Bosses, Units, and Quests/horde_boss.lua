--[[
***************************
*      .-.                *
*      `-.. ..-. + +      *
*      `-''-'' '          *
*  OpenSource Scripting   *
*          Team           *
* http://sunplusplus.info *
*                         *
***************************
Created:Recon
-- ]]

--Thrall--
function thrall_OnCombat(pUnit, Event)
	pUnit:PlaySoundToSet(5880)
	pUnit:RegisterEvent("chain",12000, 0)
	pUnit:RegisterEvent("shock",17000, 0)
	pUnit:RegisterEvent("summonka",25000, 0)
end

function chain(pUnit, Event)
	print "Thrall_chainlight"
	pUnit:FullCastSpellOnTarget(16033,pUnit:GetMainTank())
end

function shock(pUnit, Event)
	print "Thrall_shock"
	pUnit:FullCastSpellOnTarget(16034,pUnit:GetMainTank())
end

function summonka(pUnit, Event)
	print "Thrall_summon"
	local x = pUnit:GetX()
	local y = pUnit:GetY()
	local z = pUnit:GetZ()
	local o = pUnit:GetO()
	pUnit:SpawnCreature(3296, x, y, z, o, 83, 60000) -- Summon Grunt   after 60 sec grunt autom. despawn	
	pUnit:SpawnCreature(3296, x, y, z, o, 83, 60000)
end

function thrall_OnLeaveCombat(pUnit, Event)
	pUnit:RemoveEvents()	
end


function thrall_OnDied(pUnit, event, player)
pUnit:RemoveEvents()
end

RegisterUnitEvent(4949, 1, "thrall_OnCombat")
RegisterUnitEvent(4949, 2, "thrall_OnLeaveCombat")
RegisterUnitEvent(4949, 4, "thrall_OnDied")


-- Vol'jin  ai_script--

function vojin_OnCombat(pUnit, Event)
	pUnit:PlaySoundToSet(5881)
end

function vojin_OnLeaveCombat(pUnit, Event)
	pUnit:RemoveEvents()	
end

function vojin_OnDied(pUnit, event, player)
pUnit:RemoveEvents()
end

RegisterUnitEvent(10540, 1, "vojin_OnCombat")
RegisterUnitEvent(10540, 2, "vojin_OnLeaveCombat")
RegisterUnitEvent(10540, 4, "vojin_OnDied")

-- Lady Sylvanas Windrunner  ai_script--

function ladyswindr_OnCombat(pUnit, Event)
	pUnit:PlaySoundToSet(5886)
	pUnit:RegisterEvent("fade",35000, 3)
	pUnit:RegisterEvent("multishot",9000, 0)
	pUnit:RegisterEvent("shoot",13000, 0)
	pUnit:RegisterEvent("summonn",19000, 0)
end

function shoot(pUnit, Event)
	print "ladyswindr_shoot"
	pUnit:CastSpellOnTarget(20463,pUnit:GetMainTank())
end


function fade(pUnit, Event)
	print "ladyswindr_fade"
	pUnit:FullCastSpell(20672)
end

function multishot(pUnit, Event)
	print "ladyswindr_multishot"
	pUnit:CastSpellOnTarget(20735,pUnit:GetMainTank())
end

function summonn(pUnit, Event)
	print "ladyswindr_summon"
	pUnit:CastSpell(20464)
end

function ladyswindr_OnLeaveCombat(pUnit, Event)
	pUnit:RemoveEvents()	
end

function ladyswindr_OnDied(pUnit, event, player)
pUnit:RemoveEvents()
end

RegisterUnitEvent(10181, 1, "ladyswindr_OnCombat")
RegisterUnitEvent(10181, 2, "ladyswindr_OnLeaveCombat")
RegisterUnitEvent(10181, 4, "ladyswindr_OnDied")

--Varimathras--
function Varimathras_OnCombat(pUnit, Event)
	pUnit:PlaySoundToSet(5887)
	pUnit:RegisterEvent("drainlife",15000, 0)
	pUnit:RegisterEvent("shadoww",9000, 0)
end



function drainlife(pUnit, Event)
	print "Varimathras_drainlife"
	pUnit:CastSpellOnTarget(20743,pUnit:GetMainTank())
end

function shadoww(pUnit, Event)
	print "Varimathras_shadow"
	pUnit:CastSpellOnTarget(20741,pUnit:GetMainTank())
end

function Varimathras_OnLeaveCombat(pUnit, Event)
	pUnit:RemoveEvents()	
end

function Varimathras_OnDied(pUnit, event, player)
pUnit:RemoveEvents()
end

RegisterUnitEvent(2425, 1, "Varimathras_OnCombat")
RegisterUnitEvent(2425, 2, "Varimathras_OnLeaveCombat")
RegisterUnitEvent(2425, 4, "Varimathras_OnDied")


--Cairne Bloodhoof --

function cairblood_OnCombat(pUnit, Event)
	pUnit:PlaySoundToSet(5884)
	pUnit:RegisterEvent("charge",1, 1)
	pUnit:RegisterEvent("cleave",7000, 0)
	pUnit:RegisterEvent("mortalStrike",12000, 0)
	pUnit:RegisterEvent("thunderclap",21000, 0)
	pUnit:RegisterEvent("uppercut",30000, 0)
	pUnit:RegisterEvent("warstomp",35000, 0)
end

function charge(pUnit, Event)
--	print "cairblood_charge" 
--	pUnit:castSpell(16636)
end

function cleave(pUnit, Event)
	print "cairblood_cleave"
	pUnit:CastSpellOnTarget(16044,pUnit:GetMainTank())
end

function mortalStrike(pUnit, Event)
	print "cairblood_MortalStrike"
	pUnit:CastSpellOnTarget(16856,pUnit:GetMainTank())
end

function thunderclap(pUnit, Event)
	print "cairblood_thunderclap"
	pUnit:CastSpell(23931)
end

function uppercut(pUnit, Event)
	print "cairblood_Uppercut"
	pUnit:CastSpellOnTarget(22916,pUnit:GetClosestPlayer(1))
end

function warstomp(pUnit, Event)
	print "cairblood_warstomp"
	pUnit:CastSpell(15593)
end

function cairblood_OnLeaveCombat(pUnit, Event)
	pUnit:RemoveEvents()	
end


function cairblood_OnDied(pUnit, event, player)
pUnit:RemoveEvents()
end

RegisterUnitEvent(3057, 1, "cairblood_OnCombat")
RegisterUnitEvent(3057, 2, "cairblood_OnLeaveCombat")
RegisterUnitEvent(3057, 4, "cairblood_OnDied")

--Lor'themar Theron--

function lorthemar_OnCombat(pUnit, Event)
	--pUnit:PlaySoundToSet(i i  dont know :D )
	pUnit:RegisterEvent("cleavee",7000, 0)
	pUnit:RegisterEvent("mannaburn",12000, 0)
	pUnit:RegisterEvent("shock",17000, 0)
	pUnit:RegisterEvent("charm",30000, 0)
end

function cleavee(pUnit, Event)
	print "lorthemar_cleave"
	pUnit:CastSpellOnTarget(16044,pUnit:GetMainTank())
end

function mannaburn(pUnit, Event)
	print "lorthemar_mannaburn"
	pUnit:CastSpellOnTarget(33385,pUnit:GetClosestPlayer(4))
end

function shock(pUnit, Event)
	print "lorthemar_shock"
	pUnit:FullCastSpellOnTarget(16034,pUnit:GetMainTank())
end

function charm(pUnit, Event)
	print "lorthemar_charm"
	pUnit:CastSpellOnTarget(33384,pUnit:GetRandomPlayer(1))
end


function lorthemar_OnLeaveCombat(pUnit, Event)
	pUnit:RemoveEvents()	
end


function lorthemar_OnDied(pUnit, event, player)
pUnit:RemoveEvents()
end

RegisterUnitEvent(16802, 1, "lorthemar_OnCombat")
RegisterUnitEvent(16802, 2, "lorthemar_OnLeaveCombat")
RegisterUnitEvent(16802, 4, "lorthemar_OnDied")
