cat updates_04/*.sql > world_updates.sql
