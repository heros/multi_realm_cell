DELETE FROM `disables` WHERE `entry` = 7703 AND `sourceType` = 4;
