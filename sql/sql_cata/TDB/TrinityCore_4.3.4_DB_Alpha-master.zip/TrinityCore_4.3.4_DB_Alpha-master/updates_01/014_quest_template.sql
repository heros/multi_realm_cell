UPDATE `quest_template` SET `SourceItemCount`=1 WHERE `SourceItemId` != 0;
