DELETE FROM `gameobject_template` WHERE `entry` IN (208825,208414,207346,202592,195074);
INSERT INTO `gameobject_template` (`entry`,`type`,`displayId`,`name`,`IconName`,`castBarCaption`,`unk1`,`data0`,`data1`,`data2`,`data3`,`data4`,`data5`,`data6`,`data7`,`data8`,`data9`,`data10`,`data11`,`data12`,`data13`,`data14`,`data15`,`data16`,`data17`,`data18`,`data19`,`data20`,`data21`,`data22`,`data23`,`data24`,`data25`,`data26`,`data27`,`data28`,`data29`,`data30`,`data31`,`size`,`questItem1`,`questItem2`,`questItem3`,`questItem4`,`questItem5`,`questItem6`,`unkInt32`, `WDBVerified`) VALUES
(208825,2,2048, 'Shrine of the Ancestors', '', '', '',0,16443,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0,0,0,0,0,0,0, 15595), -- -Unknown-
(208414,5,10529, 'Inscription', '', '', '',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1.8,0,0,0,0,0,0,0, 15595), -- -Unknown-
(207346,3,10242, 'Moonpetal Lily', '', '', '',259,9605,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,10641,0,0,0,0,0,0, 15595), -- -Unknown-
(202592,19,1948, 'Mailbox', '', '', '',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0, 15595), -- -Unknown-
(195074,3,323, 'Melithar''s Stolen Bags', '', 'Retrieving', '',1691,27260,0,1,0,0,0,0,0,0,0,0,0,0,23645,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,46700,0,0,0,0,0,0, 15595); -- -Unknown-
