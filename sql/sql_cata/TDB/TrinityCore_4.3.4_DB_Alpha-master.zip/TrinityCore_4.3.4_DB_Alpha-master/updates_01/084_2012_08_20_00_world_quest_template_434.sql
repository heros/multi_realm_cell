ALTER TABLE `quest_template` CHANGE `RequiredRaces` `RequiredRaces` mediumint(8) unsigned NOT NULL DEFAULT '0';
