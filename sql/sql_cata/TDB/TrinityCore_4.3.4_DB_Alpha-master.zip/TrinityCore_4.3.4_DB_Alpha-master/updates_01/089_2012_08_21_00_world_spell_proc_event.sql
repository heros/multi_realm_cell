DELETE FROM `spell_proc_event` WHERE `entry`=64752;
INSERT INTO `spell_proc_event` (`entry`,`SchoolMask`,`SpellFamilyName`,`SpellFamilyMask0`,`SpellFamilyMask1`,`SpellFamilyMask2`,`procFlags`,`procEx`,`ppmRate`,`CustomChance`,`Cooldown`) VALUES
(64752,0,7,8392704,256,2097152,0,0,0,0,0);
