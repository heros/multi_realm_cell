DELETE FROM `instance_template` WHERE `map`=938;
INSERT INTO `instance_template` (`map`,`parent`,`script`,`allowMount`) VALUES
(938,0, '',1); -- End Time
