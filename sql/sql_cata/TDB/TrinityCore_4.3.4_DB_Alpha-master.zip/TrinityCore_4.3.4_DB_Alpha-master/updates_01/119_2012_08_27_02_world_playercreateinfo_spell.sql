/* EDIT: deprecated for 4.x
DELETE FROM `playercreateinfo_spell` WHERE `Spell` IN (59221,59535,59536,59538,59539,59540,59541);
INSERT INTO `playercreateinfo_spell` (`race`, `class`, `Spell`, `Note`) VALUES
(11,1,59221,'Shadow Resistance'),
(11,2,59535,'Shadow Resistance'),
(11,3,59536,'Shadow Resistance'),
(11,5,59538,'Shadow Resistance'),
(11,6,59539,'Shadow Resistance'),
(11,7,59540,'Shadow Resistance'),
(11,8,59541,'Shadow Resistance');
*/
