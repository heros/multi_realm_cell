DELETE FROM `spell_area` WHERE spell=58045;
INSERT INTO `spell_area` (`spell`,`area`,`quest_start`,`quest_start_active`,`quest_end`,`aura_spell`,`racemask`,`gender`,`autocast`) VALUES
(58045,4197,0,0,0,0,0,2,1);
