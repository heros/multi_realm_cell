UPDATE `creature_template` SET `faction_A`=103,`faction_H`=103 WHERE `entry` IN (30890,31540); -- Twilight Whelp
