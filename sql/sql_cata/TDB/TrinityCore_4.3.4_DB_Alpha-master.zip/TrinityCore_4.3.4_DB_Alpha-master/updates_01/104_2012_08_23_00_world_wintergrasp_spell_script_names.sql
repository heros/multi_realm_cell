DELETE FROM `spell_script_names` WHERE `spell_id` = 54640;
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(54640, 'spell_wintergrasp_defender_teleport');
