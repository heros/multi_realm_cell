DELETE FROM `spell_script_names` WHERE (`spell_id`='33695');
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(33695, 'spell_pal_exorcism_and_holy_wrath_damage');
