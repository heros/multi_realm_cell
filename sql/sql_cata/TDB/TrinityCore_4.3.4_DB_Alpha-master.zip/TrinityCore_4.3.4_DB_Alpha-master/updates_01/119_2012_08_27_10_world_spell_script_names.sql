DELETE FROM `spell_script_names` WHERE `spell_id`IN (64142,62991);
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(64142,'spell_gen_upper_deck_create_foam_sword'),
(62991,'spell_gen_bonked');
