DELETE FROM `spell_area` WHERE spell=74411 AND `area`=4197;
INSERT INTO `spell_area` (`spell`,`area`,`quest_start`,`quest_start_active`,`quest_end`,`aura_spell`,`racemask`,`gender`,`autocast`) VALUES
(74411,4197,0,0,0,0,0,2,1);
