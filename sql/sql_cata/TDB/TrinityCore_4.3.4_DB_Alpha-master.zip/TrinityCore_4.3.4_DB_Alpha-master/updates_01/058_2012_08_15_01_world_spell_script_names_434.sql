DELETE FROM `spell_script_names` WHERE `spell_id` IN (2912,5176,78674);
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(2912,  'spell_dru_eclipse_energize'),
(5176,  'spell_dru_eclipse_energize'),
(78674, 'spell_dru_eclipse_energize');
