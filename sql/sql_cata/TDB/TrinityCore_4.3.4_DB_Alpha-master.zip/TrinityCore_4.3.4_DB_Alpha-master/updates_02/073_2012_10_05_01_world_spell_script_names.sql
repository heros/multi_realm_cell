DELETE FROM `spell_script_names` WHERE `spell_id` = 54643;
INSERT INTO `spell_script_names` (`spell_id`,`ScriptName`) VALUES
(54643, 'spell_wintergrasp_defender_teleport_trigger');
