DELETE FROM spell_script_names WHERE spell_id = -755;
INSERT IGNORE INTO `spell_script_names` (`spell_id`, `ScriptName`) VALUES
(-755, 'spell_warl_health_funnel');
