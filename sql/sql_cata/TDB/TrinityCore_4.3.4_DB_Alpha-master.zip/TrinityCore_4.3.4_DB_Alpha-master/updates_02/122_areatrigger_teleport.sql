UPDATE `areatrigger_teleport` SET `target_position_x`=8380.56, `target_position_y`=998.536, `target_position_z`=29.1294, `target_orientation`=3.403392 WHERE `id`=527; -- Teddrassil - Ruth Theran
