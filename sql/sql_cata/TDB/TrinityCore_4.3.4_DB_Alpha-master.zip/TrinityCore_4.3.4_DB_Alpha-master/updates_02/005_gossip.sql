DELETE FROM `gossip_menu_option` WHERE (`menu_id`=435 AND `id`=13) OR (`menu_id`=421 AND `id`=13) OR (`menu_id`=421 AND `id`=14) OR (`menu_id`=421 AND `id`=15) OR (`menu_id`=421 AND `id`=16) OR (`menu_id`=321 AND `id`=0) OR (`menu_id`=10537 AND `id`=0) OR (`menu_id`=10539 AND `id`=0) OR (`menu_id`=2351 AND `id`=10) OR (`menu_id`=2351 AND `id`=11) OR (`menu_id`=2351 AND `id`=12) OR (`menu_id`=2351 AND `id`=13) OR (`menu_id`=2351 AND `id`=14) OR (`menu_id`=10494 AND `id`=0) OR (`menu_id`=7149 AND `id`=0) OR (`menu_id`=6952 AND `id`=0) OR (`menu_id`=6953 AND `id`=0) OR (`menu_id`=12195 AND `id`=8) OR (`menu_id`=12195 AND `id`=11) OR (`menu_id`=12195 AND `id`=12) OR (`menu_id`=12195 AND `id`=13) OR (`menu_id`=12195 AND `id`=14) OR (`menu_id`=12189 AND `id`=11) OR (`menu_id`=12189 AND `id`=12) OR (`menu_id`=12189 AND `id`=13) OR (`menu_id`=12189 AND `id`=14) OR (`menu_id`=12189 AND `id`=15) OR (`menu_id`=12189 AND `id`=16) OR (`menu_id`=11892 AND `id`=1) OR (`menu_id`=11154 AND `id`=0) OR (`menu_id`=11154 AND `id`=1) OR (`menu_id`=11152 AND `id`=0) OR (`menu_id`=11152 AND `id`=1) OR (`menu_id`=4184 AND `id`=0) OR (`menu_id`=11159 AND `id`=0) OR (`menu_id`=11143 AND `id`=0) OR (`menu_id`=12540 AND `id`=0) OR (`menu_id`=12540 AND `id`=1) OR (`menu_id`=12025 AND `id`=0) OR (`menu_id`=12025 AND `id`=1) OR (`menu_id`=11156 AND `id`=0) OR (`menu_id`=3354 AND `id`=6) OR (`menu_id`=11144 AND `id`=0) OR (`menu_id`=4283 AND `id`=0) OR (`menu_id`=12198 AND `id`=9) OR (`menu_id`=12198 AND `id`=11) OR (`menu_id`=12198 AND `id`=12) OR (`menu_id`=12198 AND `id`=13) OR (`menu_id`=12198 AND `id`=14) OR (`menu_id`=12190 AND `id`=9) OR (`menu_id`=12190 AND `id`=12) OR (`menu_id`=12190 AND `id`=13) OR (`menu_id`=12190 AND `id`=14) OR (`menu_id`=11136 AND `id`=0) OR (`menu_id`=11134 AND `id`=0) OR (`menu_id`=11109 AND `id`=0) OR (`menu_id`=11133 AND `id`=0) OR (`menu_id`=12489 AND `id`=0) OR (`menu_id`=12488 AND `id`=0) OR (`menu_id`=12487 AND `id`=0) OR (`menu_id`=12484 AND `id`=0) OR (`menu_id`=12483 AND `id`=0) OR (`menu_id`=12486 AND `id`=0) OR (`menu_id`=12485 AND `id`=0) OR (`menu_id`=7531 AND `id`=0) OR (`menu_id`=7533 AND `id`=0) OR (`menu_id`=7534 AND `id`=0) OR (`menu_id`=7535 AND `id`=0) OR (`menu_id`=7536 AND `id`=0) OR (`menu_id`=7537 AND `id`=0) OR (`menu_id`=7517 AND `id`=0) OR (`menu_id`=7459 AND `id`=0) OR (`menu_id`=7497 AND `id`=0) OR (`menu_id`=7497 AND `id`=1) OR (`menu_id`=7471 AND `id`=1) OR (`menu_id`=7455 AND `id`=0) OR (`menu_id`=7833 AND `id`=0) OR (`menu_id`=8243 AND `id`=0) OR (`menu_id`=7470 AND `id`=0) OR (`menu_id`=7788 AND `id`=14) OR (`menu_id`=7491 AND `id`=0) OR (`menu_id`=7492 AND `id`=0) OR (`menu_id`=7493 AND `id`=0) OR (`menu_id`=7367 AND `id`=0) OR (`menu_id`=10506 AND `id`=0) OR (`menu_id`=10339 AND `id`=0) OR (`menu_id`=7428 AND `id`=0) OR (`menu_id`=7430 AND `id`=0) OR (`menu_id`=7429 AND `id`=0) OR (`menu_id`=8213 AND `id`=0) OR (`menu_id`=7426 AND `id`=0) OR (`menu_id`=12192 AND `id`=8) OR (`menu_id`=12192 AND `id`=11) OR (`menu_id`=12192 AND `id`=12) OR (`menu_id`=12192 AND `id`=13) OR (`menu_id`=12192 AND `id`=14) OR (`menu_id`=11728 AND `id`=0) OR (`menu_id`=11727 AND `id`=0) OR (`menu_id`=12511 AND `id`=0) OR (`menu_id`=7288 AND `id`=1) OR (`menu_id`=11635 AND `id`=0) OR (`menu_id`=11635 AND `id`=1) OR (`menu_id`=12412 AND `id`=0) OR (`menu_id`=7892 AND `id`=0) OR (`menu_id`=7352 AND `id`=2) OR (`menu_id`=8095 AND `id`=0) OR (`menu_id`=8094 AND `id`=0) OR (`menu_id`=8100 AND `id`=0) OR (`menu_id`=8096 AND `id`=0) OR (`menu_id`=7970 AND `id`=2) OR (`menu_id`=202 AND `id`=0) OR (`menu_id`=11861 AND `id`=0) OR (`menu_id`=12656 AND `id`=0) OR (`menu_id`=11132 AND `id`=0) OR (`menu_id`=7396 AND `id`=0) OR (`menu_id`=7948 AND `id`=0) OR (`menu_id`=7948 AND `id`=1) OR (`menu_id`=1443 AND `id`=0) OR (`menu_id`=4007 AND `id`=0) OR (`menu_id`=11456 AND `id`=0) OR (`menu_id`=11457 AND `id`=0) OR (`menu_id`=11455 AND `id`=0) OR (`menu_id`=11777 AND `id`=0) OR (`menu_id`=4001 AND `id`=0) OR (`menu_id`=12951 AND `id`=0) OR (`menu_id`=12950 AND `id`=0) OR (`menu_id`=12943 AND `id`=0) OR (`menu_id`=12940 AND `id`=0) OR (`menu_id`=12930 AND `id`=0) OR (`menu_id`=12938 AND `id`=0) OR (`menu_id`=12883 AND `id`=0) OR (`menu_id`=12985 AND `id`=0) OR (`menu_id`=12991 AND `id`=0) OR (`menu_id`=10841 AND `id`=0) OR (`menu_id`=12191 AND `id`=4) OR (`menu_id`=10834 AND `id`=0) OR (`menu_id`=10696 AND `id`=1) OR (`menu_id`=12539 AND `id`=1) OR (`menu_id`=12609 AND `id`=0) OR (`menu_id`=11061 AND `id`=0) OR (`menu_id`=11079 AND `id`=0) OR (`menu_id`=12799 AND `id`=2) OR (`menu_id`=12799 AND `id`=4) OR (`menu_id`=3161 AND `id`=1) OR (`menu_id`=12439 AND `id`=0) OR (`menu_id`=9549 AND `id`=1) OR (`menu_id`=12836 AND `id`=0) OR (`menu_id`=11659 AND `id`=0) OR (`menu_id`=11654 AND `id`=0) OR (`menu_id`=11653 AND `id`=0) OR (`menu_id`=11807 AND `id`=0) OR (`menu_id`=11806 AND `id`=0) OR (`menu_id`=11805 AND `id`=0) OR (`menu_id`=11804 AND `id`=0) OR (`menu_id`=11758 AND `id`=0) OR (`menu_id`=11758 AND `id`=1) OR (`menu_id`=11757 AND `id`=0) OR (`menu_id`=11757 AND `id`=1) OR (`menu_id`=11707 AND `id`=0) OR (`menu_id`=11704 AND `id`=0) OR (`menu_id`=11691 AND `id`=0) OR (`menu_id`=12823 AND `id`=0) OR (`menu_id`=12979 AND `id`=0) OR (`menu_id`=12897 AND `id`=0) OR (`menu_id`=12833 AND `id`=0) OR (`menu_id`=12790 AND `id`=0) OR (`menu_id`=12911 AND `id`=0) OR (`menu_id`=12914 AND `id`=0) OR (`menu_id`=10510 AND `id`=0) OR (`menu_id`=10139 AND `id`=0) OR (`menu_id`=12949 AND `id`=1) OR (`menu_id`=10202 AND `id`=0) OR (`menu_id`=10426 AND `id`=1) OR (`menu_id`=12762 AND `id`=0) OR (`menu_id`=12887 AND `id`=0) OR (`menu_id`=10942 AND `id`=0) OR (`menu_id`=10988 AND `id`=0) OR (`menu_id`=10974 AND `id`=0) OR (`menu_id`=4184 AND `id`=0) OR (`menu_id`=2952 AND `id`=0) OR (`menu_id`=10767 AND `id`=13) OR (`menu_id`=10767 AND `id`=14) OR (`menu_id`=13406 AND `id`=0) OR (`menu_id`=13406 AND `id`=5) OR (`menu_id`=13406 AND `id`=7) OR (`menu_id`=13321 AND `id`=0) OR (`menu_id`=13321 AND `id`=1) OR (`menu_id`=13321 AND `id`=9) OR (`menu_id`=12015 AND `id`=0) OR (`menu_id`=12015 AND `id`=1) OR (`menu_id`=13405 AND `id`=0) OR (`menu_id`=13405 AND `id`=5) OR (`menu_id`=13183 AND `id`=0) OR (`menu_id`=10502 AND `id`=0) OR (`menu_id`=5849 AND `id`=0) OR (`menu_id`=12761 AND `id`=0) OR (`menu_id`=9712 AND `id`=0) OR (`menu_id`=9696 AND `id`=0) OR (`menu_id`=9653 AND `id`=0) OR (`menu_id`=9612 AND `id`=0) OR (`menu_id`=9611 AND `id`=0) OR (`menu_id`=9610 AND `id`=0) OR (`menu_id`=9595 AND `id`=0) OR (`menu_id`=9594 AND `id`=0) OR (`menu_id`=9586 AND `id`=0) OR (`menu_id`=9586 AND `id`=2) OR (`menu_id`=13164 AND `id`=0) OR (`menu_id`=10389 AND `id`=4) OR (`menu_id`=10389 AND `id`=5) OR (`menu_id`=10389 AND `id`=6) OR (`menu_id`=10389 AND `id`=10) OR (`menu_id`=10389 AND `id`=12) OR (`menu_id`=10314 AND `id`=0) OR (`menu_id`=13075 AND `id`=0) OR (`menu_id`=13075 AND `id`=1) OR (`menu_id`=13075 AND `id`=2) OR (`menu_id`=13075 AND `id`=3) OR (`menu_id`=13075 AND `id`=4) OR (`menu_id`=13124 AND `id`=5) OR (`menu_id`=12795 AND `id`=0) OR (`menu_id`=13362 AND `id`=0) OR (`menu_id`=11829 AND `id`=0) OR (`menu_id`=11829 AND `id`=1) OR (`menu_id`=12760 AND `id`=0) OR (`menu_id`=10614 AND `id`=2) OR (`menu_id`=10614 AND `id`=0) OR (`menu_id`=12939 AND `id`=0) OR (`menu_id`=13163 AND `id`=0) OR (`menu_id`=13162 AND `id`=0) OR (`menu_id`=8713 AND `id`=0) OR (`menu_id`=12233 AND `id`=0) OR (`menu_id`=12233 AND `id`=1) OR (`menu_id`=12235 AND `id`=0) OR (`menu_id`=8031 AND `id`=0) OR (`menu_id`=13018 AND `id`=0) OR (`menu_id`=13018 AND `id`=2) OR (`menu_id`=13065 AND `id`=0) OR (`menu_id`=6183 AND `id`=0) OR (`menu_id`=13012 AND `id`=0) OR (`menu_id`=13012 AND `id`=2) OR (`menu_id`=13013 AND `id`=0) OR (`menu_id`=6575 AND `id`=2) OR (`menu_id`=6574 AND `id`=0) OR (`menu_id`=6225 AND `id`=0) OR (`menu_id`=6225 AND `id`=2) OR (`menu_id`=13068 AND `id`=0) OR (`menu_id`=13019 AND `id`=0) OR (`menu_id`=13019 AND `id`=2) OR (`menu_id`=13066 AND `id`=0) OR (`menu_id`=1971 AND `id`=0) OR (`menu_id`=9708 AND `id`=0) OR (`menu_id`=12974 AND `id`=0) OR (`menu_id`=8899 AND `id`=0) OR (`menu_id`=8908 AND `id`=0) OR (`menu_id`=9335 AND `id`=0) OR (`menu_id`=9013 AND `id`=0) OR (`menu_id`=9014 AND `id`=0) OR (`menu_id`=9011 AND `id`=0) OR (`menu_id`=9011 AND `id`=1) OR (`menu_id`=10218 AND `id`=0) OR (`menu_id`=3923 AND `id`=1) OR (`menu_id`=6508 AND `id`=0) OR (`menu_id`=12981 AND `id`=0) OR (`menu_id`=9568 AND `id`=0) OR (`menu_id`=9461 AND `id`=0) OR (`menu_id`=9462 AND `id`=0) OR (`menu_id`=9459 AND `id`=0) OR (`menu_id`=9303 AND `id`=0) OR (`menu_id`=9304 AND `id`=0) OR (`menu_id`=9305 AND `id`=0) OR (`menu_id`=9302 AND `id`=0) OR (`menu_id`=9536 AND `id`=0) OR (`menu_id`=9532 AND `id`=0) OR (`menu_id`=9507 AND `id`=0) OR (`menu_id`=9507 AND `id`=1) OR (`menu_id`=9507 AND `id`=2) OR (`menu_id`=9507 AND `id`=3) OR (`menu_id`=9508 AND `id`=0) OR (`menu_id`=9508 AND `id`=1) OR (`menu_id`=9508 AND `id`=2) OR (`menu_id`=9508 AND `id`=3) OR (`menu_id`=9509 AND `id`=0) OR (`menu_id`=9509 AND `id`=1) OR (`menu_id`=9509 AND `id`=2) OR (`menu_id`=9509 AND `id`=3) OR (`menu_id`=9510 AND `id`=0) OR (`menu_id`=9510 AND `id`=1) OR (`menu_id`=9510 AND `id`=2) OR (`menu_id`=9510 AND `id`=3) OR (`menu_id`=9487 AND `id`=0) OR (`menu_id`=9497 AND `id`=0) OR (`menu_id`=9497 AND `id`=1) OR (`menu_id`=9497 AND `id`=2) OR (`menu_id`=9496 AND `id`=0) OR (`menu_id`=9633 AND `id`=0) OR (`menu_id`=10316 AND `id`=3) OR (`menu_id`=12101 AND `id`=2) OR (`menu_id`=12101 AND `id`=3) OR (`menu_id`=9848 AND `id`=0) OR (`menu_id`=9852 AND `id`=0) OR (`menu_id`=9852 AND `id`=1) OR (`menu_id`=9852 AND `id`=2) OR (`menu_id`=11277 AND `id`=0) OR (`menu_id`=10274 AND `id`=0) OR (`menu_id`=10273 AND `id`=0) OR (`menu_id`=7706 AND `id`=0) OR (`menu_id`=7581 AND `id`=2) OR (`menu_id`=7581 AND `id`=0) OR (`menu_id`=7581 AND `id`=1) OR (`menu_id`=7552 AND `id`=2) OR (`menu_id`=7552 AND `id`=1) OR (`menu_id`=7552 AND `id`=0) OR (`menu_id`=12641 AND `id`=0) OR (`menu_id`=9871 AND `id`=0) OR (`menu_id`=10124 AND `id`=1) OR (`menu_id`=10469 AND `id`=2) OR (`menu_id`=10470 AND `id`=2) OR (`menu_id`=10472 AND `id`=2) OR (`menu_id`=10340 AND `id`=0) OR (`menu_id`=9906 AND `id`=0) OR (`menu_id`=10209 AND `id`=0) OR (`menu_id`=9928 AND `id`=0) OR (`menu_id`=9899 AND `id`=0) OR (`menu_id`=12973 AND `id`=0) OR (`menu_id`=12972 AND `id`=0) OR (`menu_id`=12975 AND `id`=0) OR (`menu_id`=11384 AND `id`=0) OR (`menu_id`=12370 AND `id`=1) OR (`menu_id`=10468 AND `id`=2) OR (`menu_id`=10206 AND `id`=0) OR (`menu_id`=9670 AND `id`=0) OR (`menu_id`=10473 AND `id`=2) OR (`menu_id`=10500 AND `id`=0) OR (`menu_id`=9274 AND `id`=0) OR (`menu_id`=9273 AND `id`=0) OR (`menu_id`=11018 AND `id`=0) OR (`menu_id`=11018 AND `id`=1) OR (`menu_id`=11018 AND `id`=3) OR (`menu_id`=11018 AND `id`=4) OR (`menu_id`=11018 AND `id`=5) OR (`menu_id`=11015 AND `id`=0) OR (`menu_id`=11015 AND `id`=1) OR (`menu_id`=11015 AND `id`=4) OR (`menu_id`=11015 AND `id`=5) OR (`menu_id`=11015 AND `id`=6) OR (`menu_id`=11016 AND `id`=0) OR (`menu_id`=11016 AND `id`=1) OR (`menu_id`=11016 AND `id`=3) OR (`menu_id`=11016 AND `id`=5) OR (`menu_id`=11016 AND `id`=6) OR (`menu_id`=11017 AND `id`=6) OR (`menu_id`=11013 AND `id`=6) OR (`menu_id`=11014 AND `id`=0) OR (`menu_id`=11014 AND `id`=3) OR (`menu_id`=11014 AND `id`=4) OR (`menu_id`=11014 AND `id`=5) OR (`menu_id`=11014 AND `id`=6) OR (`menu_id`=10383 AND `id`=0) OR (`menu_id`=10343 AND `id`=3) OR (`menu_id`=10602 AND `id`=0) OR (`menu_id`=8749 AND `id`=0) OR (`menu_id`=8750 AND `id`=0) OR (`menu_id`=8750 AND `id`=1) OR (`menu_id`=8355 AND `id`=0) OR (`menu_id`=7443 AND `id`=0) OR (`menu_id`=7442 AND `id`=0) OR (`menu_id`=7441 AND `id`=0) OR (`menu_id`=7422 AND `id`=0) OR (`menu_id`=7421 AND `id`=0) OR (`menu_id`=11877 AND `id`=0) OR (`menu_id`=11877 AND `id`=1) OR (`menu_id`=3283 AND `id`=7) OR (`menu_id`=12046 AND `id`=0) OR (`menu_id`=12046 AND `id`=1) OR (`menu_id`=12046 AND `id`=2) OR (`menu_id`=12002 AND `id`=0) OR (`menu_id`=12002 AND `id`=1) OR (`menu_id`=12002 AND `id`=2) OR (`menu_id`=12045 AND `id`=0) OR (`menu_id`=12045 AND `id`=1) OR (`menu_id`=12045 AND `id`=2) OR (`menu_id`=12045 AND `id`=3) OR (`menu_id`=12045 AND `id`=4) OR (`menu_id`=12045 AND `id`=5) OR (`menu_id`=12045 AND `id`=6) OR (`menu_id`=12045 AND `id`=7) OR (`menu_id`=12045 AND `id`=8) OR (`menu_id`=12045 AND `id`=9) OR (`menu_id`=12045 AND `id`=10) OR (`menu_id`=11146 AND `id`=0) OR (`menu_id`=11082 AND `id`=0) OR (`menu_id`=11009 AND `id`=0) OR (`menu_id`=11169 AND `id`=0) OR (`menu_id`=11169 AND `id`=1) OR (`menu_id`=10722 AND `id`=0) OR (`menu_id`=10358 AND `id`=1) OR (`menu_id`=10358 AND `id`=3) OR (`menu_id`=10358 AND `id`=4) OR (`menu_id`=10358 AND `id`=5) OR (`menu_id`=10358 AND `id`=6) OR (`menu_id`=10358 AND `id`=7) OR (`menu_id`=11244 AND `id`=0) OR (`menu_id`=11248 AND `id`=0) OR (`menu_id`=11266 AND `id`=0) OR (`menu_id`=11266 AND `id`=1) OR (`menu_id`=8113 AND `id`=0) OR (`menu_id`=12646 AND `id`=0) OR (`menu_id`=12646 AND `id`=1) OR (`menu_id`=12890 AND `id`=0) OR (`menu_id`=7949 AND `id`=0) OR (`menu_id`=7949 AND `id`=1) OR (`menu_id`=11739 AND `id`=0) OR (`menu_id`=10421 AND `id`=0) OR (`menu_id`=10425 AND `id`=0) OR (`menu_id`=7435 AND `id`=0) OR (`menu_id`=12271 AND `id`=0) OR (`menu_id`=5968 AND `id`=0) OR (`menu_id`=5968 AND `id`=1) OR (`menu_id`=12265 AND `id`=0) OR (`menu_id`=12280 AND `id`=0) OR (`menu_id`=12541 AND `id`=0) OR (`menu_id`=13015 AND `id`=0) OR (`menu_id`=13356 AND `id`=0) OR (`menu_id`=10677 AND `id`=1) OR (`menu_id`=10550 AND `id`=0) OR (`menu_id`=10826 AND `id`=0) OR (`menu_id`=10805 AND `id`=0) OR (`menu_id`=10805 AND `id`=1) OR (`menu_id`=12494 AND `id`=0) OR (`menu_id`=10681 AND `id`=0) OR (`menu_id`=10903 AND `id`=0) OR (`menu_id`=10620 AND `id`=0) OR (`menu_id`=10624 AND `id`=0) OR (`menu_id`=10622 AND `id`=0) OR (`menu_id`=12193 AND `id`=11) OR (`menu_id`=12193 AND `id`=12) OR (`menu_id`=12193 AND `id`=13) OR (`menu_id`=12193 AND `id`=14) OR (`menu_id`=12197 AND `id`=11) OR (`menu_id`=12197 AND `id`=12) OR (`menu_id`=12197 AND `id`=13) OR (`menu_id`=12197 AND `id`=14) OR (`menu_id`=12199 AND `id`=11) OR (`menu_id`=12199 AND `id`=12) OR (`menu_id`=12199 AND `id`=13) OR (`menu_id`=12199 AND `id`=14) OR (`menu_id`=11794 AND `id`=0) OR (`menu_id`=11794 AND `id`=1) OR (`menu_id`=11795 AND `id`=0) OR (`menu_id`=10842 AND `id`=0);
INSERT INTO `gossip_menu_option` (`menu_id`, `id`, `option_icon`, `option_text`, `box_coded`, `box_money`, `box_text`) VALUES
(435, 13, 0, 'Profession Trainer', 0, 0, ''), -- Stormwind City Guard
(421, 13, 0, 'Mining', 0, 0, ''), -- Stormwind City Guard
(421, 14, 0, 'Riding', 0, 0, ''), -- Stormwind City Guard
(421, 15, 0, 'Skinning', 0, 0, ''), -- Stormwind City Guard
(421, 16, 0, 'Tailoring', 0, 0, ''), -- Stormwind City Guard
(321, 0, 0, 'Please port me to Darnassus.', 0, 0, ''), -- Morridune
(10537, 0, 0, 'That''s not important right now. Ota Wen, listen to me. You must rise up against the orcs!', 0, 0, ''), -- Ota Wen
(10539, 0, 0, 'Yes, rise up! Tell your fellow furbolg to break out of this cage and to slay the Horde. The power of the rod compels you!', 0, 0, ''), -- Ota Wen
(2351, 10, 0, 'Jewelcrafting', 0, 0, ''), -- Darnassus Sentinel
(2351, 11, 0, 'Leatherworking', 0, 0, ''), -- Darnassus Sentinel
(2351, 12, 0, 'Mining', 0, 0, ''), -- Darnassus Sentinel
(2351, 13, 0, 'Skinning', 0, 0, ''), -- Darnassus Sentinel
(2351, 14, 0, 'Tailoring', 0, 0, ''), -- Darnassus Sentinel
(10494, 0, 0, 'I am ready to be one with the whirling vortex and defeat Lord Magmathar.', 0, 0, ''), -- The Vortex
(7149, 0, 2, 'Yes, I''d like to purchase a ride down to the Ghostlands.', 0, 0, ''), -- Skymistress Gloaming
(6952, 0, 0, 'Why... yes, of course.  I''ve something to show you right inside this building, Mr. Anvilward.', 0, 0, ''), -- Prospector Anvilward
(6953, 0, 0, 'I need a moment of your time, sir.', 0, 0, ''), -- Prospector Anvilward
(12195, 8, 3, 'Train me in Mining.', 0, 0, ''), -- Saren
(12195, 11, 3, 'Train me in Engineering.', 0, 0, ''), -- Saren
(12195, 12, 0, 'Tell me about Mining.', 0, 0, ''), -- Saren
(12195, 13, 0, 'Tell me about gathering professions.', 0, 0, ''), -- Saren
(12195, 14, 0, 'Tell me about production professions.', 0, 0, ''), -- Saren
(12189, 11, 3, 'Train me in Mining.', 0, 0, ''), -- Saren
(12189, 12, 0, 'Tell me about Blacksmithing.', 0, 0, ''), -- Saren
(12189, 13, 0, 'Tell me about Engineering.', 0, 0, ''), -- Saren
(12189, 14, 0, 'Tell me about Jewelcrafting.', 0, 0, ''), -- Saren
(12189, 15, 0, 'Tell me about gathering professions.', 0, 0, ''), -- Saren
(12189, 16, 0, 'Tell me about production professions.', 0, 0, ''), -- Saren
(11892, 1, 0, 'Show me where I can fly.', 0, 0, ''), -- Bat Handler Maggotbreath
(11154, 0, 3, 'I seek training in the ways of the Hunter.', 0, 0, ''), -- Dedlow Wormwood
(11154, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Dedlow Wormwood
(11152, 0, 2, 'I''d like to purchase a bat ride.', 0, 0, ''), -- Timothy Cunningham
(11152, 1, 0, 'I''ll take that flight to Brill now.', 0, 0, ''), -- Timothy Cunningham
(4184, 0, 3, 'Train me.', 0, 0, ''), -- Shelene Rhobart
(11159, 0, 1, 'Gordo, do you think you could repair my gear?', 0, 0, ''), -- Gordo
(11143, 0, 1, 'I wish to buy from you.', 0, 0, ''), -- Apprentice Crispin
(12540, 0, 3, 'I seek training in the ways of the Hunter.', 0, 0, ''), -- Matt Bruxworthy
(12540, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Matt Bruxworthy
(12025, 0, 5, 'Make this inn your home.', 0, 0, ''), -- Commander Hickley
(12025, 1, 1, 'Let me browse your goods.', 0, 0, ''), -- Commander Hickley
(11156, 0, 0, 'I am ready.', 0, 0, ''), -- Shadow Priestess Malia
(3354, 6, 0, 'Warrior', 0, 0, ''), -- Deathguard Cyrus
(11144, 0, 0, 'Who''s the little guy?', 0, 0, ''), -- Apothecary Jerrod
(4283, 0, 1, 'Let me browse your goods.', 0, 0, ''), -- Gordon Wendham
(12198, 9, 3, 'Train me in Skinning.', 0, 0, ''), -- Nedric Sallow
(12198, 11, 3, 'Train me in Leatherworking.', 0, 0, ''), -- Nedric Sallow
(12198, 12, 0, 'Tell me about Skinning.', 0, 0, ''), -- Nedric Sallow
(12198, 13, 0, 'Tell me about gathering professions.', 0, 0, ''), -- Nedric Sallow
(12198, 14, 0, 'Tell me about production professions.', 0, 0, ''), -- Nedric Sallow
(12190, 9, 3, 'Train me in Skinning.', 0, 0, ''), -- Nedric Sallow
(12190, 12, 0, 'Tell me about Leatherworking.', 0, 0, ''), -- Nedric Sallow
(12190, 13, 0, 'Tell me about gathering professions.', 0, 0, ''), -- Nedric Sallow
(12190, 14, 0, 'Tell me about production professions.', 0, 0, ''), -- Nedric Sallow
(11136, 0, 0, 'Your father?', 0, 0, ''), -- Lilian Voss
(11134, 0, 0, 'Lilian, you''re one of the Forsaken, like me.  Which brings the question: why did the Scarlet Crusade put you in a cage?  They usually kill the undead on sight.', 0, 0, ''), -- Lilian Voss
(11109, 0, 3, 'I seek training in the ways of the Hunter.', 0, 0, ''), -- Xavier the Huntsman
(11133, 0, 0, 'You''re not hideous, Lilian... you''re one of us.  Here, look in this mirror, see for yourself.', 0, 0, ''), -- Lilian Voss
(12489, 0, 0, 'You talk to Undertaker Mordo.  He''ll tell you what to do.  That''s all I know.', 0, 0, ''), -- Valdred Moray
(12488, 0, 0, 'Calm down, Valdred.  Undertaker Mordo probably sewed some new ones on for you.', 0, 0, ''), -- Valdred Moray
(12487, 0, 0, 'Don''t you remember?  You died.', 0, 0, ''), -- Valdred Moray
(12484, 0, 0, 'Lilian, do you realize that you are undead yourself?', 0, 0, ''), -- Lilian Voss
(12483, 0, 0, 'I''m not an abomination, I''m simply undead.  I just want to speak with you.', 0, 0, ''), -- Lilian Voss
(12486, 0, 0, 'You are free to do whatever you like.', 0, 0, ''), -- Marshal Redpath
(12485, 0, 0, 'I''m not here to fight.  I''ve only been asked to speak with you.', 0, 0, ''), -- Marshal Redpath
(7531, 0, 0, 'I''m a prisoner, what does it look like? The draenei filth captured me as I exited the sun gate. They killed our portal controllers and destroyed the gate. The Sun King will be most displeased with this turn of events.', 0, 0, ''), -- Captured Sunhawk Agent
(7533, 0, 0, 'I did and you believed me. Thank you for the information, blood elf. You have helped us more than you could know.', 0, 0, ''), -- Captured Sunhawk Agent
(7534, 0, 0, 'The Vector Coil is massive. I hope we have more than one abomination guarding the numerous weak points.', 0, 0, ''), -- Captured Sunhawk Agent
(7535, 0, 0, 'Sironas is an eredar... I mean, yes, obviously.', 0, 0, ''), -- Captured Sunhawk Agent
(7536, 0, 0, 'Incredible. How did Sironas accomplish such a thing?', 0, 0, ''), -- Captured Sunhawk Agent
(7537, 0, 0, 'Ah yes, Sironas. I had nearly forgotten that Sironas was here. I served under Sironas back on Outland. I hadn''t heard of this abomination, though; those damnable draenei captured me before I even fully materialized on this world.', 0, 0, ''), -- Captured Sunhawk Agent
(7517, 0, 3, 'I wish to train, Aesom.', 0, 0, ''), -- Vindicator Aesom
(7459, 0, 3, 'Train me in the ways of herbalism.', 0, 0, ''), -- Morae
(7497, 0, 5, 'Make this inn your home.', 0, 0, ''), -- Caregiver Topher Loaal
(7497, 1, 1, 'I want to browse your goods.', 0, 0, ''), -- Caregiver Topher Loaal
(7471, 1, 1, 'I wish to browse your goods.', 0, 0, ''), -- Clopper Wizbang
(7455, 0, 3, 'I wish to learn more about first aid.', 0, 0, ''), -- Anchorite Paetheus
(7833, 0, 3, 'Train me in the trade of mining.', 0, 0, ''), -- Prospector Nachlan
(8243, 0, 1, 'I want to browse your goods.', 0, 0, ''), -- Little Azimi
(7470, 0, 2, 'I wish to travel by hippogryph.', 0, 0, ''), -- Laando
(7788, 14, 0, 'Cooking', 0, 0, ''), -- Exodar Peacekeeper
(7491, 0, 0, '<Turn to the next page.>', 0, 0, ''), -- Galaen's Journal
(7492, 0, 0, '<Turn to the next page.>', 0, 0, ''), -- Galaen's Journal
(7493, 0, 0, '<Turn to the next page.>', 0, 0, ''), -- Galaen's Journal
(7367, 0, 0, 'Vindicator, please loan me your elekk to ride to Forest Song.', 0, 0, ''), -- Vindicator Palanaar
(10506, 0, 0, 'I am ready to invoke the shade of Shadumbra.', 0, 0, ''), -- Halannia
(10339, 0, 0, 'Sentinel, I would like to ride one of your nightsabers to Astranaar.', 0, 0, ''), -- Sentinel Avana
(7428, 0, 1, 'I wish to browse your wares, Ergh.', 0, 0, ''), -- Ergh of the Stillpine
(7430, 0, 3, 'I wish to become a leatherworker, Moordo. Please train me.', 0, 0, ''), -- Moordo
(7429, 0, 3, 'Please teach me how to skin, Gurf.', 0, 0, ''), -- Gurf
(8213, 0, 1, 'What elekks are for sale?', 0, 0, ''), -- Torallius the Pack Handler
(7426, 0, 0, 'It''s over, Spark. The admiral knows it was you who betrayed the Alliance. Now you''re either going to cooperate with me and tell me everything that you know or we''re going to engage in some fisticuff.', 0, 0, ''), -- Engineer "Spark" Overgrind
(12192, 8, 3, 'Train me in Mining.', 0, 0, ''), -- Valn
(12192, 11, 3, 'Train me in Blacksmithing.', 0, 0, ''), -- Valn
(12192, 12, 0, 'Tell me about Mining.', 0, 0, ''), -- Valn
(12192, 13, 0, 'Tell me about gathering professions.', 0, 0, ''), -- Valn
(12192, 14, 0, 'Tell me about production professions.', 0, 0, ''), -- Valn
(11728, 0, 0, '<Place the food and drink inside the lifeboat.>', 0, 0, ''), -- Ruined Lifeboat
(11727, 0, 1, 'I hear you''ve got some drinks I can buy, Slim.', 0, 0, ''), -- Whiskey Slim
(12511, 0, 0, 'Yes.  Please prepare the portal, Erallier.', 0, 0, ''), -- War-Mage Erallier
(7288, 1, 1, 'Let me browse your goods.', 0, 0, ''), -- Innkeeper Velandra
(11635, 0, 0, 'Did you see who killed the Furlbrows?', 0, 0, ''), -- West Plains Drifter
(11635, 1, 0, 'Maybe a couple copper will loosen your tongue. Now tell me, did you see who killed the Furlbrows?', 0, 2, 'Are you sure you want to give this hobo money?'), -- West Plains Drifter
(12412, 0, 0, 'Step through the portal and return to Wildheart Point.', 0, 0, ''), -- -Unknown-
(7892, 0, 1, 'I have marks to redeem!', 0, 0, ''), -- Warrant Officer Tracy Proudwell
(7352, 2, 0, 'Tell me of your homeland.', 0, 0, ''), -- Force Commander Danath Trollbane
(8095, 0, 2, 'Show me where I can fly.', 0, 0, ''), -- Runetog Wildhammer
(8094, 0, 1, 'What do you have for sale?', 0, 0, ''), -- Supply Officer Pestle
(8100, 0, 0, 'Send me to Shatter Point!', 0, 0, ''), -- Gryphoneer Leafbeard
(8096, 0, 0, 'Send me to Honor Point!', 0, 0, ''), -- Gryphoneer Windbellow
(7970, 2, 0, 'Send me to Shatter Point!', 0, 0, ''), -- Wing Commander Dabir'ee
(202, 0, 0, 'Let the event begin!', 0, 0, ''), -- Disciple of Naralex
(11861, 0, 3, 'Train me.', 0, 0, ''), -- Theresa Denman
(12656, 0, 1, 'I want to browse your goods.', 0, 0, ''), -- Guild Page
(11132, 0, 0, 'You''re not hideous, Lilian... you''re one of us.  Here, look in this mirror, see for yourself.', 0, 0, ''), -- Lilian Voss
(7396, 0, 1, 'I want to browse your goods.', 0, 0, ''), -- Provisioner Anir
(7948, 0, 5, 'Make this inn your home.', 0, 0, ''), -- Caregiver Ophera Windfury
(7948, 1, 1, 'I want to browse your goods.', 0, 0, ''), -- Caregiver Ophera Windfury
(1443, 0, 0, 'You can cook?  So can I!  Is there a recipe you can teach me?', 0, 0, ''), -- Henry Stern
(4007, 0, 3, 'I am here for training.', 0, 0, ''), -- Grif Wildheart
(11456, 0, 0, 'Captain Tharran wants you to deploy your remote observation bots and withdraw to Kharanos.', 0, 0, ''), -- Mountaineer Lewin
(11457, 0, 0, 'Captain Tharran wants you to deploy your remote observation bots and withdraw to Kharanos.', 0, 0, ''), -- Mountaineer Valgrum
(11455, 0, 0, 'Captain Tharran wants you to deploy your remote observation bots and withdraw to Kharanos.', 0, 0, ''), -- Mountaineer Dunstan
(11777, 0, 2, 'Show me where I can fly.', 0, 0, ''), -- Brolan Galebeard
(4001, 0, 1, 'I would like to buy from you.', 0, 0, ''), -- Veron Amberstill
(12951, 0, 0, 'Don''t forget your totems!', 0, 0, ''), -- Aggra
(12950, 0, 0, 'Umm, Aggra... shouldn''t you be following Thrall?', 0, 0, ''), -- Aggra
(12943, 0, 0, 'I am prepared. Let us go to the Firelands and finish this.', 0, 0, ''), -- Aggra
(12940, 0, 0, 'Aggra, I am ready. Let us go to Thrall.', 0, 0, ''), -- Aggra
(12930, 0, 0, 'Aggra, I am ready to travel to Deepholm.', 0, 0, ''), -- Aggra
(12938, 0, 0, 'Aggra, I am ready to travel to the Abyssal Maw.', 0, 0, ''), -- Aggra
(12883, 0, 0, 'I am ready, elemental. Take me to Thrall.', 0, 0, ''), -- Cyclonas
(12985, 0, 0, 'I am ready to travel to Uldum, Aggra.', 0, 0, ''), -- Aggra
(12991, 0, 0, 'I am ready.', 0, 0, ''), -- Thrall
(10841, 0, 1, 'Let me browse your goods.', 0, 0, ''), -- Samantha Buckley
(12191, 4, 3, 'Train me in Herbalism.', 0, 0, ''), -- Jack "All-Trades" Derrington
(10834, 0, 3, 'I seek further training in the old ways of the druids.', 0, 0, ''), -- Celestine of the Harvest
(10696, 1, 3, 'I seek further training in the old ways of the druids.', 0, 0, ''), -- Celestine of the Harvest
(12539, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Talran of the Wild
(12609, 0, 0, 'I am ready.', 0, 0, ''), -- Admiral Nightwind
(11061, 0, 0, 'Let us take back our city!', 0, 0, ''), -- Krennan Aranas
(11079, 0, 0, 'I need a horse.', 0, 0, ''), -- Lord Hewell
(12799, 2, 0, 'How are we doing in the battle?', 0, 0, ''), -- Malfurion Stormrage
(12799, 4, 0, 'What are we building here?', 0, 0, ''), -- Malfurion Stormrage
(3161, 1, 1, 'I would like to buy from you.', 0, 0, ''), -- Ogunaro Wolfrunner
(12439, 0, 1, 'I would like to buy from you.', 0, 0, ''), -- Kall Worthaton
(9549, 1, 1, 'I''d like to buy this month''s brew.', 0, 0, ''), -- Brew Vendor
(12836, 0, 0, 'Present the Smoke-Stained Locket.', 0, 0, ''), -- -Unknown-
(11659, 0, 0, 'Nobody shorts Garrosh Hellscream. You finish those ships - and finish them right - or this gets personal.', 0, 0, ''), -- Bilgewater Foreman
(11654, 0, 0, 'Yes, a map of the coastal approaches.', 0, 0, ''), -- Herezegor Flametusk
(11653, 0, 0, 'The Dragonmaw can be great again. Help our conquest of the Twilight Highlands - can you give me a map?', 0, 0, ''), -- Herezegor Flametusk
(11807, 0, 0, 'So it''s true? Sauranok IS guilty of treason!', 0, 0, ''), -- Suspicious Peon
(11806, 0, 0, 'I know all about your cult master.', 0, 0, ''), -- Suspicious Peon
(11805, 0, 0, 'I didn''t say Twilight''s Hammer. YOU said Twilight''s Hammer.', 0, 0, ''), -- Suspicious Peon
(11804, 0, 0, 'Has a secret cult infiltrated the Orgrimmar skyway?', 0, 0, ''), -- Suspicious Peon
(11758, 0, 0, 'Fight with me! Take up this blade and be a warrior.', 0, 0, ''), -- Dragonmaw Merchant
(11758, 1, 0, 'Support and heal me! Take up this warhammer and be a shaman.', 0, 0, ''), -- Dragonmaw Merchant
(11757, 0, 0, 'Fight with me! Take up this blade and be a warrior.', 0, 0, ''), -- Dragonmaw Worker
(11757, 1, 0, 'Support and heal me! Take up this warhammer and be a shaman.', 0, 0, ''), -- Dragonmaw Worker
(11707, 0, 0, 'Our warriors are dying. Do you have medical supplies I can take back with me?', 0, 0, ''), -- Gregor
(11704, 0, 0, 'Can I get a ride back to the fleet?', 0, 0, ''), -- Ornak
(11691, 0, 0, 'Send me ashore, Horzog.', 0, 0, ''), -- Horzog
(12823, 0, 1, 'Let me browse your goods.', 0, 0, ''), -- Damek Bloombeard
(12979, 0, 0, 'Fascinating.', 0, 0, ''), -- Arthorn Windsong
(12897, 0, 0, 'What more can you tell me about these fire hawks?', 0, 0, ''), -- Arthorn Windsong
(12833, 0, 0, 'How do I get out of here?', 0, 0, ''), -- Thisalee Crow
(12790, 0, 0, 'What can you tell me about the Sentinel Tree, general?', 0, 0, ''), -- General Taldris Moonfall
(12911, 0, 0, 'Tell me about the ancient, Malorne.', 0, 0, ''), -- Matoclaw
(12914, 0, 0, 'How is Hamuul doing?', 0, 0, ''), -- Dorda'en Nightweaver
(10510, 0, 2, 'Show me where I can fly.', 0, 0, ''), -- Thraka
(10139, 0, 5, 'Make this inn your home.', 0, 0, ''), -- Uda the Beast
(12949, 1, 10, 'Let me see the items up for auction.', 0, 0, ''), -- Auctioneer Drezmit
(10202, 0, 5, 'Make this inn your home.', 0, 0, ''), -- Ajay Green
(10426, 1, 1, 'I want to browse your goods.', 0, 0, ''), -- Trellis Morningsun
(12762, 0, 0, 'I am prepared to face Nemesis, Tooga.', 0, 0, ''), -- Tooga
(12887, 0, 3, 'Train me.', 0, 0, ''), -- Armand Cromwell
(10942, 0, 0, 'What would you have of me, Banshee Queen?', 0, 0, ''), -- Lady Sylvanas Windrunner
(10988, 0, 3, 'I seek training in the ways of the Hunter.', 0, 0, ''), -- Ortezza
(10974, 0, 0, 'I''m ready to face my challenge.', 0, 0, ''), -- Darkspear Jailor
(2952, 0, 1, 'I would like to buy from you.', 0, 0, ''), -- Jeremiah Payson
(10767, 13, 0, 'Skinning', 0, 0, ''), -- Kor'kron Overseer
(10767, 14, 0, 'Tailoring', 0, 0, ''), -- Kor'kron Overseer
(13406, 0, 0, 'Teleport to the garden entrance.', 0, 0, ''), -- -Unknown-
(13406, 5, 0, 'Teleport to Azshara''s Palace.', 0, 0, ''), -- -Unknown-
(13406, 7, 0, 'Teleport to The Well of Eternity.', 0, 0, ''), -- -Unknown-
(13321, 0, 0, 'Entryway of Time', 0, 0, ''), -- -Unknown-
(13321, 1, 0, 'Ruby Dragonshrine', 0, 0, ''), -- -Unknown-
(13321, 9, 0, 'Bronze Dragonshrine', 0, 0, ''), -- -Unknown-
(12015, 0, 1, 'Do you have any supplies?', 0, 0, ''), -- D'lom the Collector
(12015, 1, 0, 'Can you repair equipment?', 0, 0, ''), -- D'lom the Collector
(13405, 0, 0, 'Teleport to the garden entrance.', 0, 0, ''), -- -Unknown-
(13405, 5, 0, 'Teleport to Azshara''s Palace.', 0, 0, ''), -- -Unknown-
(13183, 0, 0, 'Yes Thrall.', 0, 0, ''), -- Thrall
(10502, 0, 0, 'I need another Oracle Orphan Whistle.', 0, 0, ''), -- Orphan Matron Aria
(5849, 0, 0, 'Children''s Week is not yet over... may I have another Orphan Whistle?', 0, 0, ''), -- Orphan Matron Nightingale
(12761, 0, 1, 'Let me see what you have for sale.', 0, 0, ''), -- Snixx Quickfreeze
(9712, 0, 0, 'I''m ready to battle the dreadlord, sire.', 0, 0, ''), -- Arthas
(9696, 0, 0, 'For Lordaeron!', 0, 0, ''), -- Arthas
(9653, 0, 0, 'Yes, my Prince. We are ready.', 0, 0, ''), -- Arthas
(9612, 0, 0, 'Very well, Chromie.', 0, 0, ''), -- Chromie
(9611, 0, 0, 'You want me to do what?', 0, 0, ''), -- Chromie
(9610, 0, 0, 'What do you think they''re up to?', 0, 0, ''), -- Chromie
(9595, 0, 0, 'So how does the Infinite Dragonflight plan to interfere?', 0, 0, ''), -- Chromie
(9594, 0, 0, 'What was this decision?', 0, 0, ''), -- Chromie
(9586, 0, 0, 'Why have I been sent back to this particular place and time?', 0, 0, ''), -- Chromie
(9586, 2, 0, 'Chromie, you and I both know what''s going to happen in this time stream. We''ve seen this all before.$B$BCan you just skip us ahead to all the real action?', 0, 0, ''), -- Chromie
(13164, 0, 0, 'Lead the way.', 0, 0, ''), -- Thrall
(10389, 4, 0, 'Teleport to the Scrapyard.', 0, 0, ''), -- Ulduar Teleporter
(10389, 5, 0, 'Teleport to the Antechamber of Ulduar.', 0, 0, ''), -- Ulduar Teleporter
(10389, 6, 0, 'Teleport to the Shattered Walkway.', 0, 0, ''), -- Ulduar Teleporter
(10389, 10, 0, 'Teleport to the Conservatory of Life.', 0, 0, ''), -- Ulduar Teleporter
(10389, 12, 0, 'Teleport to the Spark of Imagination.', 0, 0, ''), -- Ulduar Teleporter
(10314, 0, 0, 'We are ready to help!', 0, 0, ''), -- Expedition Commander
(13075, 0, 0, 'Darkmoon Adventurer''s Guide?', 0, 0, ''), -- Selina Dourman
(13075, 1, 0, 'What can I purchase?', 0, 0, ''), -- Selina Dourman
(13075, 2, 0, 'Darkmoon Faire Prize Tickets?', 0, 0, ''), -- Selina Dourman
(13075, 3, 0, 'Darkmoon Cards?', 0, 0, ''), -- Selina Dourman
(13075, 4, 0, 'Attractions?', 0, 0, ''), -- Selina Dourman
(13124, 5, 0, 'Take me to the faire staging area.', 0, 3000, 'Travel to the faire staging area will cost:'), -- Darkmoon Faire Mystic Mage
(12795, 0, 0, 'What can you tell me about these spiders?', 0, 0, ''), -- Deldren Ravenelm
(13362, 0, 0, 'I am ready to help Thrall, back in my present time.', 0, 0, ''), -- Chromie
(11829, 0, 3, 'I seek training as a druid.', 0, 0, ''), -- Celestine of the Harvest
(11829, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Celestine of the Harvest
(12760, 0, 0, 'I am ready to meet with Anachronos, Ziradormi. ', 0, 0, ''), -- Ziradormi
(10614, 2, 0, 'I am ready.', 0, 0, ''), -- Jaeren Sunsworn
(10614, 0, 0, 'I am ready.', 0, 0, ''), -- Jaeren Sunsworn
(12939, 0, 0, 'Wait no longer, I''m ready to fight.', 0, 0, ''), -- Witherbranch
(13163, 0, 0, 'Let''s go!', 0, 0, ''), -- Illidan Stormrage
(13162, 0, 0, 'I am ready to be hidden by your shadowcloak.', 0, 0, ''), -- Illidan Stormrage
(8713, 0, 0, 'I''m ready, Akama.', 0, 0, ''), -- Akama
(12233, 0, 3, 'I am interested in mage training.', 0, 0, ''), -- Gija
(12233, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Gija
(12235, 0, 3, 'Please teach me.', 0, 0, ''), -- Rundok
(8031, 0, 1, 'I would like to buy from you.', 0, 0, ''), -- Provisioner Tsaalt
(13018, 0, 0, 'How do I play Whack-a-Gnoll?', 0, 0, ''), -- Mola
(13018, 2, 0, 'Ready to whack! |cFF0008E8(Darkmoon Game Token)|r', 0, 0, ''), -- Mola
(13065, 0, 0, 'I understand.', 0, 0, ''), -- Mola
(6183, 0, 1, 'Let me browse your goods.', 0, 0, ''), -- Gelvas Grimegate
(13012, 0, 0, 'How do I play the Ring Toss?', 0, 0, ''), -- Jessica Rogers
(13012, 2, 0, 'Ready to play! |cFF0008E8(Darkmoon Game Token)|r', 0, 0, ''), -- Jessica Rogers
(13013, 0, 0, 'I understand.', 0, 0, ''), -- Jessica Rogers
(6575, 2, 0, 'Launch me! |cFF0008E8(Darkmoon Game Token)|r', 0, 0, ''), -- Maxima Blastenheimer
(6574, 0, 0, 'I understand.', 0, 0, ''), -- Maxima Blastenheimer
(6225, 0, 0, 'How does the Shooting Gallery work?', 0, 0, ''), -- Rinling
(6225, 2, 0, 'Let''s shoot! |cFF0008E8(Darkmoon Game Token)|r', 0, 0, ''), -- Rinling
(13068, 0, 0, 'I understand.', 0, 0, ''), -- Rinling
(13019, 0, 0, 'How do I play the Tonk Challenge?', 0, 0, ''), -- Finlay Coolshot
(13019, 2, 0, 'Ready to play! |cFF0008E8(Darkmoon Game Token)|r', 0, 0, ''), -- Finlay Coolshot
(13066, 0, 0, 'I understand.', 0, 0, ''), -- Finlay Coolshot
(1971, 0, 0, 'Where is the zeppelin now?', 0, 0, ''), -- Zapetta
(9708, 0, 0, 'So where do we go from here?', 0, 0, ''), -- Belgaristrasz
(12974, 0, 0, 'Commander Shadowsong, what are the Marks of the World Tree?', 0, 0, ''), -- Commander Jarod Shadowsong
(8899, 0, 0, 'Please loan me that spyglass.', 0, 0, ''), -- Winterhoof Brave
(8908, 0, 0, 'I have misplaced my worg disguise.', 0, 0, ''), -- Sage Mistwalker
(9335, 0, 0, 'Ummm... the frog says you''re a traitor, \"matey.\"', 0, 0, ''), -- "Crowleg" Dan
(9013, 0, 0, '<Discreetly search the pirate''s pockets for Taruk''s payment.>', 0, 0, ''), -- Jack Adams
(9014, 0, 0, 'Here''s a gold, buy yourself something nice.', 0, 10000, 'Do you really want to bribe Olga?'), -- Olga, the Scalawag Wench
(9011, 0, 0, 'Pay up, Harry!', 0, 0, ''), -- "Silvermoon" Harry
(9011, 1, 1, 'Do you sell any of this stuff?', 0, 0, ''), -- "Silvermoon" Harry
(10218, 0, 0, '<Get in the bomber and return to Scalawag Point.>', 0, 0, ''), -- Harry's Bomber
(3923, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Kal
(6508, 0, 9, 'I wish to join the battle!', 0, 0, ''), -- Silverwing Emissary
(12981, 0, 0, 'I''m sorry to hear that.', 0, 0, ''), -- Deldren Ravenelm
(9568, 0, 0, 'We need to get into the fight. Are you ready?', 0, 0, ''), -- Wyrmrest Defender
(9461, 0, 0, 'Greetings High Chief. Would you do me the honor of accepting my invitation to join the Horde as an official member and leader of the Taunka?', 0, 0, ''), -- Roanauk Icemist
(9462, 0, 0, 'It is you who honor me, High Chief. Please read from this scroll. It is the oath of allegiance.', 0, 0, ''), -- Roanauk Icemist
(9459, 0, 3, 'Train me.', 0, 0, ''), -- Borus Ironbender
(9303, 0, 0, 'For the Horde!

Arm yourself from the crates that surround us and report to Agmar''s Hammer, east of here. Your first trial as a member of the Horde is to survive the journey.
Lok''tar ogar!', 0, 0, ''), -- Taunka'le Refugee
(9304, 0, 0, 'Then repeat after me: \"Lok''tar ogar! Victory or death - it is these words that bind me to the Horde. For they are the most sacred and fundamental of truths to any warrior of the Horde.
I give my flesh and blood freely to the Warchief. I am the instrument of my Warchief''s desire. I am a weapon of my Warchief''s command.
From this moment until the end of days I live and die - For the Horde!\"', 0, 0, ''), -- Taunka'le Refugee
(9305, 0, 0, 'Yes, taunka. Retribution is a given right of all members of the Horde.', 0, 0, ''), -- Taunka'le Refugee
(9302, 0, 0, 'Worry no more, taunka. The Horde will save and protect you and your people, but first you must swear allegiance to the Warchief by taking the blood oath of the Horde.', 0, 0, ''), -- Taunka'le Refugee
(9536, 0, 0, 'I am ready, your grace. <kiss the ring>', 0, 0, ''), -- High Abbot Landgren
(9532, 0, 0, 'Your eminence, may I have a word in private?', 0, 0, ''), -- High Abbot Landgren
(9507, 0, 0, 'I''m afraid not, Schneider. Your time has come!', 0, 0, ''), -- Deathguard Schneider
(9507, 1, 0, 'Can you tell me where they have Chancellor Amai caged?', 0, 0, ''), -- Deathguard Schneider
(9507, 2, 0, 'Where is Senior Scrivener Barriga being held?', 0, 0, ''), -- Deathguard Schneider
(9507, 3, 0, 'Did you see where they took Sanitation Engineer Burke?', 0, 0, ''), -- Deathguard Schneider
(9508, 0, 0, 'Not today, senior scrivener!', 0, 0, ''), -- Senior Scrivener Barriga
(9508, 1, 0, 'Can you tell me where they have Chancellor Amai caged?', 0, 0, ''), -- Senior Scrivener Barriga
(9508, 2, 0, 'Did you see where they took Sanitation Engineer Burke?', 0, 0, ''), -- Senior Scrivener Barriga
(9508, 3, 0, 'Any idea where they''re keeping Deathguard Schneider?', 0, 0, ''), -- Senior Scrivener Barriga
(9509, 0, 0, 'Afraid not. Your days as a sanitation engineer are coming to an end.', 0, 0, ''), -- Engineer Burke
(9509, 1, 0, 'Can you tell me where they have Chancellor Amai caged?', 0, 0, ''), -- Engineer Burke
(9509, 2, 0, 'Where is Senior Scrivener Barriga being held?', 0, 0, ''), -- Engineer Burke
(9509, 3, 0, 'Any idea where they''re keeping Deathguard Schneider?', 0, 0, ''), -- Engineer Burke
(9510, 0, 0, 'No, chancellor, I wouldn''t say that I''m here to ''rescue'' you, per se.', 0, 0, ''), -- Chancellor Amai
(9510, 1, 0, 'Where is Senior Scrivener Barriga being held?', 0, 0, ''), -- Chancellor Amai
(9510, 2, 0, 'Did you see where they took Sanitation Engineer Burke?', 0, 0, ''), -- Chancellor Amai
(9510, 3, 0, 'Any idea where they''re keeping Deathguard Schneider?', 0, 0, ''), -- Chancellor Amai
(9487, 0, 1, 'Let me browse your goods.', 0, 0, ''), -- Quartermaster Bartlett
(9497, 0, 0, 'Assume your druidic bear form, Tur.', 0, 0, ''), -- Tur Ragepaw
(9497, 1, 0, 'Help us subdue him.', 0, 0, ''), -- Tur Ragepaw
(9497, 2, 0, 'We could use a healer.', 0, 0, ''), -- Tur Ragepaw
(9496, 0, 0, 'We have the purified ashes of Vordrassil''s sapling.  If we can subdue Ursoc, we might be able to heal his soul.', 0, 0, ''), -- Tur Ragepaw
(9633, 0, 1, 'Let me browse your goods.', 0, 0, ''), -- Provisioner Lorkran
(10316, 3, 0, 'Glad to help, my lady. I''m told you were once the guardian of a fabled sword. Do you know where I might find it?', 0, 0, ''), -- Lake Frog
(12101, 2, 5, 'Make this inn your home.', 0, 0, ''), -- Provisioner Elda
(12101, 3, 1, 'Let me browse your goods.', 0, 0, ''), -- Provisioner Elda
(9848, 0, 1, 'Can you repair my gear?', 0, 0, ''), -- Engineer Reed
(9852, 0, 0, 'Gymer, where are Algar, Navarius and Thrym?', 0, 0, ''), -- Gymer
(9852, 1, 0, 'Gymer, what do I need to know? I''ve never ridden on a giant.', 0, 0, ''), -- Gymer
(9852, 2, 0, 'I''m ready, Gymer. Let''s go!', 0, 0, ''), -- Gymer
(11277, 0, 0, 'Yes, please!', 0, 0, ''), -- Chromie
(10274, 0, 0, 'Lift the icepaw bear''s tail to check if it''s a male or a female.', 0, 0, ''), -- Icepaw Bear
(10273, 0, 0, 'Lift the frost leopard''s tail to check if it''s a male or a female.', 0, 0, ''), -- Frost Leopard
(7706, 0, 0, 'I would be grateful for any aid you can provide, Priestess.', 0, 0, ''), -- Tyrande Whisperwind
(7581, 2, 0, 'Until we meet again, Thrall.', 0, 0, ''), -- Thrall
(7581, 0, 0, 'We have nothing to fear.', 0, 0, ''), -- Thrall
(7581, 1, 0, 'I am with you, Thrall.', 0, 0, ''), -- Thrall
(7552, 2, 0, 'Until we meet again, Lady Proudmoore.', 0, 0, ''), -- Lady Jaina Proudmoore
(7552, 1, 0, 'We are ready for whatever Archimonde might send our way, Lady Proudmoore.', 0, 0, ''), -- Lady Jaina Proudmoore
(7552, 0, 0, 'My companions and I are with you, Lady Proudmoore.', 0, 0, ''), -- Lady Jaina Proudmoore
(12641, 0, 3, 'Train me.', 0, 0, ''), -- Old Man Barlo
(9871, 0, 0, 'I''m not a laborer. I''m here to free you from servitude in the mines.', 0, 0, ''), -- Captive Mechagnome
(10124, 1, 0, 'I''m ready, Brann. Let''s make the keystone.', 0, 0, ''), -- Brann Bronzebeard
(10469, 2, 0, 'I am ready to fight!', 0, 0, ''), -- Sen'jin Valiant
(10470, 2, 0, 'I am ready to fight!', 0, 0, ''), -- Silvermoon Valiant
(10472, 2, 0, 'I am ready to fight!', 0, 0, ''), -- Thunder Bluff Valiant
(10340, 0, 0, 'I am ready to fight!', 0, 0, ''), -- Squire David
(9906, 0, 0, 'I am sorry to disturb your rest, chieftain, but your brother''s spirit may be in danger. Would you tell me what you remember of him?', 0, 0, ''), -- Chieftain Swiftspear
(10209, 0, 1, 'Let me browse your goods.', 0, 0, ''), -- Calder
(9928, 0, 0, 'I''m with you, Thorim.', 0, 0, ''), -- Thorim
(9899, 0, 0, 'I am ready to be shown the fate of Krolmir,', 0, 0, ''), -- King Jokkum
(12973, 0, 0, 'What happened during the War of the Ancients?', 0, 0, ''), -- Matoclaw
(12972, 0, 0, 'No, tell me more!', 0, 0, ''), -- Matoclaw
(12975, 0, 0, 'And why is that, exactly?', 0, 0, ''), -- Commander Jarod Shadowsong
(11384, 0, 20, 'Queue for The Frost Lord Ahune battle.', 0, 0, ''), -- Earthen Ring Scout
(12370, 1, 2, 'Show me where I can go.', 0, 0, ''), -- Swift Seahorse
(10468, 2, 0, 'I am ready to fight!', 0, 0, ''), -- Orgrimmar Valiant
(10206, 0, 0, 'There will be plenty of time for this later Brann, we need to get moving!', 0, 0, ''), -- Brann Bronzebeard
(9670, 0, 0, 'Let''s move Brann, enough of the history lesson!', 0, 0, ''), -- Brann Bronzebeard
(10473, 2, 0, 'I am ready to fight!', 0, 0, ''), -- Undercity Valiant
(10500, 0, 2, 'Show me where I can fly.', 0, 0, ''), -- Andruk
(9274, 0, 0, 'Lay your hand on the stone.', 0, 0, ''), -- Ice Stone
(9273, 0, 0, 'Lay your hand on the stone.', 0, 0, ''), -- Ice Stone
(11018, 0, 0, 'Teleport to Light''s Hammer.', 0, 0, ''), -- Scourge Transporter
(11018, 1, 0, 'Teleport to the Oratory of the Damned.', 0, 0, ''), -- Scourge Transporter
(11018, 3, 0, 'Teleport to the Rampart of Skulls.', 0, 0, ''), -- Scourge Transporter
(11018, 4, 0, 'Teleport to the Deathbringer''s Rise.', 0, 0, ''), -- Scourge Transporter
(11018, 5, 0, 'Teleport to the Upper Spire.', 0, 0, ''), -- Scourge Transporter
(11015, 0, 0, 'Teleport to Light''s Hammer.', 0, 0, ''), -- Scourge Transporter
(11015, 1, 0, 'Teleport to the Oratory of the Damned.', 0, 0, ''), -- Scourge Transporter
(11015, 4, 0, 'Teleport to the Deathbringer''s Rise.', 0, 0, ''), -- Scourge Transporter
(11015, 5, 0, 'Teleport to the Upper Spire.', 0, 0, ''), -- Scourge Transporter
(11015, 6, 0, 'Teleport to Sindragosa''s Lair.', 0, 0, ''), -- Scourge Transporter
(11016, 0, 0, 'Teleport to Light''s Hammer.', 0, 0, ''), -- Scourge Transporter
(11016, 1, 0, 'Teleport to the Oratory of the Damned.', 0, 0, ''), -- Scourge Transporter
(11016, 3, 0, 'Teleport to the Rampart of Skulls.', 0, 0, ''), -- Scourge Transporter
(11016, 5, 0, 'Teleport to the Upper Spire.', 0, 0, ''), -- Scourge Transporter
(11016, 6, 0, 'Teleport to Sindragosa''s Lair.', 0, 0, ''), -- Scourge Transporter
(11017, 6, 0, 'Teleport to Sindragosa''s Lair.', 0, 0, ''), -- Scourge Transporter
(11013, 6, 0, 'Teleport to Sindragosa''s Lair.', 0, 0, ''), -- Scourge Transporter
(11014, 0, 0, 'Teleport to Light''s Hammer.', 0, 0, ''), -- Scourge Transporter
(11014, 3, 0, 'Teleport to the Rampart of Skulls.', 0, 0, ''), -- Scourge Transporter
(11014, 4, 0, 'Teleport to the Deathbringer''s Rise.', 0, 0, ''), -- Scourge Transporter
(11014, 5, 0, 'Teleport to the Upper Spire.', 0, 0, ''), -- Scourge Transporter
(11014, 6, 0, 'Teleport to Sindragosa''s Lair.', 0, 0, ''), -- Scourge Transporter
(10383, 0, 0, 'Ask Cavin to summon the Black Knight.', 0, 0, ''), -- Squire Cavin
(10343, 3, 0, 'I am ready to fight!', 0, 0, ''), -- Squire Danny
(10602, 0, 9, 'I would like to go to the battleground.', 0, 0, ''), -- Isle of Conquest Envoy
(8749, 0, 0, 'I''m ready.  Take me to the Chamber of Command.', 0, 0, ''), -- Spirit of Udalo
(8750, 0, 0, 'I''m ready.  Take me to the Chamber of Command.', 0, 0, ''), -- Spirit of Olum
(8750, 1, 0, 'Take me to the other Deathsworn, Olum.', 0, 0, ''), -- Spirit of Olum
(8355, 0, 0, 'Control Summoned Daemon', 0, 0, ''), -- Summoned Daemon
(7443, 0, 0, 'Oh, grandmother, what phat lewts you have.', 0, 0, ''), -- Grandmother
(7442, 0, 0, 'Oh, grandmother, what big eyes you have.', 0, 0, ''), -- Grandmother
(7441, 0, 0, 'Oh, grandmother, what big ears you have.', 0, 0, ''), -- Grandmother
(7422, 0, 0, 'Ok, I''ll give it a try, then.', 0, 0, ''), -- Barnes
(7421, 0, 0, 'I''m not an actor.', 0, 0, ''), -- Barnes
(11877, 0, 3, 'I seek further druidic training to have a closer understanding of the Earth Mother''s will.', 0, 0, ''), -- Shalla Whiteleaf
(11877, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Shalla Whiteleaf
(3283, 7, 0, 'Warrior', 0, 0, ''), -- Razor Hill Grunt
(12046, 0, 3, 'Cooking', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12046, 1, 0, 'First Aid', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12046, 2, 3, 'Fishing', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12002, 0, 1, 'Access profession vending machine', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12002, 1, 0, 'I''d like to purchase primary profession training.', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12002, 2, 0, 'I''d like to purchase secondary profession training.', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 0, 3, 'Alchemy', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 1, 3, 'Blacksmithing', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 2, 3, 'Enchanting', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 3, 3, 'Engineering', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 4, 3, 'Herbalism', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 5, 3, 'Inscription', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 6, 3, 'Jewelcrafting', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 7, 3, 'Leatherworking', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 8, 3, 'Mining', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 9, 3, 'Skinning', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(12045, 10, 3, 'Tailoring', 0, 0, ''), -- KTC Train-a-Tron Deluxe
(11146, 0, 0, 'Get me up into the skies, Sassy!', 0, 0, ''), -- Sassy Hardwrench
(11082, 0, 0, 'Greely, why do the Super Booster Rocket Boots only work on the zombies?', 0, 0, ''), -- Assistant Greely
(11009, 0, 1, 'I would like to buy from you.', 0, 0, ''), -- Brett "Coins" McQuid
(11169, 0, 3, 'I am interested in warlock training.', 0, 0, ''), -- Evol Fingers
(11169, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Evol Fingers
(10722, 0, 6, 'Gobber, I need to look in my pack.', 0, 0, ''), -- Gobber
(10358, 1, 1, 'Visit a trader.', 0, 0, ''), -- Argent Gruntling
(10358, 3, 0, 'Darkspear Champion''s Pennant', 0, 0, ''), -- Argent Gruntling
(10358, 4, 0, 'Forsaken Champion''s Pennant', 0, 0, ''), -- Argent Gruntling
(10358, 5, 0, 'Orgrimmar Champion''s Pennant', 0, 0, ''), -- Argent Gruntling
(10358, 6, 0, 'Silvermoon Champion''s Pennant', 0, 0, ''), -- Argent Gruntling
(10358, 7, 0, 'Thunder Bluff Champion''s Pennant', 0, 0, ''), -- Argent Gruntling
(11244, 0, 0, 'Sassy, let''s set sail for Orgrimmar before the island blows for good!', 0, 0, ''), -- Sassy Hardwrench
(11248, 0, 6, 'Gobber, I need to look in my pack.', 0, 0, ''), -- Gobber
(11266, 0, 3, 'I am interested in warlock training.', 0, 0, ''), -- Evol Fingers
(11266, 1, 0, 'I wish to unlearn my talents.', 0, 0, ''), -- Evol Fingers
(8113, 0, 0, '<Begin emergency shutdown.>', 0, 0, ''), -- Coruu Control Console
(12646, 0, 0, 'Bring elevator to first floor.', 0, 0, ''), -- -Unknown-
(12646, 1, 0, 'Bring elevator to second floor.', 0, 0, ''), -- -Unknown-
(12890, 0, 0, 'What occasion brings you to our home town, drake?', 0, 0, ''), -- Blue Drake
(7949, 0, 5, 'Make this inn your home.', 0, 0, ''), -- Innkeeper Haelthol
(7949, 1, 1, 'Let me browse your goods.', 0, 0, ''), -- Innkeeper Haelthol
(11739, 0, 0, 'I''m ready when you are, Norsala.', 0, 0, ''), -- Earthmender Norsala
(10421, 0, 1, 'I want to browse your goods.', 0, 0, ''), -- Freka Bloodaxe
(10425, 0, 1, 'I want to browse your goods.', 0, 0, ''), -- Samamba
(7435, 0, 1, 'I''m in need of your skill as a blacksmith, Koren.', 0, 0, ''), -- Koren
(12271, 0, 0, 'Come on, let''s get out of here!', 0, 0, ''), -- Slave Worker
(5968, 0, 2, 'I need a ride.', 0, 0, ''), -- Grisha
(5968, 1, 0, 'I''m ready to take the flight into the Cauldron!', 0, 0, ''), -- Grisha
(12265, 0, 0, 'Care to join our dance?', 0, 0, ''), -- Iron Summit Guard
(12280, 0, 1, 'Think you could repair my gear, Burrian?', 0, 0, ''), -- Burrian Coalpart
(12541, 0, 0, 'Come little guy, let''s get out of here.', 0, 0, ''), -- Pebble
(13015, 0, 0, 'Yes Thrall.', 0, 0, ''), -- Thrall
(13356, 0, 0, 'I humbly request that the Dragon Aspects provide no aid to myself and my fellow adventurers. They should worry about their own problems, and we will worry about ours.', 0, 0, ''), -- Lord Afrasastrasz
(10677, 1, 0, 'Refresh my memory on the whole kaja''mite thing.', 0, 0, ''), -- Foreman Dampwick
(10550, 0, 3, 'I am interested in warlock training.', 0, 0, ''), -- Evol Fingers
(10826, 0, 3, 'Train me.', 0, 0, ''), -- Doc Zapnozzle
(10805, 0, 5, 'Make this inn your home.', 0, 0, ''), -- Grimy Greasefingers
(10805, 1, 0, 'What can I do at an inn?', 0, 0, ''), -- Grimy Greasefingers
(12494, 0, 0, 'Okay, Sassy, I''m ready to go.', 0, 0, ''), -- Sassy Hardwrench
(10681, 0, 3, 'I am interested in warlock training.', 0, 0, ''), -- Evol Fingers
(10903, 0, 1, 'Vinny, I just gotta get me a genuine Cataclysm souvenir!', 0, 0, ''), -- Vinny Slapchop
(10620, 0, 0, 'Set me up with the phattest, shiniest bling you got!', 0, 0, ''), -- Gappy Silvertooth
(10624, 0, 0, 'I need some cool shades. What will two stacks of macaroons get me?', 0, 0, ''), -- Missa Spekkies
(10622, 0, 0, 'Szabo, I need a hip, new outfit for the party I''m throwing!', 0, 0, ''), -- Szabo
(12193, 11, 3, 'Train me in Enchanting.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12193, 12, 0, 'Tell me about Tailoring.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12193, 13, 0, 'Tell me about gathering professions.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12193, 14, 0, 'Tell me about production professions.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12197, 11, 3, 'Train me in Jewelcrafting.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12197, 12, 0, 'Tell me about Mining.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12197, 13, 0, 'Tell me about gathering professions.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12197, 14, 0, 'Tell me about production professions.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12199, 11, 3, 'Train me in Tailoring.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12199, 12, 0, 'Tell me about Enchanting.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12199, 13, 0, 'Tell me about gathering professions.', 0, 0, ''), -- Jack "All-Trades" Derrington
(12199, 14, 0, 'Tell me about production professions.', 0, 0, ''), -- Jack "All-Trades" Derrington
(11794, 0, 1, 'Show me today''s selection of pies.', 0, 0, ''), -- Chris Moller
(11794, 1, 0, 'Why pie over cake?', 0, 0, ''), -- Chris Moller
(11795, 0, 0, 'I''ll keep that in mind.', 0, 0, ''), -- Chris Moller
(10842, 0, 1, 'Let me browse your goods.', 0, 0, ''); -- Gerard Walthorn

UPDATE `gossip_menu_option` SET `option_text`='|cFF0008E8NEW|r: Reforging' WHERE `menu_id`=435 AND `id`=0; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='|cFF0008E8NEW|r: Transmogrification' WHERE `menu_id`=435 AND `id`=1; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='|cFF0008E8NEW|r: Void Storage' WHERE `menu_id`=435 AND `id`=2; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Auction House' WHERE `menu_id`=435 AND `id`=3; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Bank' WHERE `menu_id`=435 AND `id`=4; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Barber' WHERE `menu_id`=435 AND `id`=5; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Class Trainer' WHERE `menu_id`=435 AND `id`=6; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Flight Master' WHERE `menu_id`=435 AND `id`=7; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Guild Master & Vendor' WHERE `menu_id`=435 AND `id`=8; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Inn' WHERE `menu_id`=435 AND `id`=9; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Mailbox' WHERE `menu_id`=435 AND `id`=10; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Points of Interest' WHERE `menu_id`=435 AND `id`=11; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Portals' WHERE `menu_id`=435 AND `id`=12; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Stable Master' WHERE `menu_id`=435 AND `id`=14; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Vendor' WHERE `menu_id`=435 AND `id`=15; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Archaeology' WHERE `menu_id`=421 AND `id`=1; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Blacksmithing' WHERE `menu_id`=421 AND `id`=2; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Cooking' WHERE `menu_id`=421 AND `id`=3; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Enchanting' WHERE `menu_id`=421 AND `id`=4; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Engineering' WHERE `menu_id`=421 AND `id`=5; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='First Aid' WHERE `menu_id`=421 AND `id`=6; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Fishing' WHERE `menu_id`=421 AND `id`=7; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Flying' WHERE `menu_id`=421 AND `id`=8; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Herbalism' WHERE `menu_id`=421 AND `id`=9; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Inscription' WHERE `menu_id`=421 AND `id`=10; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Jewelcrafting' WHERE `menu_id`=421 AND `id`=11; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Leatherworking' WHERE `menu_id`=421 AND `id`=12; -- Stormwind City Guard
UPDATE `gossip_menu_option` SET `option_text`='Archaeology' WHERE `menu_id`=2351 AND `id`=1; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_text`='Blacksmithing' WHERE `menu_id`=2351 AND `id`=2; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_text`='Cooking' WHERE `menu_id`=2351 AND `id`=3; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_text`='Enchanting' WHERE `menu_id`=2351 AND `id`=4; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_text`='Engineering' WHERE `menu_id`=2351 AND `id`=5; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_text`='First Aid' WHERE `menu_id`=2351 AND `id`=6; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_text`='Fishing' WHERE `menu_id`=2351 AND `id`=7; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_text`='Herbalism' WHERE `menu_id`=2351 AND `id`=8; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_text`='Inscription' WHERE `menu_id`=2351 AND `id`=9; -- Darnassus Sentinel
UPDATE `gossip_menu_option` SET `option_icon`=5, `option_text`='Make this inn your home.' WHERE `menu_id`=6620 AND `id`=0; -- Innkeeper Delaniel
UPDATE `gossip_menu_option` SET `option_icon`=1, `option_text`='I want to browse your goods.' WHERE `menu_id`=6620 AND `id`=1; -- Innkeeper Delaniel
UPDATE `gossip_menu_option` SET `option_text`='Hunter' WHERE `menu_id`=3354 AND `id`=0; -- Deathguard Cyrus
UPDATE `gossip_menu_option` SET `option_text`='Mage' WHERE `menu_id`=3354 AND `id`=1; -- Deathguard Cyrus
UPDATE `gossip_menu_option` SET `option_text`='Paladin' WHERE `menu_id`=3354 AND `id`=2; -- Deathguard Cyrus
UPDATE `gossip_menu_option` SET `option_text`='Priest' WHERE `menu_id`=3354 AND `id`=3; -- Deathguard Cyrus
UPDATE `gossip_menu_option` SET `option_text`='Rogue' WHERE `menu_id`=3354 AND `id`=4; -- Deathguard Cyrus
UPDATE `gossip_menu_option` SET `option_text`='Warlock' WHERE `menu_id`=3354 AND `id`=5; -- Deathguard Cyrus
UPDATE `gossip_menu_option` SET `option_text`='What can I do at an inn?' WHERE `menu_id`=1296 AND `id`=0; -- Innkeeper Renee
UPDATE `gossip_menu_option` SET `option_text`='What can I do at an inn?' WHERE `menu_id`=1291 AND `id`=0; -- Innkeeper Farley
UPDATE `gossip_menu_option` SET `option_icon`=1, `option_text`='I want to browse your goods.' WHERE `menu_id`=1291 AND `id`=2; -- Innkeeper Farley
UPDATE `gossip_menu_option` SET `option_icon`=5, `option_text`='Make this inn your home.' WHERE `menu_id`=7481 AND `id`=0; -- Caregiver Breel
UPDATE `gossip_menu_option` SET `option_icon`=1, `option_text`='I want to browse your goods.' WHERE `menu_id`=7481 AND `id`=1; -- Caregiver Breel
UPDATE `gossip_menu_option` SET `option_text`='Bank' WHERE `menu_id`=7777 AND `id`=1; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Guild Master & Vendor' WHERE `menu_id`=7777 AND `id`=3; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Inn' WHERE `menu_id`=7777 AND `id`=4; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Battlemasters' WHERE `menu_id`=7777 AND `id`=7; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Class Trainer' WHERE `menu_id`=7777 AND `id`=8; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Profession Trainer' WHERE `menu_id`=7777 AND `id`=9; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Reforging' WHERE `menu_id`=7777 AND `id`=10; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Archaeology' WHERE `menu_id`=7788 AND `id`=1; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Blacksmithing' WHERE `menu_id`=7788 AND `id`=2; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Enchanting' WHERE `menu_id`=7788 AND `id`=3; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Engineering' WHERE `menu_id`=7788 AND `id`=4; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='First Aid' WHERE `menu_id`=7788 AND `id`=5; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Fishing' WHERE `menu_id`=7788 AND `id`=6; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Herbalism' WHERE `menu_id`=7788 AND `id`=7; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Inscription' WHERE `menu_id`=7788 AND `id`=8; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Jewelcrafting' WHERE `menu_id`=7788 AND `id`=9; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Leatherworking' WHERE `menu_id`=7788 AND `id`=10; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Mining' WHERE `menu_id`=7788 AND `id`=11; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Skinning' WHERE `menu_id`=7788 AND `id`=12; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='Tailoring' WHERE `menu_id`=7788 AND `id`=13; -- Exodar Peacekeeper
UPDATE `gossip_menu_option` SET `option_text`='What can I do at an inn?' WHERE `menu_id`=7468 AND `id`=0; -- Caregiver Chellan
UPDATE `gossip_menu_option` SET `option_icon`=1, `option_text`='Let me browse your goods.' WHERE `menu_id`=7468 AND `id`=2; -- Caregiver Chellan
UPDATE `gossip_menu_option` SET `option_text`='Guild Master & Vendor' WHERE `menu_id`=8129 AND `id`=2; -- Azuremyst Peacekeeper
UPDATE `gossip_menu_option` SET `option_icon`=5, `option_text`='Make this inn your home.' WHERE `menu_id`=7288 AND `id`=0; -- Innkeeper Velandra
UPDATE `gossip_menu_option` SET `option_icon`=0 WHERE `menu_id`=7939 AND `id`=1; -- Amish Wildhammer
UPDATE `gossip_menu_option` SET `option_icon`=1, `option_text`='Let me browse your goods.' WHERE `menu_id`=10139 AND `id`=1; -- Uda the Beast
UPDATE `gossip_menu_option` SET `option_icon`=1, `option_text`='Let me browse your goods.' WHERE `menu_id`=10202 AND `id`=1; -- Ajay Green
UPDATE `gossip_menu_option` SET `option_text`='Archaeology' WHERE `menu_id`=10767 AND `id`=1; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Blacksmithing' WHERE `menu_id`=10767 AND `id`=2; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Cooking' WHERE `menu_id`=10767 AND `id`=3; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Enchanting' WHERE `menu_id`=10767 AND `id`=4; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Engineering' WHERE `menu_id`=10767 AND `id`=5; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='First Aid' WHERE `menu_id`=10767 AND `id`=6; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Fishing' WHERE `menu_id`=10767 AND `id`=7; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Herbalism' WHERE `menu_id`=10767 AND `id`=8; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Inscription' WHERE `menu_id`=10767 AND `id`=9; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Jewelcrafting' WHERE `menu_id`=10767 AND `id`=10; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Leatherworking' WHERE `menu_id`=10767 AND `id`=11; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Mining' WHERE `menu_id`=10767 AND `id`=12; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Auction House' WHERE `menu_id`=10769 AND `id`=0; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Bank' WHERE `menu_id`=10769 AND `id`=1; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Bat Handler' WHERE `menu_id`=10769 AND `id`=3; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Guild Master & Vendor' WHERE `menu_id`=10769 AND `id`=4; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Class Trainer' WHERE `menu_id`=10769 AND `id`=5; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Inn' WHERE `menu_id`=10769 AND `id`=6; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Mailbox' WHERE `menu_id`=10769 AND `id`=7; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Profession Trainer' WHERE `menu_id`=10769 AND `id`=8; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Stable Master' WHERE `menu_id`=10769 AND `id`=9; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Zeppelin Master' WHERE `menu_id`=10769 AND `id`=10; -- Kor'kron Overseer
UPDATE `gossip_menu_option` SET `option_text`='Stefan told me you would demonstrate the purpose of this item.' WHERE `menu_id`=9714 AND `id`=0; -- Bloodrose Datura
UPDATE `gossip_menu_option` SET `option_text`='Show me the drinks!' WHERE `menu_id`=6230 AND `id`=0; -- Sylannia
UPDATE `gossip_menu_option` SET `option_text`='How do I use the cannon?' WHERE `menu_id`=6575 AND `id`=0; -- Maxima Blastenheimer
UPDATE `gossip_menu_option` SET `option_text`='I want to fly on the wings of the bronze flight.' WHERE `menu_id`=9574 AND `id`=1; -- Eternos
UPDATE `gossip_menu_option` SET `option_text`='What abilities do amber drakes have?' WHERE `menu_id`=9574 AND `id`=4; -- Eternos
UPDATE `gossip_menu_option` SET `option_text`='I''d like to buy Jack a drink.  Perhaps something... extra strong.' WHERE `menu_id`=9015 AND `id`=0; -- Olga, the Scalawag Wench
UPDATE `gossip_menu_option` SET `option_text`='Calm down. I want to you ask you about the iron dwarves and Loken.' WHERE `menu_id`=9484 AND `id`=0; -- Hugh Glass
UPDATE `gossip_menu_option` SET `option_text`='Tell me more about using the Shield-Breaker.' WHERE `menu_id`=10402 AND `id`=1; -- Valis Windchaser
UPDATE `gossip_menu_option` SET `option_text`='Tell me more about Defend and Thrust.' WHERE `menu_id`=10398 AND `id`=1; -- Jeran Lockwood
UPDATE `gossip_menu_option` SET `option_text`='Tell me more about the Charge.' WHERE `menu_id`=10400 AND `id`=1; -- Rugan Steelbelly
UPDATE `gossip_menu_option` SET `option_text`='I have witnessed your magnificent operation, Drakuru. When do we put your plan into effect??' WHERE `menu_id`=9731 AND `id`=5; -- Overlord Drakuru
UPDATE `gossip_menu_option` SET `option_text`='Druid' WHERE `menu_id`=3283 AND `id`=0; -- Razor Hill Grunt
UPDATE `gossip_menu_option` SET `option_text`='Hunter' WHERE `menu_id`=3283 AND `id`=1; -- Razor Hill Grunt
UPDATE `gossip_menu_option` SET `option_text`='Mage' WHERE `menu_id`=3283 AND `id`=2; -- Razor Hill Grunt
UPDATE `gossip_menu_option` SET `option_text`='Priest' WHERE `menu_id`=3283 AND `id`=3; -- Razor Hill Grunt
UPDATE `gossip_menu_option` SET `option_text`='Rogue' WHERE `menu_id`=3283 AND `id`=4; -- Razor Hill Grunt
UPDATE `gossip_menu_option` SET `option_text`='Shaman' WHERE `menu_id`=3283 AND `id`=5; -- Razor Hill Grunt
UPDATE `gossip_menu_option` SET `option_text`='Warlock' WHERE `menu_id`=3283 AND `id`=6; -- Razor Hill Grunt
UPDATE `gossip_menu_option` SET `option_icon`=3 WHERE `menu_id`=8784 AND `id`=1; -- Kylene
