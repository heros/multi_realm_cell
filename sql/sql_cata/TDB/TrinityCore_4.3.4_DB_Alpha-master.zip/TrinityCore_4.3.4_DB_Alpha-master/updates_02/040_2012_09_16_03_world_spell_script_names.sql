DELETE FROM spell_script_names WHERE scriptName="spell_dru_savage_roar";
INSERT INTO spell_script_names (spell_id, ScriptName) VALUES
(52610, 'spell_dru_savage_roar');
