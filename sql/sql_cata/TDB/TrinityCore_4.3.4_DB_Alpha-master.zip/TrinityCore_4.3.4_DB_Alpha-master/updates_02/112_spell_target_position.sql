DELETE FROM `spell_target_position` WHERE `id` IN (65728, 65729);
INSERT INTO `spell_target_position` (`id`, `target_map`, `target_position_x`, `target_position_y`, `target_position_z`, `target_orientation`) VALUES
(65728, 0, -11708.4, -3168, -5.07, 3.35103), -- Portal Effect: Hellfire Peninsula, Alliance
(65729, 0, -11708.4, -3168, -5.07, 3.351032); -- Portal Effect: Hellfire Peninsula, Horde
