UPDATE `creature_template` SET `WDBVerified`=15595 WHERE `entry`=46325; -- Akhet
