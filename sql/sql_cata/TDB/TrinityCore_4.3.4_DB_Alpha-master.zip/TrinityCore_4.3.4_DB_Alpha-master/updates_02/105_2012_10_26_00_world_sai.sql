UPDATE `smart_scripts` SET `action_param3`=3500,`action_param4`=6000 WHERE `entryorguid`=9458 AND `source_type`=0 AND `id`=0;
