ALTER TABLE `item_template` CHANGE unk0 SoundOverrideSubclass tinyint(3) NOT NULL DEFAULT '-1';
