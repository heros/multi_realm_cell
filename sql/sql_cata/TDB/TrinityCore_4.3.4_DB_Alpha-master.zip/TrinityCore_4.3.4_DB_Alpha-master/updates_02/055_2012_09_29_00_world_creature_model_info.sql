-- VoA
UPDATE `creature_model_info` SET `bounding_radius`=0.3875,`combat_reach`=7.5 WHERE `modelid`=29524; -- Koralon
UPDATE `creature_model_info` SET `bounding_radius`=0.465,`combat_reach`=7.5 WHERE `modelid`=27108; -- Emalon
UPDATE `creature_model_info` SET `bounding_radius`=0.465,`combat_reach`=9 WHERE `modelid`=31089; -- Toravon
UPDATE `creature_model_info` SET `bounding_radius`=0.465,`combat_reach`=7.5 WHERE `modelid`=26967; -- Archavon

-- ToCr
UPDATE `creature_model_info` SET `bounding_radius`=1.085,`combat_reach`=10.5 WHERE `modelid`=29614; -- Gormok
UPDATE `creature_model_info` SET `bounding_radius`=1.55,`combat_reach`=5 WHERE `modelid`=29815; -- Acidmaw
UPDATE `creature_model_info` SET `bounding_radius`=1.24,`combat_reach`=12 WHERE `modelid`=24564; -- Dreadscale
UPDATE `creature_model_info` SET `bounding_radius`=4,`combat_reach`=14 WHERE `modelid`=21601; -- Icehowl
UPDATE `creature_model_info` SET `bounding_radius`=1.52778,`combat_reach`=5 WHERE `modelid`=29615; -- Jaraxxus
UPDATE `creature_model_info` SET `bounding_radius`=1.5,`combat_reach`=9 WHERE `modelid`=29267; -- Eydis Darkbane
UPDATE `creature_model_info` SET `bounding_radius`=1.5,`combat_reach`=9 WHERE `modelid`=29240; -- Fjola Lightbane
UPDATE `creature_model_info` SET `bounding_radius`=1.5,`combat_reach`=2.25 WHERE `modelid`=29773; -- Saamul
UPDATE `creature_model_info` SET `bounding_radius`=0.459,`combat_reach`=2.25 WHERE `modelid`=29774; -- Baelnor Lightbearer
UPDATE `creature_model_info` SET `bounding_radius`=0.312,`combat_reach`=2.25 WHERE `modelid`=29776; -- Irieth Shadowstep
UPDATE `creature_model_info` SET `bounding_radius`=0.52785,`combat_reach`=2.5875 WHERE `modelid`=29777; -- Serissa Grimdabbler
UPDATE `creature_model_info` SET `bounding_radius`=0.312,`combat_reach`=2.25 WHERE `modelid`=29778; -- Brienna Nightfell
UPDATE `creature_model_info` SET `bounding_radius`=1.5,`combat_reach`=2.25 WHERE `modelid`=29779; -- Shocuul
UPDATE `creature_model_info` SET `bounding_radius`=0.4511,`combat_reach`=2.6 WHERE `modelid`=29780; -- Melador Valestrider / Erin Misthoof
