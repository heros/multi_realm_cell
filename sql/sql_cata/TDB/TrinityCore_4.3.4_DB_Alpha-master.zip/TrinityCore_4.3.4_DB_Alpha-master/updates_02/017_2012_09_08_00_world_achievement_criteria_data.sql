DELETE FROM `achievement_criteria_data` WHERE `criteria_id` IN (10304,10313);
INSERT INTO `achievement_criteria_data` (`criteria_id`,`type`,`value1`,`value2`,`ScriptName`) VALUES
(10304,5,62320,0,''),
(10304,12,0,0,''),
(10313,5,62320,0,''),
(10313,12,1,0,'');
