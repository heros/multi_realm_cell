UPDATE `creature_loot_template` SET `item`=39657 WHERE `entry`=28546 AND `item`=36657;
