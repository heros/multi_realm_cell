UPDATE `smart_scripts` SET `event_param1` = 35282, `action_param1` = 256, `comment` = 'Scrapped Fel Reaver - On Spellhit - Remove - OOC Not attackable - flags'  WHERE `entryorguid` = 20243;
