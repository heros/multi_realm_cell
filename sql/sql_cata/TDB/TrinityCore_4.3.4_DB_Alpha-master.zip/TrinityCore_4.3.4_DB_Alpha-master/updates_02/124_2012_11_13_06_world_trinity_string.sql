DELETE FROM `trinity_string` WHERE `entry` IN (5018,5019);
UPDATE `trinity_string` SET `content_default`= '[Raid]' WHERE `entry`=5017;
