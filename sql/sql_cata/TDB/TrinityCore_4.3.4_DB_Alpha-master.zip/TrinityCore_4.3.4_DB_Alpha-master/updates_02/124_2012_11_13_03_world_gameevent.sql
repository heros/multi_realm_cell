-- Pilgrim's Bounty start time fix
UPDATE `game_event` SET `start_time`= '2012-11-18 01:00:00' WHERE `eventEntry`=26;
