UPDATE `gameobject_template` SET `flags`=40 WHERE `entry`=186371; -- Zeppelin
