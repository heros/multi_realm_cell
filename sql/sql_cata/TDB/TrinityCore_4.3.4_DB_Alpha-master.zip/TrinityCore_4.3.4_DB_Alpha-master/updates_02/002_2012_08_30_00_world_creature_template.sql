ALTER TABLE `creature_template` ADD `unit_flags2` int(10) UNSIGNED NOT NULL DEFAULT '0' AFTER `unit_flags`;
