UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'DeathKnight Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Druid Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Shaman Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Rogue Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Paladin Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Priest Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Warrior Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|32 WHERE `subname` LIKE 'Warlock Trainer';

UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Leatherworking Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Enchanting Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Profession Trainer%';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Tailoring Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Herbalism Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Mining Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Skinning Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Alchemy Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'BlackSmithing Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Engineering Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Inscription Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Jewelcrafting Trainer';

UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Archaeology Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Cooking Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'First Aid Trainer';
UPDATE `creature_template` SET `npcflag`=`npcflag`|16|64 WHERE `subname` LIKE 'Fishing Trainer';
