UPDATE `npc_text` SET `WDBVerified`=15595 WHERE `ID`=11136; -- 11136
UPDATE `npc_text` SET `WDBVerified`=15595 WHERE `ID`=11406; -- 11406
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12210; -- 12210
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12212; -- 12212
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12214; -- 12214
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12215; -- 12215
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12217; -- 12217
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12218; -- 12218
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12219; -- 12219
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12220; -- 12220
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=12930; -- 12930
UPDATE `npc_text` SET `em0_0`=2, `em0_1`=1, `em0_2`=0, `em0_3`=0, `em0_4`=2, `WDBVerified`=15595 WHERE `ID`=12216; -- 12216

UPDATE `gameobject_template` SET `WDBVerified`=15595 WHERE `entry`=21128; -- Orc Spy Report
