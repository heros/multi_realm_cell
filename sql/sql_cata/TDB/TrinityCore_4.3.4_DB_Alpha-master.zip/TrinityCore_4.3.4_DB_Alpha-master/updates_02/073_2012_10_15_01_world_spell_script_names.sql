UPDATE `spell_script_names` SET `spell_id`=755 WHERE `spell_id`=-755;
UPDATE `spell_script_names` SET `spell_id`=1535 WHERE `spell_id`=-1535;
