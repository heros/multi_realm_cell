UPDATE `creature_template` SET `gossip_menu_id`=4470 WHERE `entry`=928; -- Lord Grayson Shadowbreaker
UPDATE `creature_template` SET `gossip_menu_id`=4470 WHERE `entry`=5492; -- Katherine the Pure
UPDATE `creature_template` SET `gossip_menu_id`=4470 WHERE `entry`=5491; -- Arthur the Faithful
