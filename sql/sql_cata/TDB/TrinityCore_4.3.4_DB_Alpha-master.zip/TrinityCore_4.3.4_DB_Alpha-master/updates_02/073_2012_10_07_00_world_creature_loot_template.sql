-- increase droprate for Plump Buzzard Wing
UPDATE `creature_loot_template` SET `chanceOrQuestChance`=-50 WHERE `item`=23239;
