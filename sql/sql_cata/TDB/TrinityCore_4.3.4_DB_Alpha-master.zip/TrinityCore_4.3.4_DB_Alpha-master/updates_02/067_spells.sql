UPDATE `creature_template` SET `spell4`=74183 WHERE `entry`=39710; -- -Unknown-
UPDATE `creature_template` SET `spell4`=0, `spell6`=62324 WHERE `entry`=33109; -- Salvaged Demolisher
UPDATE `creature_template` SET `spell2`=75070, `spell4`=97395 WHERE `entry`=52682; -- -Unknown-
UPDATE `creature_template` SET `spell2`=66541 WHERE `entry`=34944; -- Keep Cannon
UPDATE `creature_template` SET `spell1`=99588, `spell2`=99706, `spell6`=99674 WHERE `entry`=53300; -- -Unknown-
UPDATE `creature_template` SET `spell1`=97240 WHERE `entry`=52597; -- -Unknown-
UPDATE `creature_template` SET `spell1`=96212 WHERE `entry`=27894; -- Antipersonnel Cannon
UPDATE `creature_template` SET `spell1`=93604, `spell2`=93593 WHERE `entry`=52988; -- -Unknown-
UPDATE `creature_template` SET `spell1`=92733 WHERE `entry`=49680; -- -Unknown-
UPDATE `creature_template` SET `spell1`=91571, `spell2`=91574 WHERE `entry`=49135; -- -Unknown-
UPDATE `creature_template` SET `spell1`=89786 WHERE `entry`=48283; -- -Unknown-
UPDATE `creature_template` SET `spell1`=88496 WHERE `entry`=47467; -- -Unknown-
UPDATE `creature_template` SET `spell1`=85188, `spell2`=92721, `spell3`=92728 WHERE `entry`=51083; -- -Unknown-
UPDATE `creature_template` SET `spell1`=84971, `spell3`=84974 WHERE `entry`=45344; -- -Unknown-
UPDATE `creature_template` SET `spell1`=74922, `spell2`=74974 WHERE `entry`=52676; -- -Unknown-
UPDATE `creature_template` SET `spell1`=73998, `spell2`=73994, `spell3`=73997 WHERE `entry`=39598; -- -Unknown-
UPDATE `creature_template` SET `spell1`=73456, `spell2`=73477 WHERE `entry`=39074; -- -Unknown-
UPDATE `creature_template` SET `spell1`=72246, `spell5`=72849 WHERE `entry`=38540; -- -Unknown-
UPDATE `creature_template` SET `spell1`=72206 WHERE `entry`=38526; -- -Unknown-
UPDATE `creature_template` SET `spell1`=72051 WHERE `entry`=38377; -- -Unknown-
UPDATE `creature_template` SET `spell1`=72013 WHERE `entry`=38424; -- -Unknown-
UPDATE `creature_template` SET `spell1`=70735, `spell2`=70732, `spell4`=59737 WHERE `entry`=37927; -- -Unknown-
UPDATE `creature_template` SET `spell1`=68903 WHERE `entry`=36540; -- -Unknown-
UPDATE `creature_template` SET `spell1`=68659 WHERE `entry`=36283; -- -Unknown-
UPDATE `creature_template` SET `spell1`=67794 WHERE `entry`=35178; -- -Unknown-
UPDATE `creature_template` SET `spell1`=67461, `spell2`=66203 WHERE `entry`=36355; -- Siege Turret
UPDATE `creature_template` SET `spell1`=66529 WHERE `entry`=34935; -- Horde Gunship Cannon
UPDATE `creature_template` SET `spell1`=66186, `spell2`=66183 WHERE `entry`=36356; -- Flame Turret
UPDATE `creature_template` SET `spell1`=50348, `spell2`=55987, `spell3`=50430 WHERE `entry`=27996; -- Wyrmrest Vanquisher
UPDATE `creature_template` SET `spell1`=49161, `spell2`=49243, `spell3`=49263, `spell4`=49264, `spell6`=49367 WHERE `entry`=27629; -- Wyrmrest Defender
UPDATE `creature_template` SET `spell1`=48619, `spell2`=48620, `spell3`=52812 WHERE `entry`=56914; -- -Unknown-
