UPDATE `creature_template` SET `gossip_menu_id`=10619 WHERE `entry`=35126; -- Gappy Silvertooth
UPDATE `creature_template` SET `gossip_menu_id`=10620 WHERE `entry`=35126; -- Gappy Silvertooth
UPDATE `creature_template` SET `gossip_menu_id`=10621 WHERE `entry`=35128; -- Szabo
UPDATE `creature_template` SET `gossip_menu_id`=10622 WHERE `entry`=35128; -- Szabo
UPDATE `creature_template` SET `gossip_menu_id`=10623 WHERE `entry`=35130; -- Missa Spekkies
UPDATE `creature_template` SET `gossip_menu_id`=10624 WHERE `entry`=35130; -- Missa Spekkies
UPDATE `creature_template` SET `gossip_menu_id`=10632 WHERE `entry`=35207; -- Ace
UPDATE `creature_template` SET `gossip_menu_id`=10633 WHERE `entry`=35209; -- Gobber
UPDATE `creature_template` SET `gossip_menu_id`=10634 WHERE `entry`=35210; -- Izzy
UPDATE `creature_template` SET `gossip_menu_id`=10636 WHERE `entry`=35238; -- Kezan Partygoer
UPDATE `creature_template` SET `gossip_menu_id`=10697 WHERE `entry`=44461; -- Huntsman Blake
UPDATE `creature_template` SET `gossip_menu_id`=10698 WHERE `entry`=44465; -- Myriam Spellwaker
UPDATE `creature_template` SET `gossip_menu_id`=10699 WHERE `entry`=44464; -- Loren the Fence
UPDATE `creature_template` SET `gossip_menu_id`=10702 WHERE `entry`=44469; -- Vitus Darkwalker
UPDATE `creature_template` SET `gossip_menu_id`=10708 WHERE `entry`=35917; -- Kilag Gorefang
UPDATE `creature_template` SET `gossip_menu_id`=10722 WHERE `entry`=38746; -- Gobber
UPDATE `creature_template` SET `gossip_menu_id`=10823 WHERE `entry`=35769; -- Foreman Dampwick
UPDATE `creature_template` SET `gossip_menu_id`=10826 WHERE `entry`=36615; -- Doc Zapnozzle
UPDATE `creature_template` SET `gossip_menu_id`=10834 WHERE `entry`=38799; -- Celestine of the Harvest
UPDATE `creature_template` SET `gossip_menu_id`=10835 WHERE `entry`=38798; -- Huntsman Blake
UPDATE `creature_template` SET `gossip_menu_id`=10837 WHERE `entry`=36631; -- Myriam Spellwaker
UPDATE `creature_template` SET `gossip_menu_id`=10837 WHERE `entry`=38465; -- Myriam Spellwaker
UPDATE `creature_template` SET `gossip_menu_id`=10837 WHERE `entry`=38794; -- Myriam Spellwaker
UPDATE `creature_template` SET `gossip_menu_id`=10838 WHERE `entry`=38795; -- Sister Almyra
UPDATE `creature_template` SET `gossip_menu_id`=10840 WHERE `entry`=38797; -- Vitus Darkwalker
UPDATE `creature_template` SET `gossip_menu_id`=10841 WHERE `entry`=38783; -- Marie Allen
UPDATE `creature_template` SET `gossip_menu_id`=10841 WHERE `entry`=42853; -- Karen Murray
UPDATE `creature_template` SET `gossip_menu_id`=10841 WHERE `entry`=43558; -- Marie Allen
UPDATE `creature_template` SET `gossip_menu_id`=10843 WHERE `entry`=38796; -- Loren the Fence
UPDATE `creature_template` SET `gossip_menu_id`=10965 WHERE `entry`=38120; -- Hobart Grapplehammer
UPDATE `creature_template` SET `gossip_menu_id`=11045, `faction_A`=2231, `faction_H`=2231 WHERE `entry`=38122; -- Bamm Megabomb
UPDATE `creature_template` SET `gossip_menu_id`=11046, `faction_A`=2231, `faction_H`=2231 WHERE `entry`=38513; -- Evol Fingers
UPDATE `creature_template` SET `gossip_menu_id`=11047, `faction_A`=2231, `faction_H`=2231 WHERE `entry`=38514; -- Fizz Lighter
UPDATE `creature_template` SET `gossip_menu_id`=11049, `faction_A`=2231, `faction_H`=2231 WHERE `entry`=38515; -- Maxx Avalanche
UPDATE `creature_template` SET `gossip_menu_id`=11050, `faction_A`=2231, `faction_H`=2231 WHERE `entry`=38516; -- Sister Goldskimmer
UPDATE `creature_template` SET `gossip_menu_id`=11051, `faction_A`=2231, `faction_H`=2231 WHERE `entry`=38517; -- Slinky Sharpshiv
UPDATE `creature_template` SET `gossip_menu_id`=11052, `faction_A`=2231, `faction_H`=2231 WHERE `entry`=38518; -- Warrior-Matic NX-01
UPDATE `creature_template` SET `gossip_menu_id`=11074 WHERE `entry`=38738; -- Coach Crosscheck
UPDATE `creature_template` SET `gossip_menu_id`=11078 WHERE `entry`=38647; -- Izzy
UPDATE `creature_template` SET `gossip_menu_id`=11079 WHERE `entry`=38764; -- Lord Hewell
UPDATE `creature_template` SET `gossip_menu_id`=11142 WHERE `entry`=38935; -- Thrall
UPDATE `creature_template` SET `gossip_menu_id`=11226, `minlevel`=80, `maxlevel`=80, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39427; -- Jadi Falaryn
UPDATE `creature_template` SET `gossip_menu_id`=11289, `minlevel`=80, `maxlevel`=80, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39640; -- Kristoff Manheim
UPDATE `creature_template` SET `gossip_menu_id`=11306, `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `speed_run`=1.385714, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=39927; -- Laina Nightsky
UPDATE `creature_template` SET `gossip_menu_id`=11313 WHERE `entry`=40983; -- Mack Fearsen
UPDATE `creature_template` SET `gossip_menu_id`=11314 WHERE `entry`=39883; -- Adarrah
UPDATE `creature_template` SET `gossip_menu_id`=11316, `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=39933; -- Tyrus Blackhorn
UPDATE `creature_template` SET `gossip_menu_id`=11319, `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=39928; -- Matoclaw
UPDATE `creature_template` SET `gossip_menu_id`=11327, `minlevel`=83, `maxlevel`=83, `npcflag`=3, `speed_run`=1.428571, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33024, `unit_flags2`=0 WHERE `entry`=41324; -- Private Pollard
UPDATE `creature_template` SET `gossip_menu_id`=11344 WHERE `entry`=39876; -- Felora Firewreath
UPDATE `creature_template` SET `gossip_menu_id`=11352 WHERE `entry`=39882; -- The Great Sambino
UPDATE `creature_template` SET `gossip_menu_id`=11399, `minlevel`=82, `maxlevel`=82, `faction_A`=2167, `faction_H`=2167, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=16384 WHERE `entry`=40221; -- Toshe Chaosrender
UPDATE `creature_template` SET `gossip_menu_id`=11400 WHERE `entry`=39875; -- Earthmender Duarn
UPDATE `creature_template` SET `gossip_menu_id`=11442, `minlevel`=80, `maxlevel`=80, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=39667; -- Adarrah
UPDATE `creature_template` SET `gossip_menu_id`=11444 WHERE `entry`=39669; -- Captain Samir
UPDATE `creature_template` SET `gossip_menu_id`=11454 WHERE `entry`=41006; -- Thisalee Crow
UPDATE `creature_template` SET `gossip_menu_id`=11470, `minlevel`=85, `maxlevel`=85, `faction_A`=2233, `faction_H`=2233, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=512 WHERE `entry`=40997; -- Skylord Omnuron
UPDATE `creature_template` SET `gossip_menu_id`=11474, `minlevel`=82, `maxlevel`=82, `faction_A`=1733, `faction_H`=1733, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=256 WHERE `entry`=40643; -- Admiral Dvorek
UPDATE `creature_template` SET `gossip_menu_id`=11477, `minlevel`=82, `maxlevel`=82, `faction_A`=1733, `faction_H`=1733, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=16384 WHERE `entry`=41535; -- Engineer Hexascrub
UPDATE `creature_template` SET `gossip_menu_id`=11477, `unit_flags`=16640 WHERE `entry`=40639; -- Engineer Hexascrub
UPDATE `creature_template` SET `gossip_menu_id`=11478, `minlevel`=80, `maxlevel`=80, `faction_A`=2167, `faction_H`=2167, `npcflag`=3, `speed_run`=0.9920629, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=40105; -- Erunak Stonespeaker
UPDATE `creature_template` SET `gossip_menu_id`=11481, `minlevel`=82, `maxlevel`=82, `faction_A`=2261, `faction_H`=2261, `npcflag`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=537149952, `unit_flags2`=2049 WHERE `entry`=41281; -- Injured Assault Volunteer
UPDATE `creature_template` SET `gossip_menu_id`=11489, `minlevel`=83, `maxlevel`=83, `npcflag`=3, `speed_run`=1.428571, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=0 WHERE `entry`=41340; -- Private Pollard
UPDATE `creature_template` SET `gossip_menu_id`=11515, `minlevel`=81, `maxlevel`=81, `faction_A`=1770, `faction_H`=1770, `npcflag`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=33556480 WHERE `entry`=42072; -- Fathom-Lord Zin'jatar
UPDATE `creature_template` SET `gossip_menu_id`=11516, `minlevel`=80, `maxlevel`=80, `faction_A`=1770, `faction_H`=1770, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=33556480 WHERE `entry`=41455; -- Overseer Idra'kess
UPDATE `creature_template` SET `gossip_menu_id`=11517, `minlevel`=81, `maxlevel`=81, `faction_A`=1770, `faction_H`=1770, `npcflag`=1, `speed_run`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32832, `unit_flags2`=33556480 WHERE `entry`=42071; -- Lady Sira'kess
UPDATE `creature_template` SET `gossip_menu_id`=11522, `minlevel`=81, `maxlevel`=81, `faction_A`=2167, `faction_H`=2167, `npcflag`=65667, `speed_run`=0.9920629, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=41341; -- Erunak Stonespeaker
UPDATE `creature_template` SET `gossip_menu_id`=11525, `minlevel`=82, `maxlevel`=82, `faction_A`=2167, `faction_H`=2167, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768, `unit_flags2`=34816 WHERE `entry`=41531; -- Earthmender Duarn
UPDATE `creature_template` SET `gossip_menu_id`=11530 WHERE `entry`=39433; -- Ian Duran
UPDATE `creature_template` SET `gossip_menu_id`=11538 WHERE `entry`=39878; -- Caretaker Movra
UPDATE `creature_template` SET `gossip_menu_id`=11546, `minlevel`=82, `maxlevel`=82, `faction_A`=2252, `faction_H`=2252, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=41005; -- Choluna
UPDATE `creature_template` SET `gossip_menu_id`=11553 WHERE `entry`=41871; -- Earthwatcher Komo
UPDATE `creature_template` SET `gossip_menu_id`=11554 WHERE `entry`=41878; -- Earthwatcher Faldor
UPDATE `creature_template` SET `gossip_menu_id`=11568, `faction_A`=2231, `faction_H`=2231 WHERE `entry`=42473; -- Grimy Greasefingers
UPDATE `creature_template` SET `gossip_menu_id`=11572, `minlevel`=81, `maxlevel`=81, `faction_A`=1770, `faction_H`=1770, `npcflag`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32832, `unit_flags2`=33556480 WHERE `entry`=41980; -- Fathom-Caller Azrajar
UPDATE `creature_template` SET `gossip_menu_id`=11598, `minlevel`=82, `maxlevel`=82, `faction_A`=1733, `faction_H`=1733, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=256 WHERE `entry`=41540; -- Captain Taylor
UPDATE `creature_template` SET `gossip_menu_id`=11599, `minlevel`=82, `maxlevel`=82, `faction_A`=1733, `faction_H`=1733, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=256 WHERE `entry`=41541; -- Admiral Dvorek
UPDATE `creature_template` SET `gossip_menu_id`=11601, `minlevel`=82, `maxlevel`=82, `faction_A`=2167, `faction_H`=2167, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=256 WHERE `entry`=41802; -- Wavespeaker Valoren
UPDATE `creature_template` SET `gossip_menu_id`=11608 WHERE `entry`=39226; -- Farseer Gadra
UPDATE `creature_template` SET `gossip_menu_id`=11639 WHERE `entry`=42573; -- Earthcaller Yevaa
UPDATE `creature_template` SET `gossip_menu_id`=11641 WHERE `entry`=42574; -- Initiate Goldmine
UPDATE `creature_template` SET `gossip_menu_id`=11647, `minlevel`=82, `maxlevel`=82, `faction_A`=2167, `faction_H`=2167, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=39881; -- Wavespeaker Valoren
UPDATE `creature_template` SET `gossip_menu_id`=11660, `minlevel`=83, `maxlevel`=83, `faction_A`=2289, `faction_H`=2289, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32832 WHERE `entry`=42730; -- Earthcaller Torunscar
UPDATE `creature_template` SET `gossip_menu_id`=11683 WHERE `entry`=42467; -- Diamant the Patient
UPDATE `creature_template` SET `gossip_menu_id`=11694 WHERE `entry`=43168; -- Gravel Longslab
UPDATE `creature_template` SET `gossip_menu_id`=11695 WHERE `entry`=43169; -- Clay Mudaxle
UPDATE `creature_template` SET `gossip_menu_id`=11722 WHERE `entry`=42684; -- Stormcaller Mylra
UPDATE `creature_template` SET `gossip_menu_id`=11725 WHERE `entry`=43319; -- Earthmender Deepvein
UPDATE `creature_template` SET `gossip_menu_id`=11746 WHERE `entry`=42472; -- Gorsik the Tumultuous
UPDATE `creature_template` SET `gossip_menu_id`=11773 WHERE `entry`=43897; -- Pyrium Lodestone
UPDATE `creature_template` SET `gossip_menu_id`=11774, `minlevel`=83, `maxlevel`=83, `npcflag`=3, `speed_run`=0.9920629, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=256 WHERE `entry`=43898; -- Flint Oremantle
UPDATE `creature_template` SET `gossip_menu_id`=11800 WHERE `entry`=44143; -- Slate Quicksand
UPDATE `creature_template` SET `gossip_menu_id`=11872, `npcflag`=1 WHERE `entry`=44646; -- Earthcaller Yevaa
UPDATE `creature_template` SET `gossip_menu_id`=11873, `minlevel`=83, `maxlevel`=83, `faction_A`=2167, `faction_H`=2167, `npcflag`=1, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32832 WHERE `entry`=43836; -- Windspeaker Lorvarius
UPDATE `creature_template` SET `gossip_menu_id`=11873, `npcflag`=1 WHERE `entry`=44631; -- Tharm Wildfire
UPDATE `creature_template` SET `gossip_menu_id`=11914, `minlevel`=88, `maxlevel`=88, `faction_A`=2286, `faction_H`=2286, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2 WHERE `entry`=44025; -- Therazane
UPDATE `creature_template` SET `gossip_menu_id`=11916 WHERE `entry`=45043; -- Peak Grindstone
UPDATE `creature_template` SET `gossip_menu_id`=11929, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=44860; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=11945 WHERE `entry`=43397; -- Seer Kormo
UPDATE `creature_template` SET `gossip_menu_id`=11967, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=48034; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=11967, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=45180; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12036 WHERE `entry`=45168; -- Fargo Flintlocke
UPDATE `creature_template` SET `gossip_menu_id`=12037, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=45296; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12046 WHERE `entry`=45286; -- KTC Train-a-Tron Deluxe
UPDATE `creature_template` SET `gossip_menu_id`=12058 WHERE `entry`=45874; -- Schnottz Scout
UPDATE `creature_template` SET `gossip_menu_id`=12062 WHERE `entry`=45169; -- Lieutenant Emry
UPDATE `creature_template` SET `gossip_menu_id`=12070, `minlevel`=85, `maxlevel`=85, `faction_A`=2328, `faction_H`=2328, `npcflag`=3, `speed_run`=1.857143, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=33536 WHERE `entry`=45528; -- Calen
UPDATE `creature_template` SET `gossip_menu_id`=12083, `minlevel`=85, `maxlevel`=85, `faction_A`=12, `faction_H`=12, `npcflag`=1, `speed_run`=1.357143, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=4, `unit_flags`=33536 WHERE `entry`=46076; -- SI:7 Squad Commander
UPDATE `creature_template` SET `gossip_menu_id`=12098, `minlevel`=85, `maxlevel`=85, `faction_A`=12, `faction_H`=12, `npcflag`=3, `baseattacktime`=1000, `rangeattacktime`=2000, `unit_class`=4, `unit_flags`=33536 WHERE `entry`=45796; -- Master Mathias Shaw
UPDATE `creature_template` SET `gossip_menu_id`=12113, `minlevel`=85, `maxlevel`=85, `faction_A`=2337, `faction_H`=2337, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280, `unit_flags2`=0 WHERE `entry`=46174; -- Cayden Dunwald
UPDATE `creature_template` SET `gossip_menu_id`=12118 WHERE `entry`=46338; -- Budd
UPDATE `creature_template` SET `gossip_menu_id`=12122, `minlevel`=81, `maxlevel`=81, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=46458; -- Budd
UPDATE `creature_template` SET `gossip_menu_id`=12123, `minlevel`=81, `maxlevel`=81, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=46463; -- Budd
UPDATE `creature_template` SET `gossip_menu_id`=12139, `minlevel`=85, `maxlevel`=85, `faction_A`=2337, `faction_H`=2337, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=46175; -- Eoin Dunwald
UPDATE `creature_template` SET `gossip_menu_id`=12141, `minlevel`=85, `maxlevel`=85, `faction_A`=2337, `faction_H`=2337, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33024 WHERE `entry`=46143; -- Flynn Dunwald
UPDATE `creature_template` SET `gossip_menu_id`=12142, `minlevel`=85, `maxlevel`=85, `faction_A`=2337, `faction_H`=2337, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33024 WHERE `entry`=46177; -- Keely Dunwald
UPDATE `creature_template` SET `gossip_menu_id`=12143, `minlevel`=85, `maxlevel`=85, `faction_A`=2337, `faction_H`=2337, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33024 WHERE `entry`=46628; -- Flynn Dunwald
UPDATE `creature_template` SET `gossip_menu_id`=12159 WHERE `entry`=46805; -- Iain Firebeard
UPDATE `creature_template` SET `gossip_menu_id`=12160 WHERE `entry`=46804; -- Keegan Firebeard
UPDATE `creature_template` SET `gossip_menu_id`=12164 WHERE `entry`=46939; -- Mullan Gryphon
UPDATE `creature_template` SET `gossip_menu_id`=12165 WHERE `entry`=46968; -- Mullan Gryphon
UPDATE `creature_template` SET `gossip_menu_id`=12169 WHERE `entry`=47005; -- Adarrah
UPDATE `creature_template` SET `gossip_menu_id`=12170, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=34816 WHERE `entry`=46978; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12180, `npcflag`=1 WHERE `entry`=50247; -- Jack "All-Trades" Derrington
UPDATE `creature_template` SET `gossip_menu_id`=1221 WHERE `entry`=36496; -- Grimy Greasefingers
UPDATE `creature_template` SET `gossip_menu_id`=12212, `speed_walk`=1, `speed_run`=1.142857 WHERE `entry`=47176; -- Ambassador Laurent
UPDATE `creature_template` SET `gossip_menu_id`=12213, `minlevel`=85, `maxlevel`=85, `faction_A`=190, `faction_H`=190, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=768 WHERE `entry`=47159; -- Commander Schnottz
UPDATE `creature_template` SET `gossip_menu_id`=12227 WHERE `entry`=47195; -- Slate Quicksand
UPDATE `creature_template` SET `gossip_menu_id`=12239 WHERE `entry`=47318; -- Mack
UPDATE `creature_template` SET `gossip_menu_id`=12287 WHERE `entry`=47516; -- Prolific Writer
UPDATE `creature_template` SET `gossip_menu_id`=12291 WHERE `entry`=47519; -- Privileged Socialite
UPDATE `creature_template` SET `gossip_menu_id`=12300, `speed_walk`=1, `speed_run`=1.142857, `rangeattacktime`=2000 WHERE `entry`=47670; -- Belloc Brightblade
UPDATE `creature_template` SET `gossip_menu_id`=12303 WHERE `entry`=47592; -- Master Mathias Shaw
UPDATE `creature_template` SET `gossip_menu_id`=12316 WHERE `entry`=47520; -- Pretentious Businessman
UPDATE `creature_template` SET `gossip_menu_id`=12319, `npcflag`=1 WHERE `entry`=47707; -- Budding Artist
UPDATE `creature_template` SET `gossip_menu_id`=12354, `minlevel`=85, `maxlevel`=85, `faction_A`=190, `faction_H`=190, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=768, `unit_flags2`=32768 WHERE `entry`=47940; -- Commander Schnottz
UPDATE `creature_template` SET `gossip_menu_id`=12357 WHERE `entry`=46603; -- Nomarch Teneth
UPDATE `creature_template` SET `gossip_menu_id`=12360 WHERE `entry`=47930; -- Asaq
UPDATE `creature_template` SET `gossip_menu_id`=12362 WHERE `entry`=47902; -- Lirastrasza
UPDATE `creature_template` SET `gossip_menu_id`=12363 WHERE `entry`=47959; -- Prince Nadun
UPDATE `creature_template` SET `gossip_menu_id`=12369, `minlevel`=80, `maxlevel`=80, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=768 WHERE `entry`=47967; -- Prolific Writer
UPDATE `creature_template` SET `gossip_menu_id`=12378, `minlevel`=84, `maxlevel`=84, `faction_A`=2339, `faction_H`=2339, `npcflag`=3, `speed_run`=1.357143, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768, `unit_flags2`=34816 WHERE `entry`=48175; -- Low Shaman Blundy
UPDATE `creature_template` SET `gossip_menu_id`=12379, `minlevel`=84, `maxlevel`=84, `faction_A`=2339, `faction_H`=2339, `npcflag`=3, `speed_run`=1.357143, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33024 WHERE `entry`=48013; -- Fanny Thundermar
UPDATE `creature_template` SET `gossip_menu_id`=12386 WHERE `entry`=44806; -- Fargo Flintlocke
UPDATE `creature_template` SET `gossip_menu_id`=12388, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=48082; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12399, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=48162; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12402, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=48186; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12403, `minlevel`=85, `maxlevel`=85, `faction_A`=190, `faction_H`=190, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=768, `unit_flags2`=0 WHERE `entry`=47972; -- Commander Schnottz
UPDATE `creature_template` SET `gossip_menu_id`=12405, `speed_walk`=1, `speed_run`=0.8571429 WHERE `entry`=48203; -- Sullah
UPDATE `creature_template` SET `gossip_menu_id`=12407, `minlevel`=84, `maxlevel`=84, `faction_A`=12, `faction_H`=12, `npcflag`=3, `speed_run`=1.357143, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=48174; -- Nivvet Channelock
UPDATE `creature_template` SET `gossip_menu_id`=12408 WHERE `entry`=48237; -- Salhet
UPDATE `creature_template` SET `gossip_menu_id`=12409, `minlevel`=85, `maxlevel`=85, `faction_A`=2339, `faction_H`=2339, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=48173; -- Colin Thundermar
UPDATE `creature_template` SET `gossip_menu_id`=12425, `minlevel`=85, `maxlevel`=85, `faction_A`=2339, `faction_H`=2339, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=48365; -- Kurdran Wildhammer
UPDATE `creature_template` SET `gossip_menu_id`=12427, `minlevel`=85, `maxlevel`=85, `faction_A`=2339, `faction_H`=2339, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=48472; -- Colin Thundermar
UPDATE `creature_template` SET `gossip_menu_id`=12441, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=48528; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12444, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags2`=34816 WHERE `entry`=48558; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12446, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=48621; -- Sullah
UPDATE `creature_template` SET `gossip_menu_id`=12450, `minlevel`=85, `maxlevel`=85, `npcflag`=3, `speed_run`=0.8571429, `baseattacktime`=2000, `rangeattacktime`=2000 WHERE `entry`=48698; -- Harrison Jones
UPDATE `creature_template` SET `gossip_menu_id`=12480, `minlevel`=85, `maxlevel`=85, `faction_A`=2339, `faction_H`=2339, `npcflag`=3, `speed_run`=1.357143, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=48368; -- Grundy MacGraff
UPDATE `creature_template` SET `gossip_menu_id`=12501, `minlevel`=85, `maxlevel`=85, `faction_A`=2328, `faction_H`=2328, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33536 WHERE `entry`=49417; -- Lirastrasza
UPDATE `creature_template` SET `gossip_menu_id`=12562, `minlevel`=84, `maxlevel`=84, `faction_A`=1078, `faction_H`=1078, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_flags`=33280, `unit_flags2`=0 WHERE `entry`=50049; -- Jack Bauden
UPDATE `creature_template` SET `gossip_menu_id`=12568 WHERE `entry`=50270; -- Captain Taylor
UPDATE `creature_template` SET `gossip_menu_id`=12571 WHERE `entry`=40825; -- Erunak Stonespeaker
UPDATE `creature_template` SET `gossip_menu_id`=12572 WHERE `entry`=38514; -- Fizz Lighter
UPDATE `creature_template` SET `gossip_menu_id`=12576 WHERE `entry`=38513; -- Evol Fingers
UPDATE `creature_template` SET `gossip_menu_id`=12578, `speed_walk`=1, `speed_run`=2.428571 WHERE `entry`=46750; -- Fusion Core
UPDATE `creature_template` SET `gossip_menu_id`=12597, `minlevel`=82, `maxlevel`=82, `npcflag`=3, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=41003; -- Morthis Whisperwing
UPDATE `creature_template` SET `gossip_menu_id`=12603 WHERE `entry`=40644; -- Levia Dreamwaker
UPDATE `creature_template` SET `gossip_menu_id`=12613 WHERE `entry`=40139; -- Captain Saynna Stormrunner
UPDATE `creature_template` SET `gossip_menu_id`=12640 WHERE `entry`=48564; -- King Phaoris
UPDATE `creature_template` SET `gossip_menu_id`=12678, `npcflag`=3, `rangeattacktime`=2000, `unit_flags`=32768 WHERE `entry`=49248; -- Brann Bronzebeard
UPDATE `creature_template` SET `gossip_menu_id`=5665 WHERE `entry`=50570; -- Whilsey Bottomtooth
UPDATE `creature_template` SET `gossip_menu_id`=7809 WHERE `entry`=39884; -- Captain Samir
UPDATE `creature_template` SET `gossip_menu_id`=9821 WHERE `entry`=45298; -- Mule Driver Ironshod
UPDATE `creature_template` SET `gossip_menu_id`=9821, `minlevel`=81, `maxlevel`=81, `faction_A`=2252, `faction_H`=2252, `npcflag`=129, `baseattacktime`=2000, `rangeattacktime`=2000, `unit_class`=2, `unit_flags`=32768 WHERE `entry`=43494; -- Oltarin Graycloud
