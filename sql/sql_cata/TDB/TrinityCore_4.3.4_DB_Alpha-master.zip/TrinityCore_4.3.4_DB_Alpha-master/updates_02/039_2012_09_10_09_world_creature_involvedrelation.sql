/* 4.x disabled
DELETE FROM creature_involvedrelation WHERE quest IN (25500, 25286);
INSERT INTO creature_involvedrelation (id, quest) VALUES
(39675, 25500),
(39675, 25286);
*/