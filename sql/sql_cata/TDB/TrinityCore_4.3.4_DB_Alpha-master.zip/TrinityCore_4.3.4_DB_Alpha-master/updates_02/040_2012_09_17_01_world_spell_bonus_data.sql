DELETE FROM `spell_bonus_data` WHERE `entry` = 61840;
INSERT INTO `spell_bonus_data` (`entry`,`direct_bonus`, `dot_bonus`,`ap_bonus`,`ap_dot_bonus`,`comments`) VALUES
(61840, 0, 0, 0, 0, 'No bonus for Righteous Vengance DoT');
