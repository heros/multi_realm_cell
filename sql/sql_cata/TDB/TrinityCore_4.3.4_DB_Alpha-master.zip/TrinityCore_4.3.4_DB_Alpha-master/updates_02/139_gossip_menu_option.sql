UPDATE `gossip_menu_option` SET `option_id`=6, `npc_option_npcflag`=16385 WHERE `menu_id`=83;
