UPDATE `creature_model_info` SET `combat_reach`=2.125 WHERE `modelid`=833;
UPDATE `creature_model_info` SET `combat_reach`=3.5 WHERE `modelid`=1988;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=3233;
UPDATE `creature_model_info` SET `combat_reach`=0.25 WHERE `modelid`=16259;
UPDATE `creature_model_info` SET `combat_reach`=1.65 WHERE `modelid`=19744;
UPDATE `creature_model_info` SET `combat_reach`=0.9 WHERE `modelid`=20833;
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=21270;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=23337;
UPDATE `creature_model_info` SET `combat_reach`=1.125 WHERE `modelid`=23514;
UPDATE `creature_model_info` SET `combat_reach`=0.9 WHERE `modelid`=23519;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=24607;
UPDATE `creature_model_info` SET `combat_reach`=1.65 WHERE `modelid`=24916;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25166;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25594;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=25602;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25603;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25607;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25608;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25609;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25623;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25649;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25655;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25673;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25674;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=25791;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25806;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25807;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25875;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25877;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25878;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25879;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25880;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25882;
UPDATE `creature_model_info` SET `combat_reach`=1.65 WHERE `modelid`=25947;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=25983;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26067;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26068;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26069;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26072;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26073;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26138;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26299;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26307;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26309;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26310;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26311;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26312;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26313;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26321;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26335;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26347;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26373;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26377;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26395;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26396;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=26437;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26438;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26440;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26441;
UPDATE `creature_model_info` SET `combat_reach`=0.75 WHERE `modelid`=26442;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26463;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26464;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26465;
UPDATE `creature_model_info` SET `combat_reach`=0.2 WHERE `modelid`=26517;
UPDATE `creature_model_info` SET `combat_reach`=0.2 WHERE `modelid`=26518;
UPDATE `creature_model_info` SET `combat_reach`=0.2 WHERE `modelid`=26519;
UPDATE `creature_model_info` SET `combat_reach`=0.2 WHERE `modelid`=26521;
UPDATE `creature_model_info` SET `combat_reach`=0.3125 WHERE `modelid`=26524;
UPDATE `creature_model_info` SET `combat_reach`=0.4 WHERE `modelid`=26526;
UPDATE `creature_model_info` SET `combat_reach`=0.15 WHERE `modelid`=26530;
UPDATE `creature_model_info` SET `combat_reach`=0.15 WHERE `modelid`=26531;
UPDATE `creature_model_info` SET `combat_reach`=0.15 WHERE `modelid`=26547;
UPDATE `creature_model_info` SET `combat_reach`=0.1 WHERE `modelid`=26557;
UPDATE `creature_model_info` SET `bounding_radius`=2 WHERE `modelid`=26759;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26779;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=26997;
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=27060;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27068;
UPDATE `creature_model_info` SET `combat_reach`=1.65 WHERE `modelid`=27216;
UPDATE `creature_model_info` SET `combat_reach`=1.65 WHERE `modelid`=27217;
UPDATE `creature_model_info` SET `bounding_radius`=1 WHERE `modelid`=27243;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27287;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27333;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27398;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27449;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27509;
UPDATE `creature_model_info` SET `combat_reach`=1.8 WHERE `modelid`=27592;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=27657;
UPDATE `creature_model_info` SET `combat_reach`=0.3 WHERE `modelid`=27718;
UPDATE `creature_model_info` SET `combat_reach`=0.375 WHERE `modelid`=27719;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27766;
UPDATE `creature_model_info` SET `combat_reach`=1.35 WHERE `modelid`=27820;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27822;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27912;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27915;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27952;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27954;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27956;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27958;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27962;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=27998;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=28143;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=28144;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28147;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28148;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28149;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28150;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28153;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28154;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28156;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28159;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=28160;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28161;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28164;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=28165;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=28167;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28168;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28169;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28170;
UPDATE `creature_model_info` SET `combat_reach`=3.75 WHERE `modelid`=28183;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28194;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28202;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28203;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28204;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=28208;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=28432;
UPDATE `creature_model_info` SET `combat_reach`=1.25 WHERE `modelid`=28618;
UPDATE `creature_model_info` SET `combat_reach`=1.65 WHERE `modelid`=29076;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29834;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29835;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=29836;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30311;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=30358;
UPDATE `creature_model_info` SET `combat_reach`=1.725 WHERE `modelid`=30686;
UPDATE `creature_model_info` SET `combat_reach`=1.5 WHERE `modelid`=30764;
UPDATE `creature_model_info` SET `bounding_radius`=0.612, `combat_reach`=3, `gender`=0 WHERE `modelid`=30802;
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=35704;
UPDATE `creature_model_info` SET `bounding_radius`=0.383, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=37403;



DELETE FROM `npc_text` WHERE `ID`=17336;
INSERT INTO `npc_text` (`ID`, `text0_0`, `text0_1`, `lang0`, `prob0`, `em0_0`, `em0_1`, `em0_2`, `em0_3`, `em0_4`, `em0_5`, `text1_0`, `text1_1`, `lang1`, `prob1`, `em1_0`, `em1_1`, `em1_2`, `em1_3`, `em1_4`, `em1_5`, `text2_0`, `text2_1`, `lang2`, `prob2`, `em2_0`, `em2_1`, `em2_2`, `em2_3`, `em2_4`, `em2_5`, `text3_0`, `text3_1`, `lang3`, `prob3`, `em3_0`, `em3_1`, `em3_2`, `em3_3`, `em3_4`, `em3_5`, `text4_0`, `text4_1`, `lang4`, `prob4`, `em4_0`, `em4_1`, `em4_2`, `em4_3`, `em4_4`, `em4_5`, `text5_0`, `text5_1`, `lang5`, `prob5`, `em5_0`, `em5_1`, `em5_2`, `em5_3`, `em5_4`, `em5_5`, `text6_0`, `text6_1`, `lang6`, `prob6`, `em6_0`, `em6_1`, `em6_2`, `em6_3`, `em6_4`, `em6_5`, `text7_0`, `text7_1`, `lang7`, `prob7`, `em7_0`, `em7_1`, `em7_2`, `em7_3`, `em7_4`, `em7_5`, `WDBVerified`) VALUES
(17336, 'The high elf mage and scholar Dariness is the city''s most learned archaeologist... and the most sociable.$B$BShe can often be found in the Legerdemain Lounge, just north of the city''s center, enjoying the atmosphere or discussing her wild adventures with the proprieters and patrons both.', 'The high elf mage and scholar Dariness is the city''s most learned archaeologist... and the most sociable.$B$BShe can often be found in the Legerdemain Lounge, just north of the city''s center, enjoying the atmosphere or discussing her wild adventures with the proprieters and patrons both.', 0, 1, 1, 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 15595); -- 17336

UPDATE `npc_text` SET `em0_0`=2, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14013; -- 14013
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13976; -- 13976
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13961; -- 13961
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13960; -- 13960
UPDATE `npc_text` SET `text0_0`='There is a well in northern Dalaran that some of the city''s more... adventurous... visitors use to enter the sewers.', `text0_1`='There is a well in northern Dalaran that some of the city''s more... adventurous... visitors use to enter the sewers.', `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13969; -- 13969
UPDATE `npc_text` SET `prob0`=0, `em0_0`=1, `em0_1`=0, `text1_0`='I will mark the location upon your map.', `text1_1`='I will mark the location upon your map.', `prob1`=1, `em1_0`=396, `WDBVerified`=15595 WHERE `ID`=14010; -- 14010
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14007; -- 14007
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14005; -- 14005
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14006; -- 14006
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13974; -- 13974
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14003; -- 14003
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13977; -- 13977
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13973; -- 13973
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13972; -- 13972
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14004; -- 14004
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14015; -- 14015
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14002; -- 14002
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13992; -- 13992
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13993; -- 13993
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14251; -- 14251
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14008; -- 14008
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14009; -- 14009
UPDATE `npc_text` SET `em0_0`=6, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13975; -- 13975
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13971; -- 13971
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13970; -- 13970
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13980; -- 13980
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13968; -- 13968
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13967; -- 13967
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13966; -- 13966
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13965; -- 13965
UPDATE `npc_text` SET `WDBVerified`=15595 WHERE `ID`=14174; -- 14174
UPDATE `npc_text` SET `em0_0`=6, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14000; -- 14000
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13999; -- 13999
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13998; -- 13998
UPDATE `npc_text` SET `em0_0`=6, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13996; -- 13996
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13995; -- 13995
UPDATE `npc_text` SET `text0_0`='There is a large smithy and forge in the Magus Commerce Exchange, northwest Dalaran.$B$BLook for the massive enchanted anvil and stained glass windows in the shapes of axes and shields.', `text0_1`='There is a large smithy and forge in the Magus Commerce Exchange, northwest Dalaran.$B$BLook for the massive enchanted anvil and stained glass windows in the shapes of axes and shields.', `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13994; -- 13994
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13991; -- 13991
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13990; -- 13990
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13989; -- 13989
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13988; -- 13988
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13987; -- 13987
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14001; -- 14001
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13986; -- 13986
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13985; -- 13985
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13984; -- 13984
UPDATE `npc_text` SET `text0_0`='Skinners and leatherworkers of all sorts may be found at Legendary Leathers in the Magus Commerce Exchange, northwest Dalaran.', `text0_1`='Skinners and leatherworkers of all sorts may be found at Legendary Leathers in the Magus Commerce Exchange, northwest Dalaran.', `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13982; -- 13982
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13983; -- 13983
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=13981; -- 13981
UPDATE `npc_text` SET `em0_0`=6, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14117; -- 14117
UPDATE `npc_text` SET `em0_0`=6, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14114; -- 14114
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14112; -- 14112
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14111; -- 14111
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14109; -- 14109
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14108; -- 14108
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14107; -- 14107
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14106; -- 14106
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14105; -- 14105
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14103; -- 14103
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14102; -- 14102
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14104; -- 14104
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14100; -- 14100
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14101; -- 14101
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14110; -- 14110
UPDATE `npc_text` SET `em0_0`=6, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14113; -- 14113
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14098; -- 14098
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14097; -- 14097
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14096; -- 14096
UPDATE `npc_text` SET `em0_0`=1, `em0_1`=0, `WDBVerified`=15595 WHERE `ID`=14095; -- 14095
UPDATE `npc_text` SET `WDBVerified`=15595 WHERE `ID`=15921; -- 15921

DELETE FROM `gossip_menu_option` WHERE `menu_id` IN (10043, 10057, 10092, 10089, 10085, 10058, 10086, 10095, 10084, 10262, 10090, 10083, 10173, 10056, 10082);

DELETE FROM `gossip_menu_option` WHERE (`menu_id`=10082 AND `id`=0) OR (`menu_id`=10082 AND `id`=5) OR (`menu_id`=10078 AND `id`=14) OR (`menu_id`=10073 AND `id`=0) OR (`menu_id`=10073 AND `id`=1) OR (`menu_id`=10160 AND `id`=0) OR (`menu_id`=10160 AND `id`=1) OR (`menu_id`=10153 AND `id`=0);
INSERT INTO `gossip_menu_option` (`menu_id`, `id`, `option_icon`, `option_text`, `box_coded`, `box_money`, `box_text`) VALUES
(10082, 0, 0, 'Class Trainer', 0, 0, ''), -- Whirt the All-Knowing
(10082, 5, 0, 'Profession Trainer', 0, 0, ''), -- Whirt the All-Knowing
(10078, 14, 0, 'Tailoring', 0, 0, ''), -- Whirt the All-Knowing
(10073, 0, 0, 'Alliance Inn', 0, 0, ''), -- Whirt the All-Knowing
(10073, 1, 0, 'Horde Inn', 0, 0, ''), -- Whirt the All-Knowing
(10160, 0, 0, 'The Alliance Quarter', 0, 0, ''), -- Whirt the All-Knowing
(10160, 1, 0, 'The Horde Quarter', 0, 0, ''), -- Whirt the All-Knowing
(10153, 0, 0, 'Profession Trainer', 0, 0, ''); -- Whirt the All-Knowing

UPDATE `gossip_menu_option` SET `option_text`='Flight Master' WHERE `menu_id`=10043 AND `id`=5; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Guild Master & Vendor' WHERE `menu_id`=10043 AND `id`=6; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Inn' WHERE `menu_id`=10043 AND `id`=7; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Locksmith' WHERE `menu_id`=10043 AND `id`=8; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Mailbox' WHERE `menu_id`=10043 AND `id`=9; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Points of Interest' WHERE `menu_id`=10043 AND `id`=10; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Stable Master' WHERE `menu_id`=10043 AND `id`=11; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Trainers' WHERE `menu_id`=10043 AND `id`=12; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Vendors' WHERE `menu_id`=10043 AND `id`=13; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Cold Weather Flying Trainer' WHERE `menu_id`=10082 AND `id`=3; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Portal Trainer' WHERE `menu_id`=10082 AND `id`=4; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Archaeology' WHERE `menu_id`=10078 AND `id`=1; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Blacksmithing' WHERE `menu_id`=10078 AND `id`=2; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Cooking' WHERE `menu_id`=10078 AND `id`=3; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Enchanting' WHERE `menu_id`=10078 AND `id`=4; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Engineering' WHERE `menu_id`=10078 AND `id`=5; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='First Aid' WHERE `menu_id`=10078 AND `id`=6; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Fishing' WHERE `menu_id`=10078 AND `id`=7; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Herbalism' WHERE `menu_id`=10078 AND `id`=8; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Inscription' WHERE `menu_id`=10078 AND `id`=9; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Jewelcrafting' WHERE `menu_id`=10078 AND `id`=10; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Leatherworking' WHERE `menu_id`=10078 AND `id`=11; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Mining' WHERE `menu_id`=10078 AND `id`=12; -- Whirt the All-Knowing
UPDATE `gossip_menu_option` SET `option_text`='Skinning' WHERE `menu_id`=10078 AND `id`=13; -- Whirt the All-Knowing
