UPDATE `creature_model_info` SET `bounding_radius`=0.005, `combat_reach`=0.01, `gender`=2 WHERE `modelid`=13069; -- 13069
UPDATE `creature_model_info` SET `bounding_radius`=0.031, `combat_reach`=0.25 WHERE `modelid`=33547; -- 33547
UPDATE `creature_model_info` SET `bounding_radius`=0.075, `combat_reach`=0.15 WHERE `modelid`=24719; -- 24719
UPDATE `creature_model_info` SET `bounding_radius`=0.1085, `combat_reach`=0.35 WHERE `modelid`=36872; -- 36872
UPDATE `creature_model_info` SET `bounding_radius`=0.1125, `combat_reach`=1.5 WHERE `modelid`=36303; -- 36303
UPDATE `creature_model_info` SET `bounding_radius`=0.125, `combat_reach`=0.25 WHERE `modelid`=17188; -- 17188
UPDATE `creature_model_info` SET `bounding_radius`=0.15, `combat_reach`=1.25 WHERE `modelid`=35677; -- 35677
UPDATE `creature_model_info` SET `bounding_radius`=0.19375, `combat_reach`=4.375 WHERE `modelid`=39094; -- 39094
UPDATE `creature_model_info` SET `bounding_radius`=0.235, `combat_reach`=1 WHERE `modelid`=4626; -- 4626
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5 WHERE `modelid`=31210; -- 31210
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33344; -- 33344
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33345; -- 33345
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=33628; -- 33628
UPDATE `creature_model_info` SET `bounding_radius`=0.236, `combat_reach`=1.5, `gender`=1 WHERE `modelid`=35230; -- 35230
UPDATE `creature_model_info` SET `bounding_radius`=0.2392, `combat_reach`=1.725, `gender`=1 WHERE `modelid`=34364; -- 34364
UPDATE `creature_model_info` SET `bounding_radius`=0.25 WHERE `modelid`=38705; -- 38705
UPDATE `creature_model_info` SET `bounding_radius`=0.2596, `combat_reach`=1.65, `gender`=1 WHERE `modelid`=38692; -- 38692
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5 WHERE `modelid`=15894; -- 15894
UPDATE `creature_model_info` SET `bounding_radius`=0.306, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=37419; -- 37419
UPDATE `creature_model_info` SET `bounding_radius`=0.31, `combat_reach`=1.5 WHERE `modelid`=37757; -- 37757
UPDATE `creature_model_info` SET `bounding_radius`=0.312, `combat_reach`=2.25 WHERE `modelid`=29045; -- 29045
UPDATE `creature_model_info` SET `bounding_radius`=0.35, `combat_reach`=20 WHERE `modelid`=14992; -- 14992
UPDATE `creature_model_info` SET `bounding_radius`=0.35, `combat_reach`=4 WHERE `modelid`=29539; -- 29539
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=32596; -- 32596
UPDATE `creature_model_info` SET `bounding_radius`=0.3519, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=34365; -- 34365
UPDATE `creature_model_info` SET `bounding_radius`=0.3672, `combat_reach`=1.8, `gender`=1 WHERE `modelid`=38062; -- 38062
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33260; -- 33260
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33261; -- 33261
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33264; -- 33264
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33350; -- 33350
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33351; -- 33351
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33352; -- 33352
UPDATE `creature_model_info` SET `bounding_radius`=0.372, `combat_reach`=1.5, `gender`=0 WHERE `modelid`=33437; -- 33437
UPDATE `creature_model_info` SET `bounding_radius`=0.3993053, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=33296; -- 33296
UPDATE `creature_model_info` SET `bounding_radius`=0.4, `combat_reach`=0.5 WHERE `modelid`=9563; -- 9563
UPDATE `creature_model_info` SET `bounding_radius`=0.4, `combat_reach`=4, `gender`=1 WHERE `modelid`=38146; -- 38146
UPDATE `creature_model_info` SET `bounding_radius`=0.403, `combat_reach`=7.8 WHERE `modelid`=33433; -- 33433
UPDATE `creature_model_info` SET `bounding_radius`=0.4125, `combat_reach`=0.825 WHERE `modelid`=24719; -- 24719
UPDATE `creature_model_info` SET `bounding_radius`=0.439875, `combat_reach`=2.15625, `gender`=0 WHERE `modelid`=33716; -- 33716
UPDATE `creature_model_info` SET `bounding_radius`=0.44045, `combat_reach`=1.725, `gender`=0 WHERE `modelid`=34363; -- 34363
UPDATE `creature_model_info` SET `bounding_radius`=0.44045, `combat_reach`=1.725, `gender`=1 WHERE `modelid`=34362; -- 34362
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=2.25 WHERE `modelid`=33073; -- 33073
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=2.25 WHERE `modelid`=35170; -- 35170
UPDATE `creature_model_info` SET `bounding_radius`=0.465, `combat_reach`=3.75 WHERE `modelid`=35166; -- 35166
UPDATE `creature_model_info` SET `bounding_radius`=0.4896, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=34630; -- 34630
UPDATE `creature_model_info` SET `bounding_radius`=0.4896, `combat_reach`=2.4, `gender`=0 WHERE `modelid`=38846; -- 38846
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=37752; -- 37752
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=37753; -- 37753
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1 WHERE `modelid`=37754; -- 37754
UPDATE `creature_model_info` SET `bounding_radius`=0.5, `combat_reach`=1.5 WHERE `modelid`=35406; -- 35406
UPDATE `creature_model_info` SET `bounding_radius`=0.5205, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=34357; -- 34357
UPDATE `creature_model_info` SET `bounding_radius`=0.5205, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=34358; -- 34358
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=31809; -- 31809
UPDATE `creature_model_info` SET `bounding_radius`=0.520833, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=33262; -- 33262
UPDATE `creature_model_info` SET `bounding_radius`=0.525, `combat_reach`=10.675 WHERE `modelid`=34021; -- 34021
UPDATE `creature_model_info` SET `bounding_radius`=0.5425, `combat_reach`=10.675 WHERE `modelid`=34025; -- 34025
UPDATE `creature_model_info` SET `bounding_radius`=0.5425, `combat_reach`=2.625 WHERE `modelid`=37193; -- 37193
UPDATE `creature_model_info` SET `bounding_radius`=0.5425, `combat_reach`=2.625 WHERE `modelid`=37195; -- 37195
UPDATE `creature_model_info` SET `bounding_radius`=0.5425, `combat_reach`=4.375 WHERE `modelid`=37194; -- 37194
UPDATE `creature_model_info` SET `bounding_radius`=0.5526451, `combat_reach`=1.5 WHERE `modelid`=24013; -- 24013
UPDATE `creature_model_info` SET `bounding_radius`=0.556, `combat_reach`=2.5 WHERE `modelid`=34020; -- 34020
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=18, `gender`=1 WHERE `modelid`=32569; -- 32569
UPDATE `creature_model_info` SET `bounding_radius`=0.558, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=35411; -- 35411
UPDATE `creature_model_info` SET `bounding_radius`=0.5745, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=35412; -- 35412
UPDATE `creature_model_info` SET `bounding_radius`=0.5835, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=38605; -- 38605
UPDATE `creature_model_info` SET `bounding_radius`=0.59, `combat_reach`=3.75, `gender`=0 WHERE `modelid`=34354; -- 34354
UPDATE `creature_model_info` SET `bounding_radius`=0.6, `combat_reach`=10, `gender`=1 WHERE `modelid`=28949; -- 28949
UPDATE `creature_model_info` SET `bounding_radius`=0.61112, `combat_reach`=20, `gender`=1 WHERE `modelid`=38447; -- 38447
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=12 WHERE `modelid`=34015; -- 34015
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=12 WHERE `modelid`=34023; -- 34023
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=20, `gender`=0 WHERE `modelid`=32716; -- 32716
UPDATE `creature_model_info` SET `bounding_radius`=0.62, `combat_reach`=3 WHERE `modelid`=35432; -- 35432
UPDATE `creature_model_info` SET `bounding_radius`=0.6255, `combat_reach`=2.8125 WHERE `modelid`=399; -- 399
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=3, `gender`=0 WHERE `modelid`=38417; -- 38417
UPDATE `creature_model_info` SET `bounding_radius`=0.7, `combat_reach`=40, `gender`=0 WHERE `modelid`=35248; -- 35248
UPDATE `creature_model_info` SET `bounding_radius`=0.713, `combat_reach`=3.45 WHERE `modelid`=32684; -- 32684
UPDATE `creature_model_info` SET `bounding_radius`=0.713, `combat_reach`=3.45 WHERE `modelid`=32685; -- 32685
UPDATE `creature_model_info` SET `bounding_radius`=0.7638884, `combat_reach`=3.3, `gender`=0 WHERE `modelid`=32583; -- 32583
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=17.5 WHERE `modelid`=39094; -- 39094
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=3.75 WHERE `modelid`=38305; -- 38305
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=5 WHERE `modelid`=34683; -- 34683
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=6.25 WHERE `modelid`=38653; -- 38653
UPDATE `creature_model_info` SET `bounding_radius`=0.775, `combat_reach`=6.25 WHERE `modelid`=38654; -- 38654
UPDATE `creature_model_info` SET `bounding_radius`=0.778, `combat_reach`=3, `gender`=0 WHERE `modelid`=38441; -- 38441
UPDATE `creature_model_info` SET `bounding_radius`=0.778, `combat_reach`=3, `gender`=0 WHERE `modelid`=38652; -- 38652
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=36437; -- 36437
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=36438; -- 36438
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=36439; -- 36439
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=36440; -- 36440
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=36441; -- 36441
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=36442; -- 36442
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=36443; -- 36443
UPDATE `creature_model_info` SET `bounding_radius`=0.78075, `combat_reach`=3.375, `gender`=0 WHERE `modelid`=36444; -- 36444
UPDATE `creature_model_info` SET `bounding_radius`=0.8, `combat_reach`=0.8 WHERE `modelid`=4960; -- 4960
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=1.2 WHERE `modelid`=23361; -- 23361
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=3 WHERE `modelid`=34822; -- 34822
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=3 WHERE `modelid`=34824; -- 34824
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=3, `gender`=0 WHERE `modelid`=34821; -- 34821
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=3, `gender`=0 WHERE `modelid`=34823; -- 34823
UPDATE `creature_model_info` SET `bounding_radius`=0.9, `combat_reach`=33, `gender`=1 WHERE `modelid`=37096; -- 37096
UPDATE `creature_model_info` SET `bounding_radius`=0.915, `combat_reach`=15 WHERE `modelid`=38594; -- 38594
UPDATE `creature_model_info` SET `bounding_radius`=0.916668, `combat_reach`=7.5 WHERE `modelid`=38175; -- 38175
UPDATE `creature_model_info` SET `bounding_radius`=0.918, `combat_reach`=4.5, `gender`=0 WHERE `modelid`=32440; -- 32440
UPDATE `creature_model_info` SET `bounding_radius`=0.93, `combat_reach`=3.75, `gender`=0 WHERE `modelid`=34353; -- 34353
UPDATE `creature_model_info` SET `bounding_radius`=0.9747, `combat_reach`=4.05, `gender`=0 WHERE `modelid`=33259; -- 33259
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=30756; -- 30756
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=30757; -- 30757
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=30758; -- 30758
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=30759; -- 30759
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=37212; -- 37212
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=37492; -- 37492
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=37493; -- 37493
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=37496; -- 37496
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=1.5 WHERE `modelid`=37756; -- 37756
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=2, `gender`=0 WHERE `modelid`=20726; -- 20726
UPDATE `creature_model_info` SET `bounding_radius`=1, `combat_reach`=52, `gender`=0 WHERE `modelid`=37875; -- 37875
UPDATE `creature_model_info` SET `bounding_radius`=1.1, `combat_reach`=11 WHERE `modelid`=34812; -- 34812
UPDATE `creature_model_info` SET `bounding_radius`=1.16964, `combat_reach`=4.860001, `gender`=0 WHERE `modelid`=38564; -- 38564
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=1.2, `gender`=1 WHERE `modelid`=32474; -- 32474
UPDATE `creature_model_info` SET `bounding_radius`=1.2, `combat_reach`=12 WHERE `modelid`=34813; -- 34813
UPDATE `creature_model_info` SET `bounding_radius`=1.26711, `combat_reach`=5.265, `gender`=0 WHERE `modelid`=38658; -- 38658
UPDATE `creature_model_info` SET `bounding_radius`=1.3, `combat_reach`=1.3, `gender`=1 WHERE `modelid`=32584; -- 32584
UPDATE `creature_model_info` SET `bounding_radius`=1.30875, `combat_reach`=5.625, `gender`=1 WHERE `modelid`=34356; -- 34356
UPDATE `creature_model_info` SET `bounding_radius`=1.3125, `combat_reach`=4.375, `gender`=0 WHERE `modelid`=33185; -- 33185
UPDATE `creature_model_info` SET `bounding_radius`=1.34, `combat_reach`=2, `gender`=0 WHERE `modelid`=31893; -- 31893
UPDATE `creature_model_info` SET `bounding_radius`=1.46205, `combat_reach`=6.075, `gender`=0 WHERE `modelid`=34355; -- 34355
UPDATE `creature_model_info` SET `bounding_radius`=1.4663, `combat_reach`=14.19, `gender`=0 WHERE `modelid`=28838; -- 28838
UPDATE `creature_model_info` SET `bounding_radius`=1.4663, `combat_reach`=9.460001 WHERE `modelid`=28839; -- 28839
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=32371; -- 32371
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=1.5 WHERE `modelid`=39456; -- 39456
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=12.5 WHERE `modelid`=34825; -- 34825
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=15 WHERE `modelid`=32232; -- 32232
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=2.25 WHERE `modelid`=35138; -- 35138
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=2.25, `gender`=0 WHERE `modelid`=34361; -- 34361
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=2.25, `gender`=1 WHERE `modelid`=34366; -- 34366
UPDATE `creature_model_info` SET `bounding_radius`=1.5, `combat_reach`=5, `gender`=0 WHERE `modelid`=33186; -- 33186
UPDATE `creature_model_info` SET `bounding_radius`=1.5278, `combat_reach`=5 WHERE `modelid`=38440; -- 38440
UPDATE `creature_model_info` SET `bounding_radius`=1.55, `combat_reach`=12.5, `gender`=0 WHERE `modelid`=35232; -- 35232
UPDATE `creature_model_info` SET `bounding_radius`=1.65699, `combat_reach`=6.885, `gender`=0 WHERE `modelid`=34628; -- 34628
UPDATE `creature_model_info` SET `bounding_radius`=1.833336, `combat_reach`=18 WHERE `modelid`=38774; -- 38774
UPDATE `creature_model_info` SET `bounding_radius`=13.545, `combat_reach`=30 WHERE `modelid`=38593; -- 38593
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2 WHERE `modelid`=30792; -- 30792
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2 WHERE `modelid`=38530; -- 38530
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=2, `gender`=0 WHERE `modelid`=38531; -- 38531
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=20 WHERE `modelid`=32809; -- 32809
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=20 WHERE `modelid`=34547; -- 34547
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=6 WHERE `modelid`=32469; -- 32469
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=6 WHERE `modelid`=33148; -- 33148
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=6 WHERE `modelid`=33149; -- 33149
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=6 WHERE `modelid`=33150; -- 33150
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=6 WHERE `modelid`=33151; -- 33151
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=6 WHERE `modelid`=33152; -- 33152
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=6 WHERE `modelid`=33153; -- 33153
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=6 WHERE `modelid`=33154; -- 33154
UPDATE `creature_model_info` SET `bounding_radius`=2, `combat_reach`=7, `gender`=0 WHERE `modelid`=34816; -- 34816
UPDATE `creature_model_info` SET `bounding_radius`=2.138892, `combat_reach`=21 WHERE `modelid`=38773; -- 38773
UPDATE `creature_model_info` SET `bounding_radius`=2.25, `combat_reach`=4.5, `gender`=0 WHERE `modelid`=32950; -- 32950
UPDATE `creature_model_info` SET `bounding_radius`=2.365, `combat_reach`=11.825, `gender`=0 WHERE `modelid`=29039; -- 29039
UPDATE `creature_model_info` SET `bounding_radius`=2.45875, `combat_reach`=1.875, `gender`=0 WHERE `modelid`=31514; -- 31514
UPDATE `creature_model_info` SET `bounding_radius`=3, `combat_reach`=4.5, `gender`=0 WHERE `modelid`=38532; -- 38532
UPDATE `creature_model_info` SET `bounding_radius`=3.5, `combat_reach`=7, `gender`=0 WHERE `modelid`=36633; -- 36633
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=1.5 WHERE `modelid`=38565; -- 38565
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=1.5 WHERE `modelid`=38566; -- 38566
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=1.5 WHERE `modelid`=38567; -- 38567
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=1.5 WHERE `modelid`=38568; -- 38568
UPDATE `creature_model_info` SET `bounding_radius`=4, `combat_reach`=20, `gender`=0 WHERE `modelid`=33308; -- 33308
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=10 WHERE `modelid`=32832; -- 32832
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=5, `gender`=0 WHERE `modelid`=35367; -- 35367
UPDATE `creature_model_info` SET `bounding_radius`=5, `combat_reach`=6.25 WHERE `modelid`=18360; -- 18360
UPDATE `creature_model_info` SET `bounding_radius`=5.58, `combat_reach`=9, `gender`=0 WHERE `modelid`=38470; -- 38470
UPDATE `creature_model_info` SET `bounding_radius`=6, `combat_reach`=6, `gender`=0 WHERE `modelid`=34576; -- 34576
UPDATE `creature_model_info` SET `bounding_radius`=6, `combat_reach`=6, `gender`=0 WHERE `modelid`=37525; -- 37525
UPDATE `creature_model_info` SET `bounding_radius`=6.112, `combat_reach`=16, `gender`=0 WHERE `modelid`=38621; -- 38621
UPDATE `creature_model_info` SET `bounding_radius`=6.82, `combat_reach`=22 WHERE `modelid`=28845; -- 28845
UPDATE `creature_model_info` SET `bounding_radius`=60, `combat_reach`=60 WHERE `modelid`=35402; -- 35402
UPDATE `creature_model_info` SET `bounding_radius`=7.5, `combat_reach`=15 WHERE `modelid`=32679; -- 32679
UPDATE `creature_model_info` SET `bounding_radius`=8.68, `combat_reach`=14, `gender`=0 WHERE `modelid`=38561; -- 38561
UPDATE `creature_model_info` SET `gender`=0 WHERE `modelid`=4602; -- 4602
UPDATE `creature_model_info` SET `gender`=1 WHERE `modelid`=4601; -- 4601


UPDATE `creature_template` SET `speed_run`=1.142857 WHERE `entry`=31755; -- Stabled Hunter Pet
UPDATE `creature_template` SET `speed_run`=1.428571, `unit_flags`=32768 WHERE `entry`=31233; -- Sinewy Wolf
UPDATE `creature_template` SET `speed_walk`=0.888888, `speed_run`=1.428571 WHERE `entry`=47086; -- Crimsonborne Firestarter
UPDATE `creature_template` SET `speed_walk`=0.888888, `speed_run`=1.428571 WHERE `entry`=47087; -- Azureborne Destroyer
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=0.9126986 WHERE `entry`=45676; -- Faceless Guardian
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.142857 WHERE `entry`=45699; -- Twilight Shadow Mender
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.142857 WHERE `entry`=45700; -- Twilight Portal Shaper
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.142857 WHERE `entry`=45848; -- Spray Blood
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.142857, `unit_flags2`=0 WHERE `entry`=44765; -- Spike
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.142857, `unit_flags2`=0 WHERE `entry`=45213; -- Sinestra
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.142857, `unit_flags2`=33556480 WHERE `entry`=47161; -- Twilight Brute
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.142857, `unit_flags`=320, `unit_flags2`=0 WHERE `entry`=45213; -- Sinestra
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571 WHERE `entry`=46951; -- Chosen Warrior
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571 WHERE `entry`=46952; -- Chosen Seer
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571 WHERE `entry`=46965; -- Cho'gall
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571 WHERE `entry`=47079; -- Lava Scarab
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571 WHERE `entry`=47152; -- Twilight Elementalist
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571, `dynamicflags`=0 WHERE `entry`=47152; -- Twilight Elementalist
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571, `unit_flags2`=134219776 WHERE `entry`=43324; -- Cho'gall
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571, `unit_flags2`=134219776 WHERE `entry`=45992; -- Valiona
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571, `unit_flags2`=134219776 WHERE `entry`=45993; -- Theralion
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571, `unit_flags2`=134219776, `dynamicflags`=0 WHERE `entry`=43324; -- Cho'gall
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571, `unit_flags2`=134219776, `dynamicflags`=0 WHERE `entry`=45992; -- Valiona
UPDATE `creature_template` SET `speed_walk`=1, `speed_run`=1.428571, `unit_flags2`=134219776, `dynamicflags`=0 WHERE `entry`=45993; -- Theralion
UPDATE `creature_template` SET `speed_walk`=1.555556, `speed_run`=1.142857, `unit_flags2`=33556480 WHERE `entry`=47081; -- Elemental Firelord
UPDATE `creature_template` SET `speed_walk`=1.555556, `speed_run`=1.142857, `unit_flags2`=33556480 WHERE `entry`=47150; -- Earth Ravager
UPDATE `creature_template` SET `speed_walk`=1.555556, `speed_run`=1.142857, `unit_flags2`=33556480 WHERE `entry`=47151; -- Wind Breaker
UPDATE `creature_template` SET `speed_walk`=1.555556, `speed_run`=1.142857, `unit_flags2`=33556480, `dynamicflags`=0 WHERE `entry`=47081; -- Elemental Firelord
UPDATE `creature_template` SET `speed_walk`=1.555556, `speed_run`=1.142857, `unit_flags2`=33556480, `dynamicflags`=0 WHERE `entry`=47150; -- Earth Ravager
UPDATE `creature_template` SET `speed_walk`=1.555556, `speed_run`=1.142857, `unit_flags2`=33556480, `dynamicflags`=0 WHERE `entry`=47151; -- Wind Breaker
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571 WHERE `entry`=45261; -- Twilight Shadow Knight
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571 WHERE `entry`=45264; -- Twilight Crossfire
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571 WHERE `entry`=45265; -- Twilight Soul Blade
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571 WHERE `entry`=45266; -- Twilight Dark Mender
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571 WHERE `entry`=45267; -- Twilight Phase-Twister
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571 WHERE `entry`=45687; -- Twilight-Shifter
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `dynamicflags`=0 WHERE `entry`=45261; -- Twilight Shadow Knight
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `dynamicflags`=0 WHERE `entry`=45264; -- Twilight Crossfire
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `dynamicflags`=0 WHERE `entry`=45265; -- Twilight Soul Blade
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `dynamicflags`=0 WHERE `entry`=45266; -- Twilight Dark Mender
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `dynamicflags`=0 WHERE `entry`=45267; -- Twilight Phase-Twister
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `unit_flags2`=0 WHERE `entry`=44641; -- Orphaned Emerald Whelp
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `unit_flags2`=0 WHERE `entry`=44645; -- Nether Scion
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `unit_flags2`=0 WHERE `entry`=44650; -- Storm Rider
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `unit_flags2`=0 WHERE `entry`=44652; -- Slate Dragon
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `unit_flags2`=0 WHERE `entry`=44797; -- Time Warden
UPDATE `creature_template` SET `speed_walk`=1.6, `speed_run`=1.428571, `unit_flags2`=34816 WHERE `entry`=44687; -- Proto-Behemoth
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.7142857 WHERE `entry`=43999; -- Corruption
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.7142857 WHERE `entry`=45685; -- Old God Portal
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.7142857 WHERE `entry`=46147; -- Valiona
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.7142857 WHERE `entry`=46296; -- Breath Flight Target Stalker
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.7142857 WHERE `entry`=46364; -- Theralion Flight Target Stalker
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=0.7142857, `unit_flags2`=67110912 WHERE `entry`=51551; -- Twilight Portal
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.428571 WHERE `entry`=49813; -- Evolved Drakonaar
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.428571 WHERE `entry`=49817; -- Bound Inferno
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.428571 WHERE `entry`=49821; -- Bound Zephyr
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.428571 WHERE `entry`=49825; -- Bound Deluge
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.428571 WHERE `entry`=49826; -- Bound Rumbler
UPDATE `creature_template` SET `speed_walk`=2, `speed_run`=1.428571, `baseattacktime`=1800, `dynamicflags`=4 WHERE `entry`=49813; -- Evolved Drakonaar
UPDATE `creature_template` SET `speed_walk`=2.8, `speed_run`=1, `unit_flags2`=67584 WHERE `entry`=43888; -- Malformation
UPDATE `creature_template` SET `speed_walk`=2.8, `speed_run`=1.714286, `unit_flags2`=0 WHERE `entry`=46277; -- Calen
UPDATE `creature_template` SET `speed_walk`=3.2, `speed_run`=1.714286 WHERE `entry`=44600; -- Halfus Wyrmbreaker
UPDATE `creature_template` SET `speed_walk`=3.2, `speed_run`=2 WHERE `entry`=43686; -- Ignacious
UPDATE `creature_template` SET `speed_walk`=3.2, `speed_run`=2 WHERE `entry`=43687; -- Feludius
UPDATE `creature_template` SET `speed_walk`=3.2, `speed_run`=2 WHERE `entry`=43688; -- Arion
UPDATE `creature_template` SET `speed_walk`=3.2, `speed_run`=2 WHERE `entry`=43689; -- Terrastra
UPDATE `creature_template` SET `speed_walk`=3.2, `speed_run`=2 WHERE `entry`=43735; -- Elementium Monstrosity
UPDATE `creature_template` SET `speed_walk`=3.2, `speed_run`=2, `dynamicflags`=0 WHERE `entry`=43735; -- Elementium Monstrosity
