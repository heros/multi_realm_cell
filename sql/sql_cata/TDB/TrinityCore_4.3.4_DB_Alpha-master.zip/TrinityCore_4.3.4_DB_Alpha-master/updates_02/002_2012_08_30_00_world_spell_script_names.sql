DELETE FROM `spell_script_names` WHERE `spell_id` IN (41054, 63418, 69893, 45205, 69896, 57594);
INSERT INTO `spell_script_names` VALUES
(41054, "spell_gen_clone_weapon_aura"),
(63418, "spell_gen_clone_weapon_aura"),
(69893, "spell_gen_clone_weapon_aura"),
(45205, "spell_gen_clone_weapon_aura"),
(69896, "spell_gen_clone_weapon_aura"),
(57594, "spell_gen_clone_weapon_aura");
