insert into `creature_template` (`entry`, `modelid_1`, `modelid_2`, `modelid_3`, `modelid_4`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed_run`, `scale`, `rank`, `mindmg`, `maxdmg`, `baseattacktime`, `family`, `type`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `mingold`, `maxgold`)
values ('500044', '17822', '0', '0', '0', "Hierlooms", "Weapons", '80', '80', '1000000', '1000000', '250000', '250000', '30000', '35', '35', '4225', '8.00', '1', '3', '500', '5000', '1000', '0', '7', '0', '0', '0', '0', '0', '0', '0', '0');


INSERT INTO `npc_vendor` (`entry`,`item`) VALUES 
('500044','42944'), 
('500044','44096'), 
('500044','42943'), 
('500044','42946'), 
('500044','42948'), 
('500044','42947'), 
('500044','44095'), 
('500044','44092'), 
('500044','48718'), 
('500044','44091'), 
('500044','44094'), 
('500044','44093'), 
('500044','42945'), 
('500044','48716');
