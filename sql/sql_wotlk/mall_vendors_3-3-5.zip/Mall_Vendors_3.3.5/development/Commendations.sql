insert into `creature_template` (`entry`, `modelid_1`, `modelid_2`, `modelid_3`, `modelid_4`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed_run`, `scale`, `rank`, `mindmg`, `maxdmg`, `baseattacktime`, `family`, `type`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `mingold`, `maxgold`)
values ('500019', '17822', '0', '0', '0', "Commendations", "Miscellaneous", '80', '80', '1000000', '1000000', '250000', '250000', '30000', '35', '35', '4225', '8.00', '1', '3', '500', '5000', '1000', '0', '7', '0', '0', '0', '0', '0', '0', '0', '0');


INSERT INTO `npc_vendor` (`entry`,`item`) VALUES
('500019','44115'),
('500019','45706'),
('500019','43950'),
('500019','44710'),
('500019','44711'),
('500019','44713'),
('500019','45714'),
('500019','45715'),
('500019','45716'),
('500019','45717'),
('500019','45718'),
('500019','45719'),
('500019','45720'),
('500019','45721'),
('500019','45722'),
('500019','45723'),
('500019','49702');


