insert into `creature_template` (`entry`, `modelid_1`, `modelid_2`, `modelid_3`, `modelid_4`, `name`, `subname`, `minlevel`, `maxlevel`, `minhealth`, `maxhealth`, `minmana`, `maxmana`, `armor`, `faction_A`, `faction_H`, `npcflag`, `speed_run`, `scale`, `rank`, `mindmg`, `maxdmg`, `baseattacktime`, `family`, `type`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `mingold`, `maxgold`)
values ('500036', '17822', '0', '0', '0', "Fishing Poles", "Weapons", '80', '80', '1000000', '1000000', '250000', '250000', '30000', '35', '35', '4225', '8.00', '1', '3', '500', '5000', '1000', '0', '7', '0', '0', '0', '0', '0', '0', '0', '0');


INSERT INTO `npc_vendor` (`entry`,`item`) VALUES 
('500036','44050'),
('500036','19970'),
('500036','45991'),
('500036','45992'),
('500036','45858'),
('500036','19022'),
('500036','25978'),
('500036','6367'),
('500036','12225'),
('500036','6366'),
('500036','6256'),
('500036','6365');
