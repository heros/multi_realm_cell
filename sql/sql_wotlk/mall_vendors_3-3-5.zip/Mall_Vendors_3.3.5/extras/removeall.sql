DELETE FROM creature_template WHERE entry >= 500000 AND entry <= 500113;
DELETE FROM npc_vendor WHERE entry >= 500000 AND entry <= 500113;
DELETE FROM creature WHERE guid >= 500001 AND guid <= 500118;