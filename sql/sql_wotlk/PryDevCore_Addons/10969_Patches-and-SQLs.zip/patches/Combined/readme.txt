I am adding this file to let people know what is and is not included in the ALL patch.

Included:
argent tournament
AHBOT with VIPAccounts (had to combine the 2, because VIPAccounts require auctionhousebot.cpp)
Dalaran Sewers
Fix Turret
GM 1 NORMAL
Guildhouses (sell option not working, and it does not take gold when you buy. it does make sure you have the gold. Will be fixed...)
Isle of Conquest
Paladin redeaming the dead hack (yes it is a hack. got no complaints so far)
Ruby Sanctum
TeleNPC2
Wintergrasp
XP After Level 100


Not Included:
Icecrown Citadel by bolvor (crappy patch. doesn't work and is worthless without gunship. completely removed from repo.)
AC2
BOTS (Added another patch that includes BOTS. If you want a patch with BOTS and without AC2 let me know. VIPAccounts makes it very hard to compile other patches in.)
City Conquest
TrinityJail
Gamble


There is a 3rd all patch that has everything listed except gamble.